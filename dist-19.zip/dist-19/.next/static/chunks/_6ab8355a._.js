(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([typeof document === "object" ? document.currentScript : undefined, {

"[project]/components/profile/ProfileCard.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": ()=>ProfileCard
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/image.js [app-client] (ecmascript)");
;
;
function renderStars(rating) {
    const stars = [];
    const fullStars = Math.floor(rating);
    const hasHalfStar = rating % 1 >= 0.5;
    for(let i = 0; i < fullStars; i++){
        stars.push(/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
            className: "text-yellow-400 text-lg",
            children: "★"
        }, i, false, {
            fileName: "[project]/components/profile/ProfileCard.tsx",
            lineNumber: 16,
            columnNumber: 7
        }, this));
    }
    if (hasHalfStar) {
        stars.push(/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
            className: "text-yellow-400 text-lg",
            children: "☆"
        }, "half", false, {
            fileName: "[project]/components/profile/ProfileCard.tsx",
            lineNumber: 23,
            columnNumber: 7
        }, this));
    }
    for(let i = stars.length; i < 5; i++){
        stars.push(/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
            className: "text-gray-300 text-lg",
            children: "☆"
        }, i, false, {
            fileName: "[project]/components/profile/ProfileCard.tsx",
            lineNumber: 30,
            columnNumber: 7
        }, this));
    }
    return stars;
}
function VerificationBadge(param) {
    let { verified, label } = param;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "flex items-center gap-2",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: "w-5 h-5 rounded-full ".concat(verified ? "bg-black" : "bg-gray-300"),
                children: verified && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                    className: "block w-full h-full text-white text-xs leading-5 text-center",
                    children: "✓"
                }, void 0, false, {
                    fileName: "[project]/components/profile/ProfileCard.tsx",
                    lineNumber: 53,
                    columnNumber: 11
                }, this)
            }, void 0, false, {
                fileName: "[project]/components/profile/ProfileCard.tsx",
                lineNumber: 47,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: "text-sm text-gray-700",
                children: label
            }, void 0, false, {
                fileName: "[project]/components/profile/ProfileCard.tsx",
                lineNumber: 58,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/components/profile/ProfileCard.tsx",
        lineNumber: 46,
        columnNumber: 5
    }, this);
}
_c = VerificationBadge;
function ProfileCard(param) {
    let { user, className = "" } = param;
    var _user_subscription_end_date, _user_subscription_end_date1, _user_current_package_plan;
    // Compose name
    const name = "".concat(user.first_name, " ").concat(user.last_name).trim() || user.username;
    const avatar = user.avatar || user.profile_picture || "https://static.vecteezy.com/system/resources/thumbnails/020/765/399/small_2x/default-profile-account-unknown-icon-black-silhouette-free-vector.jpg";
    const email = user.email;
    const phone = user.phone_number || "";
    const bio = user.bio || "";
    const memberSince = ((_user_subscription_end_date = user.subscription_end_date) === null || _user_subscription_end_date === void 0 ? void 0 : _user_subscription_end_date.slice(0, 12)) || ((_user_subscription_end_date1 = user.subscription_end_date) === null || _user_subscription_end_date1 === void 0 ? void 0 : _user_subscription_end_date1.slice(0, 12)) || "";
    // Show review score and numbers
    const rating = user.review_score || 0;
    const reviewNumbers = user.review_numbers || 0;
    // Show package plan if available
    const packagePlan = ((_user_current_package_plan = user.current_package_plan) === null || _user_current_package_plan === void 0 ? void 0 : _user_current_package_plan.package) || "-";
    // Show subscription status
    const subscriptionStatus = user.subscription_status;
    // Show professional badge
    const isProfessional = user.professional;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "bg-white rounded-2xl shadow-xl p-8 mb-8 ".concat(className),
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex flex-col lg:flex-row items-start lg:items-center gap-8",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex items-center gap-6",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                src: avatar,
                                alt: name,
                                width: 96,
                                height: 96,
                                className: "rounded-full border-4 border-gray-200 shadow-lg"
                            }, void 0, false, {
                                fileName: "[project]/components/profile/ProfileCard.tsx",
                                lineNumber: 92,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                                        className: "font-bold text-3xl text-gray-900 mb-2 flex items-center gap-2",
                                        children: [
                                            name,
                                            isProfessional && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "ml-2 px-2 py-1 bg-blue-100 text-blue-700 text-xs rounded-full font-semibold",
                                                children: "Pro"
                                            }, void 0, false, {
                                                fileName: "[project]/components/profile/ProfileCard.tsx",
                                                lineNumber: 103,
                                                columnNumber: 17
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/components/profile/ProfileCard.tsx",
                                        lineNumber: 100,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "flex items-center gap-2 mb-2",
                                        children: [
                                            renderStars(rating),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "text-gray-600 ml-1",
                                                children: [
                                                    "(",
                                                    rating.toFixed(1),
                                                    ")"
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/components/profile/ProfileCard.tsx",
                                                lineNumber: 110,
                                                columnNumber: 15
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "text-gray-400 text-xs",
                                                children: [
                                                    reviewNumbers,
                                                    " reviews"
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/components/profile/ProfileCard.tsx",
                                                lineNumber: 111,
                                                columnNumber: 15
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/components/profile/ProfileCard.tsx",
                                        lineNumber: 108,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "text-gray-600 text-sm mb-1",
                                        children: email
                                    }, void 0, false, {
                                        fileName: "[project]/components/profile/ProfileCard.tsx",
                                        lineNumber: 115,
                                        columnNumber: 13
                                    }, this),
                                    phone && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "text-gray-600 text-sm",
                                        children: phone
                                    }, void 0, false, {
                                        fileName: "[project]/components/profile/ProfileCard.tsx",
                                        lineNumber: 116,
                                        columnNumber: 23
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/components/profile/ProfileCard.tsx",
                                lineNumber: 99,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/profile/ProfileCard.tsx",
                        lineNumber: 91,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex-1 lg:text-right",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "grid grid-cols-2 md:grid-cols-3 gap-6 text-center lg:text-right",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "text-2xl font-bold text-gray-900",
                                            children: "Forfait"
                                        }, void 0, false, {
                                            fileName: "[project]/components/profile/ProfileCard.tsx",
                                            lineNumber: 123,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "text-sm text-gray-600",
                                            children: packagePlan
                                        }, void 0, false, {
                                            fileName: "[project]/components/profile/ProfileCard.tsx",
                                            lineNumber: 126,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/components/profile/ProfileCard.tsx",
                                    lineNumber: 122,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "text-2xl font-bold text-gray-900",
                                            children: "Abonnement"
                                        }, void 0, false, {
                                            fileName: "[project]/components/profile/ProfileCard.tsx",
                                            lineNumber: 129,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "text-sm text-gray-600",
                                            children: subscriptionStatus
                                        }, void 0, false, {
                                            fileName: "[project]/components/profile/ProfileCard.tsx",
                                            lineNumber: 132,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/components/profile/ProfileCard.tsx",
                                    lineNumber: 128,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "text-2xl font-bold text-gray-900",
                                            children: "Valide jusqu’au"
                                        }, void 0, false, {
                                            fileName: "[project]/components/profile/ProfileCard.tsx",
                                            lineNumber: 135,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "text-sm text-gray-600",
                                            children: memberSince
                                        }, void 0, false, {
                                            fileName: "[project]/components/profile/ProfileCard.tsx",
                                            lineNumber: 139,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/components/profile/ProfileCard.tsx",
                                    lineNumber: 134,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/components/profile/ProfileCard.tsx",
                            lineNumber: 121,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/components/profile/ProfileCard.tsx",
                        lineNumber: 120,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/profile/ProfileCard.tsx",
                lineNumber: 90,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "mt-6 pt-6 border-t border-gray-200",
                children: [
                    bio && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "text-gray-700 italic mb-4",
                        children: bio
                    }, void 0, false, {
                        fileName: "[project]/components/profile/ProfileCard.tsx",
                        lineNumber: 146,
                        columnNumber: 17
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex flex-wrap gap-4",
                        children: [
                            user.cin && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "px-2 py-1 bg-gray-100 text-gray-700 text-xs rounded",
                                children: [
                                    "CIN: ",
                                    user.cin
                                ]
                            }, void 0, true, {
                                fileName: "[project]/components/profile/ProfileCard.tsx",
                                lineNumber: 150,
                                columnNumber: 13
                            }, this),
                            user.driving_licence && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "px-2 py-1 bg-gray-100 text-gray-700 text-xs rounded",
                                children: [
                                    "Permis de conduire : ",
                                    user.driving_licence
                                ]
                            }, void 0, true, {
                                fileName: "[project]/components/profile/ProfileCard.tsx",
                                lineNumber: 155,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "px-2 py-1 bg-gray-100 text-gray-700 text-xs rounded",
                                children: [
                                    "Renouvellement automatique: ",
                                    user.auto_renew ? "Yes" : "No"
                                ]
                            }, void 0, true, {
                                fileName: "[project]/components/profile/ProfileCard.tsx",
                                lineNumber: 160,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "px-2 py-1 text-xs rounded ".concat(user.is_active ? "bg-green-100 text-green-700" : "bg-red-100 text-red-700"),
                                children: user.is_active ? "Active" : "Inactive"
                            }, void 0, false, {
                                fileName: "[project]/components/profile/ProfileCard.tsx",
                                lineNumber: 164,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/profile/ProfileCard.tsx",
                        lineNumber: 147,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/profile/ProfileCard.tsx",
                lineNumber: 145,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/components/profile/ProfileCard.tsx",
        lineNumber: 89,
        columnNumber: 5
    }, this);
}
_c1 = ProfileCard;
var _c, _c1;
__turbopack_context__.k.register(_c, "VerificationBadge");
__turbopack_context__.k.register(_c1, "ProfileCard");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/components/profile/TripsSection.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
// import Link from "next/link";
// interface TripItemProps {
//   trip: {
//     id: number;
//     from: string;
//     to: string;
//     date: string;
//     price: string;
//     status: string;
//     seats?: number;
//     driver?: string;
//     bookedSeats?: number;
//     seatsAvailable?: number;
//   };
//   type: "reservation" | "offered";
//   onCancel?: (tripId: number) => void;
//   onEdit?: (tripId: number) => void;
// }
// interface TripsSectionProps {
//   title: string;
//   trips: TripItemProps["trip"][];
//   type: "reservation" | "offered";
//   onCancel?: (tripId: number) => void;
//   onEdit?: (tripId: number) => void;
//   className?: string;
// }
// function TripItem({ trip, type, onCancel, onEdit }: TripItemProps) {
//   const getStatusColor = (status: string) => {
//     switch (status.toLowerCase()) {
//       case "confirmed":
//       case "active":
//         return "bg-black text-white";
//       case "pending":
//         return "bg-gray-300 text-gray-700";
//       case "completed":
//       case "full":
//         return "bg-gray-100 text-gray-700";
//       default:
//         return "bg-gray-300 text-gray-700";
//     }
//   };
//   // Deterministic UTC date formatting
//   const dateObj = new Date(trip.date);
//   const dateStr =
//     dateObj.getUTCFullYear() +
//     "-" +
//     String(dateObj.getUTCMonth() + 1).padStart(2, "0") +
//     "-" +
//     String(dateObj.getUTCDate()).padStart(2, "0");
//   const timeStr =
//     String(dateObj.getUTCHours()).padStart(2, "0") +
//     ":" +
//     String(dateObj.getUTCMinutes()).padStart(2, "0");
//   const content = (
//     <div className="border border-gray-200 rounded-xl p-4 hover:shadow-md transition cursor-pointer">
//       <div className="flex justify-between items-start mb-3">
//         <div>
//           <div className="font-semibold text-lg text-gray-900">
//             {trip.from} <span className="text-gray-400">→</span> {trip.to}
//           </div>
//           <div className="text-gray-600 text-sm">
//   {dateStr} à {timeStr}H
// </div>
//           {type === "reservation" && trip.driver && (
//             <div className="text-gray-600 text-sm">
//               with <span className="font-medium">{trip.driver}</span>
//             </div>
//           )}
//           {type === "offered" && (
//             <div className="text-gray-600 text-sm">
//               {trip.status?.toLowerCase() === "full"
//                 ? `Full${
//                     typeof trip.seatsAvailable === "number" &&
//                     trip.seatsAvailable > 0
//                       ? ` (${trip.seatsAvailable} available)`
//                       : ""
//                   }`
//                 : typeof trip.seatsAvailable === "number"
//                 ? `${trip.seatsAvailable} seats available`
//                 : "-"}
//             </div>
//           )}
//         </div>
//         <div className="text-right">
//           <div className="text-lg font-bold text-gray-900">{trip.price} TND</div>
//           {type === "reservation" && trip.seats && (
//             <div className="text-sm text-gray-600">
//               {trip.seats} seat{trip.seats !== 1 ? "s" : ""}
//             </div>
//           )}
//           {type === "offered" && (
//             <div className="text-sm text-gray-600">par place</div>
//           )}
//         </div>
//       </div>
//       <div className="flex justify-between items-center">
//         <span
//           className={`px-3 py-1 rounded-full text-xs font-semibold ${getStatusColor(
//             trip.status
//           )}`}
//         >
//           {trip.status}
//         </span>
//         <div className="flex gap-2">
//           {onCancel && trip.status?.toLowerCase() !== "canceled" && (
//             <button
//               onClick={() => onCancel(trip.id)}
//               className="text-sm text-red-600 hover:text-red-800 font-medium border border-red-200 rounded px-2 py-1"
//             >
//               Supprimer
//             </button>
//           )}
//         </div>
//       </div>
//     </div>
//   );
//   if (type === "offered") {
//     return (
//       <Link
//         href={`/rides/${trip.id}`}
//         style={{ textDecoration: "none", color: "inherit" }}
//       >
//         {content}
//       </Link>
//     );
//   }
//   return content;
// }
// export default function TripsSection({
//   title,
//   trips,
//   type,
//   onCancel,
//   onEdit,
//   className = "",
// }: TripsSectionProps) {
//   return (
//     <div className={`bg-white rounded-2xl shadow-xl p-8 ${className}`}>
//       <h2 className="text-2xl font-bold text-gray-900 mb-6">{title}</h2>
//       <div className="space-y-4 max-h-96 overflow-y-auto pr-2">
//         {trips.map((trip) => (
//           <TripItem
//             key={trip.id}
//             trip={trip}
//             type={type}
//             onCancel={onCancel}
//             onEdit={onEdit}
//           />
//         ))}
//       </div>
//     </div>
//   );
// }
__turbopack_context__.s({
    "default": ()=>TripsSection
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
;
// Composant Modal de Confirmation
function ConfirmDeleteModal(param) {
    let { isOpen, onClose, onConfirm, tripInfo } = param;
    if (!isOpen) return null;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50",
        onClick: onClose,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "bg-white rounded-xl shadow-2xl p-6 max-w-md w-full mx-4",
            onClick: (e)=>e.stopPropagation(),
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex items-center gap-3 mb-4",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "w-12 h-12 bg-red-100 rounded-full flex items-center justify-center",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                className: "w-6 h-6 text-red-600",
                                fill: "none",
                                stroke: "currentColor",
                                viewBox: "0 0 24 24",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                    strokeLinecap: "round",
                                    strokeLinejoin: "round",
                                    strokeWidth: 2,
                                    d: "M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"
                                }, void 0, false, {
                                    fileName: "[project]/components/profile/TripsSection.tsx",
                                    lineNumber: 222,
                                    columnNumber: 15
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/components/profile/TripsSection.tsx",
                                lineNumber: 216,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/components/profile/TripsSection.tsx",
                            lineNumber: 215,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                className: "text-lg font-bold text-gray-900",
                                children: "Confirmer la suppression"
                            }, void 0, false, {
                                fileName: "[project]/components/profile/TripsSection.tsx",
                                lineNumber: 231,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/components/profile/TripsSection.tsx",
                            lineNumber: 230,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/components/profile/TripsSection.tsx",
                    lineNumber: 214,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "mb-6",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: "text-gray-600 mb-3",
                            children: "Êtes-vous sûr de vouloir supprimer ce trajet ?"
                        }, void 0, false, {
                            fileName: "[project]/components/profile/TripsSection.tsx",
                            lineNumber: 238,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "bg-gray-50 rounded-lg p-3 border border-gray-200",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "text-sm font-semibold text-gray-900",
                                    children: [
                                        tripInfo.from,
                                        " → ",
                                        tripInfo.to
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/components/profile/TripsSection.tsx",
                                    lineNumber: 242,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "text-sm text-gray-600",
                                    children: tripInfo.date
                                }, void 0, false, {
                                    fileName: "[project]/components/profile/TripsSection.tsx",
                                    lineNumber: 245,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/components/profile/TripsSection.tsx",
                            lineNumber: 241,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: "text-sm text-red-600 mt-3",
                            children: "Cette action est irréversible."
                        }, void 0, false, {
                            fileName: "[project]/components/profile/TripsSection.tsx",
                            lineNumber: 247,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/components/profile/TripsSection.tsx",
                    lineNumber: 237,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex gap-3",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            onClick: onClose,
                            className: "flex-1 px-4 py-2 border border-gray-300 rounded-lg text-gray-700 font-medium hover:bg-gray-50 transition",
                            children: "Annuler"
                        }, void 0, false, {
                            fileName: "[project]/components/profile/TripsSection.tsx",
                            lineNumber: 253,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            onClick: onConfirm,
                            className: "flex-1 px-4 py-2 bg-red-600 text-white rounded-lg font-medium hover:bg-red-700 transition",
                            children: "Supprimer"
                        }, void 0, false, {
                            fileName: "[project]/components/profile/TripsSection.tsx",
                            lineNumber: 259,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/components/profile/TripsSection.tsx",
                    lineNumber: 252,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/components/profile/TripsSection.tsx",
            lineNumber: 210,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/components/profile/TripsSection.tsx",
        lineNumber: 206,
        columnNumber: 5
    }, this);
}
_c = ConfirmDeleteModal;
function TripItem(param) {
    let { trip, type, onCancel, onEdit } = param;
    var _trip_status, _trip_status1;
    _s();
    const [showConfirmModal, setShowConfirmModal] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [isNavigating, setIsNavigating] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const getStatusColor = (status)=>{
        switch(status.toLowerCase()){
            case "confirmed":
            case "active":
                return "bg-black text-white";
            case "pending":
                return "bg-gray-300 text-gray-700";
            case "completed":
            case "full":
                return "bg-gray-100 text-gray-700";
            default:
                return "bg-gray-300 text-gray-700";
        }
    };
    // Deterministic UTC date formatting
    const dateObj = new Date(trip.date);
    const dateStr = dateObj.getUTCFullYear() + "-" + String(dateObj.getUTCMonth() + 1).padStart(2, "0") + "-" + String(dateObj.getUTCDate()).padStart(2, "0");
    const timeStr = String(dateObj.getUTCHours()).padStart(2, "0") + ":" + String(dateObj.getUTCMinutes()).padStart(2, "0");
    const handleDeleteClick = (e)=>{
        e.preventDefault();
        e.stopPropagation();
        setShowConfirmModal(true);
    };
    const handleConfirmDelete = ()=>{
        setShowConfirmModal(false);
        if (onCancel) {
            onCancel(trip.id);
        }
    };
    const handleCardClick = (e)=>{
        // Empêcher la navigation si le modal est ouvert
        if (showConfirmModal || isNavigating) {
            e.preventDefault();
            return;
        }
        // Pour les trajets offerts, naviguer vers la page de détails
        if (type === "offered") {
            setIsNavigating(true);
            window.location.href = "/rides/".concat(trip.id);
        }
    };
    const content = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "border border-gray-200 rounded-xl p-4 hover:shadow-md transition cursor-pointer",
        onClick: handleCardClick,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex justify-between items-start mb-3",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "font-semibold text-lg text-gray-900",
                                children: [
                                    trip.from,
                                    " ",
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "text-gray-400",
                                        children: "→"
                                    }, void 0, false, {
                                        fileName: "[project]/components/profile/TripsSection.tsx",
                                        lineNumber: 338,
                                        columnNumber: 25
                                    }, this),
                                    " ",
                                    trip.to
                                ]
                            }, void 0, true, {
                                fileName: "[project]/components/profile/TripsSection.tsx",
                                lineNumber: 337,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "text-gray-600 text-sm",
                                children: [
                                    dateStr,
                                    " à ",
                                    timeStr,
                                    "H"
                                ]
                            }, void 0, true, {
                                fileName: "[project]/components/profile/TripsSection.tsx",
                                lineNumber: 340,
                                columnNumber: 11
                            }, this),
                            type === "reservation" && trip.driver && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "text-gray-600 text-sm",
                                children: [
                                    "with ",
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "font-medium",
                                        children: trip.driver
                                    }, void 0, false, {
                                        fileName: "[project]/components/profile/TripsSection.tsx",
                                        lineNumber: 345,
                                        columnNumber: 20
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/components/profile/TripsSection.tsx",
                                lineNumber: 344,
                                columnNumber: 13
                            }, this),
                            type === "offered" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "text-gray-600 text-sm",
                                children: ((_trip_status = trip.status) === null || _trip_status === void 0 ? void 0 : _trip_status.toLowerCase()) === "full" ? "Full".concat(typeof trip.seatsAvailable === "number" && trip.seatsAvailable > 0 ? " (".concat(trip.seatsAvailable, " available)") : "") : typeof trip.seatsAvailable === "number" ? "".concat(trip.seatsAvailable, " seats available") : "-"
                            }, void 0, false, {
                                fileName: "[project]/components/profile/TripsSection.tsx",
                                lineNumber: 349,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/profile/TripsSection.tsx",
                        lineNumber: 336,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "text-right",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "text-lg font-bold text-gray-900",
                                children: [
                                    trip.price,
                                    " TND"
                                ]
                            }, void 0, true, {
                                fileName: "[project]/components/profile/TripsSection.tsx",
                                lineNumber: 364,
                                columnNumber: 11
                            }, this),
                            type === "reservation" && trip.seats && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "text-sm text-gray-600",
                                children: [
                                    trip.seats,
                                    " seat",
                                    trip.seats !== 1 ? "s" : ""
                                ]
                            }, void 0, true, {
                                fileName: "[project]/components/profile/TripsSection.tsx",
                                lineNumber: 366,
                                columnNumber: 13
                            }, this),
                            type === "offered" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "text-sm text-gray-600",
                                children: "par place"
                            }, void 0, false, {
                                fileName: "[project]/components/profile/TripsSection.tsx",
                                lineNumber: 371,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/profile/TripsSection.tsx",
                        lineNumber: 363,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/profile/TripsSection.tsx",
                lineNumber: 335,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex justify-between items-center",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "px-3 py-1 rounded-full text-xs font-semibold ".concat(getStatusColor(trip.status)),
                        children: trip.status
                    }, void 0, false, {
                        fileName: "[project]/components/profile/TripsSection.tsx",
                        lineNumber: 376,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex gap-2",
                        children: onCancel && ((_trip_status1 = trip.status) === null || _trip_status1 === void 0 ? void 0 : _trip_status1.toLowerCase()) !== "canceled" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            onClick: handleDeleteClick,
                            className: "text-sm text-red-600 hover:text-red-800 font-medium border border-red-200 rounded px-3 py-1 hover:bg-red-50 transition",
                            children: "Supprimer"
                        }, void 0, false, {
                            fileName: "[project]/components/profile/TripsSection.tsx",
                            lineNumber: 385,
                            columnNumber: 13
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/components/profile/TripsSection.tsx",
                        lineNumber: 383,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/profile/TripsSection.tsx",
                lineNumber: 375,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(ConfirmDeleteModal, {
                isOpen: showConfirmModal,
                onClose: ()=>setShowConfirmModal(false),
                onConfirm: handleConfirmDelete,
                tripInfo: {
                    from: trip.from,
                    to: trip.to,
                    date: "".concat(dateStr, " à ").concat(timeStr, "H")
                }
            }, void 0, false, {
                fileName: "[project]/components/profile/TripsSection.tsx",
                lineNumber: 396,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/components/profile/TripsSection.tsx",
        lineNumber: 331,
        columnNumber: 5
    }, this);
    // Retourner directement le contenu sans Link
    return content;
}
_s(TripItem, "CFeLNtuFRw66pCJp+y9VULmh+E4=");
_c1 = TripItem;
function TripsSection(param) {
    let { title, trips, type, onCancel, onEdit, className = "" } = param;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "bg-white rounded-2xl shadow-xl p-8 ".concat(className),
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                className: "text-2xl font-bold text-gray-900 mb-6",
                children: title
            }, void 0, false, {
                fileName: "[project]/components/profile/TripsSection.tsx",
                lineNumber: 423,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "space-y-4 max-h-96 overflow-y-auto pr-2",
                children: trips.map((trip)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(TripItem, {
                        trip: trip,
                        type: type,
                        onCancel: onCancel,
                        onEdit: onEdit
                    }, trip.id, false, {
                        fileName: "[project]/components/profile/TripsSection.tsx",
                        lineNumber: 426,
                        columnNumber: 11
                    }, this))
            }, void 0, false, {
                fileName: "[project]/components/profile/TripsSection.tsx",
                lineNumber: 424,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/components/profile/TripsSection.tsx",
        lineNumber: 422,
        columnNumber: 5
    }, this);
}
_c2 = TripsSection;
var _c, _c1, _c2;
__turbopack_context__.k.register(_c, "ConfirmDeleteModal");
__turbopack_context__.k.register(_c1, "TripItem");
__turbopack_context__.k.register(_c2, "TripsSection");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/components/profile/Toast.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
// src/components/ui/Toast.tsx
__turbopack_context__.s({
    "default": ()=>Toast
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$circle$2d$check$2d$big$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__CheckCircle$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/circle-check-big.js [app-client] (ecmascript) <export default as CheckCircle>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$circle$2d$x$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__XCircle$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/circle-x.js [app-client] (ecmascript) <export default as XCircle>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$circle$2d$alert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__AlertCircle$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/circle-alert.js [app-client] (ecmascript) <export default as AlertCircle>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$x$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__X$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/x.js [app-client] (ecmascript) <export default as X>");
;
var _s = __turbopack_context__.k.signature();
;
;
function Toast(param) {
    let { message, type = 'success', onClose, duration = 3000 } = param;
    _s();
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "Toast.useEffect": ()=>{
            const timer = setTimeout({
                "Toast.useEffect.timer": ()=>{
                    onClose();
                }
            }["Toast.useEffect.timer"], duration);
            return ({
                "Toast.useEffect": ()=>clearTimeout(timer)
            })["Toast.useEffect"];
        }
    }["Toast.useEffect"], [
        duration,
        onClose
    ]);
    const icons = {
        success: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$circle$2d$check$2d$big$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__CheckCircle$3e$__["CheckCircle"], {
            className: "w-6 h-6 text-green-500"
        }, void 0, false, {
            fileName: "[project]/components/profile/Toast.tsx",
            lineNumber: 22,
            columnNumber: 14
        }, this),
        error: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$circle$2d$x$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__XCircle$3e$__["XCircle"], {
            className: "w-6 h-6 text-red-500"
        }, void 0, false, {
            fileName: "[project]/components/profile/Toast.tsx",
            lineNumber: 23,
            columnNumber: 12
        }, this),
        warning: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$circle$2d$alert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__AlertCircle$3e$__["AlertCircle"], {
            className: "w-6 h-6 text-yellow-500"
        }, void 0, false, {
            fileName: "[project]/components/profile/Toast.tsx",
            lineNumber: 24,
            columnNumber: 14
        }, this)
    };
    const bgColors = {
        success: 'bg-green-50 border-green-200',
        error: 'bg-red-50 border-red-200',
        warning: 'bg-yellow-50 border-yellow-200'
    };
    const textColors = {
        success: 'text-green-800',
        error: 'text-red-800',
        warning: 'text-yellow-800'
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "fixed top-4 right-4 z-[9999] animate-slideInRight",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex items-center gap-3 px-4 py-3 rounded-lg border-2 shadow-lg ".concat(bgColors[type], " backdrop-blur-sm"),
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex-shrink-0",
                        children: icons[type]
                    }, void 0, false, {
                        fileName: "[project]/components/profile/Toast.tsx",
                        lineNumber: 42,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "font-medium ".concat(textColors[type]),
                        children: message
                    }, void 0, false, {
                        fileName: "[project]/components/profile/Toast.tsx",
                        lineNumber: 45,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        onClick: onClose,
                        className: "flex-shrink-0 ml-2 p-1 hover:bg-white/50 rounded-full transition-colors",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$x$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__X$3e$__["X"], {
                            className: "w-4 h-4"
                        }, void 0, false, {
                            fileName: "[project]/components/profile/Toast.tsx",
                            lineNumber: 52,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/components/profile/Toast.tsx",
                        lineNumber: 48,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/profile/Toast.tsx",
                lineNumber: 41,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("style", {
                children: "\n        @keyframes slideInRight {\n          from {\n            opacity: 0;\n            transform: translateX(100%);\n          }\n          to {\n            opacity: 1;\n            transform: translateX(0);\n          }\n        }\n        .animate-slideInRight {\n          animation: slideInRight 0.3s ease-out;\n        }\n      "
            }, void 0, false, {
                fileName: "[project]/components/profile/Toast.tsx",
                lineNumber: 56,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/components/profile/Toast.tsx",
        lineNumber: 40,
        columnNumber: 5
    }, this);
}
_s(Toast, "OD7bBpZva5O2jO+Puf00hKivP7c=");
_c = Toast;
var _c;
__turbopack_context__.k.register(_c, "Toast");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/components/profile/EditCarModal.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
// // src/components/profile/EditCarModal.tsx
// import { useState, useEffect } from 'react';
// import { X, Upload, Car as CarIcon, Palette, Fuel, Calendar, Hash, FileText } from 'lucide-react';
// import api from '../../api/api';
// // ============================================================================
// // TYPES - Correspond à votre backend Django
// // ============================================================================
// interface VehicleType {
//   id: number;
//   name: string;
// }
// interface Color {
//   id: number;
//   name: string;
//   code: string;
// }
// interface EngineType {
//   id: number;
//   name: string;
// }
// interface Brand {
//   id: number;
//   name: string;
// }
// interface Model {
//   id: number;
//   name: string;
//   brand: Brand;
// }
// interface CarData {
//   id: number;
//   vehicle_type: number;
//   color: number;
//   engine_type: number;
//   model: number;
//   serial_number: string;
//   nb_place: number;
//   grey_card: string;
//   year: number;
//   image?: string;
// }
// interface EditCarModalProps {
//   car: CarData;
//   isOpen: boolean;
//   onClose: () => void;
//   onSuccess: () => void;
// }
// // ============================================================================
// // COMPOSANT EDIT CAR MODAL
// // ============================================================================
// export default function EditCarModal({ car, isOpen, onClose, onSuccess }: EditCarModalProps) {
//   const [formData, setFormData] = useState({
//     vehicle_type: car.vehicle_type,
//     color: car.color,
//     engine_type: car.engine_type,
//     model: car.model,
//     serial_number: car.serial_number,
//     nb_place: car.nb_place,
//     grey_card: car.grey_card,
//     year: car.year,
//     image: car.image || ''
//   });
//   const [imageFile, setImageFile] = useState<File | null>(null);
//   const [imagePreview, setImagePreview] = useState(car.image || '');
//   const [errors, setErrors] = useState<Record<string, string>>({});
//   const [isLoading, setIsLoading] = useState(false);
//   // États pour stocker les données depuis l'API
//   const [vehicleTypes, setVehicleTypes] = useState<VehicleType[]>([]);
//   const [colors, setColors] = useState<Color[]>([]);
//   const [engineTypes, setEngineTypes] = useState<EngineType[]>([]);
//   const [models, setModels] = useState<Model[]>([]);
//   const [loadingData, setLoadingData] = useState(true);
//   // Charger les données depuis l'API au montage du composant
//   useEffect(() => {
//     const fetchData = async () => {
//       if (!isOpen) return;
//       setLoadingData(true);
//       try {
//         const [vehicleTypesRes, colorsRes, engineTypesRes, modelsRes] = await Promise.all([
//           api.get('/api/vehicle-types/'),
//           api.get('/api/colors/'),
//           api.get('/api/engine-types/'),
//           api.get('/api/models/')
//         ]);
//         setVehicleTypes(vehicleTypesRes.data);
//         setColors(colorsRes.data);
//         setEngineTypes(engineTypesRes.data);
//         setModels(modelsRes.data);
//       } catch (error) {
//         console.error('Erreur lors du chargement des données:', error);
//         setErrors({ submit: 'Erreur lors du chargement des données' });
//       } finally {
//         setLoadingData(false);
//       }
//     };
//     fetchData();
//   }, [isOpen]);
//   useEffect(() => {
//     if (isOpen) {
//       document.body.style.overflow = 'hidden';
//     } else {
//       document.body.style.overflow = 'unset';
//     }
//     return () => {
//       document.body.style.overflow = 'unset';
//     };
//   }, [isOpen]);
//   const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
//     const { name, value } = e.target;
//     setFormData(prev => ({
//       ...prev,
//       [name]: name === 'nb_place' || name === 'year' || name === 'vehicle_type' || 
//               name === 'color' || name === 'engine_type' || name === 'model' 
//         ? parseInt(value) 
//         : value
//     }));
//     if (errors[name]) {
//       setErrors(prev => ({ ...prev, [name]: '' }));
//     }
//   };
//   const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
//     const file = e.target.files?.[0];
//     if (file) {
//       if (file.size > 5 * 1024 * 1024) {
//         setErrors(prev => ({ ...prev, image: 'L\'image ne doit pas dépasser 5MB' }));
//         return;
//       }
//       setImageFile(file);
//       const reader = new FileReader();
//       reader.onloadend = () => {
//         setImagePreview(reader.result as string);
//       };
//       reader.readAsDataURL(file);
//     }
//   };
//   const validateForm = () => {
//     const newErrors: Record<string, string> = {};
//     if (!formData.serial_number.trim()) {
//       newErrors.serial_number = 'Le numéro de série est requis';
//     }
//     if (!formData.grey_card.trim()) {
//       newErrors.grey_card = 'La carte grise est requise';
//     }
//     if (formData.nb_place < 1) {
//       newErrors.nb_place = 'Le nombre de places doit être au moins 1';
//     }
//     if (formData.year < 1900 || formData.year > new Date().getFullYear() + 1) {
//       newErrors.year = 'Année invalide';
//     }
//     setErrors(newErrors);
//     return Object.keys(newErrors).length === 0;
//   };
//   const handleSubmit = async (e: React.FormEvent) => {
//     e.preventDefault();
//     if (!validateForm()) {
//       return;
//     }
//     setIsLoading(true);
//     try {
//       const data = new FormData();
//       // Ajouter tous les champs
//       data.append('vehicle_type', String(formData.vehicle_type));
//       data.append('color', String(formData.color));
//       data.append('engine_type', String(formData.engine_type));
//       data.append('model', String(formData.model));
//       data.append('serial_number', formData.serial_number.toUpperCase().trim());
//       data.append('nb_place', String(formData.nb_place));
//       data.append('grey_card', formData.grey_card);
//       data.append('year', String(formData.year));
//       // Ajouter l'image seulement si une nouvelle a été sélectionnée
//       if (imageFile) {
//         data.append('image', imageFile);
//       }
//       console.log('🚗 Envoi PATCH /api/cars/' + car.id + '/');
//       await api.patch(`/api/cars/${car.id}/`, data, {
//         headers: {
//           'Content-Type': 'multipart/form-data',
//         },
//       });
//       alert('✅ Voiture modifiée avec succès !');
//       onSuccess();
//       onClose();
//     } catch (error: unknown) {
//       console.error('❌ Erreur:', error);
//       const err = error as { response?: { data?: Record<string, unknown> } };
//       if (err.response?.data) {
//         const errors = err.response.data;
//         let msg = 'Erreurs:\n';
//         for (const [field, errorMsg] of Object.entries(errors)) {
//           msg += `${field}: ${Array.isArray(errorMsg) ? errorMsg[0] : errorMsg}\n`;
//         }
//         setErrors({ submit: msg });
//       } else {
//         setErrors({ submit: 'Erreur lors de la mise à jour' });
//       }
//     } finally {
//       setIsLoading(false);
//     }
//   };
//   if (!isOpen) return null;
//   return (
//     <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm animate-fadeIn">
//       <div className="bg-white rounded-2xl shadow-2xl w-full max-w-4xl max-h-[90vh] overflow-hidden animate-slideUp">
//         <div className="flex items-center justify-between p-6 border-b border-gray-200 bg-gradient-to-r from-blue-50 to-indigo-50">
//           <div className="flex items-center gap-3">
//             <div className="p-2 bg-blue-500 rounded-lg">
//               <CarIcon className="w-6 h-6 text-white" />
//             </div>
//             <h2 className="text-2xl font-bold text-gray-900">Modifier le véhicule</h2>
//           </div>
//           <button
//             onClick={onClose}
//             className="p-2 hover:bg-gray-100 rounded-full transition-colors"
//           >
//             <X className="w-6 h-6 text-gray-500" />
//           </button>
//         </div>
//         {loadingData ? (
//           <div className="p-8 text-center">
//             <p>Chargement...</p>
//           </div>
//         ) : (
//           <div className="overflow-y-auto max-h-[calc(90vh-140px)]">
//             <div className="p-6 space-y-6">
//               <div className="space-y-3">
//                 <label className="block text-sm font-semibold text-gray-700">
//                   Photo du véhicule
//                 </label>
//                 <div className="flex items-center gap-4">
//                   <div className="relative w-32 h-32 rounded-lg overflow-hidden bg-gray-100 border-2 border-dashed border-gray-300">
//                     {imagePreview ? (
//                       <img
//                         src={imagePreview}
//                         alt="Preview"
//                         className="w-full h-full object-cover"
//                       />
//                     ) : (
//                       <div className="flex items-center justify-center w-full h-full">
//                         <Upload className="w-8 h-8 text-gray-400" />
//                       </div>
//                     )}
//                   </div>
//                   <div className="flex-1">
//                     <input
//                       type="file"
//                       accept="image/*"
//                       onChange={handleImageChange}
//                       className="hidden"
//                       id="image-upload"
//                     />
//                     <label
//                       htmlFor="image-upload"
//                       className="inline-flex items-center gap-2 px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 cursor-pointer transition-colors"
//                     >
//                       <Upload className="w-4 h-4" />
//                       Choisir une image
//                     </label>
//                     <p className="mt-2 text-xs text-gray-500">
//                       PNG, JPG jusqu'à 5MB
//                     </p>
//                     {errors.image && (
//                       <p className="mt-1 text-xs text-red-500">{errors.image}</p>
//                     )}
//                   </div>
//                 </div>
//               </div>
//               <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
//                 <div className="space-y-2">
//                   <label className="block text-sm font-semibold text-gray-700">
//                     Modèle
//                   </label>
//                   <select
//                     name="model"
//                     value={formData.model}
//                     onChange={handleInputChange}
//                     className="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
//                   >
//                     {models.map(model => (
//                       <option key={model.id} value={model.id}>
//                         {model.brand.name} {model.name}
//                       </option>
//                     ))}
//                   </select>
//                 </div>
//                 <div className="space-y-2">
//                   <label className="block text-sm font-semibold text-gray-700">
//                     Type de véhicule
//                   </label>
//                   <select
//                     name="vehicle_type"
//                     value={formData.vehicle_type}
//                     onChange={handleInputChange}
//                     className="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
//                   >
//                     {vehicleTypes.map(type => (
//                       <option key={type.id} value={type.id}>
//                         {type.name}
//                       </option>
//                     ))}
//                   </select>
//                 </div>
//                 <div className="space-y-2">
//                   <label className="block text-sm font-semibold text-gray-700 flex items-center gap-2">
//                     <Palette className="w-4 h-4" />
//                     Couleur
//                   </label>
//                   <select
//                     name="color"
//                     value={formData.color}
//                     onChange={handleInputChange}
//                     className="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
//                   >
//                     {colors.map(color => (
//                       <option key={color.id} value={color.id}>
//                         {color.name}
//                       </option>
//                     ))}
//                   </select>
//                 </div>
//                 <div className="space-y-2">
//                   <label className="block text-sm font-semibold text-gray-700 flex items-center gap-2">
//                     <Fuel className="w-4 h-4" />
//                     Type de moteur
//                   </label>
//                   <select
//                     name="engine_type"
//                     value={formData.engine_type}
//                     onChange={handleInputChange}
//                     className="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
//                   >
//                     {engineTypes.map(type => (
//                       <option key={type.id} value={type.id}>
//                         {type.name}
//                       </option>
//                     ))}
//                   </select>
//                 </div>
//                 <div className="space-y-2">
//                   <label className="block text-sm font-semibold text-gray-700 flex items-center gap-2">
//                     <Hash className="w-4 h-4" />
//                     Numéro de série
//                   </label>
//                   <input
//                     type="text"
//                     name="serial_number"
//                     value={formData.serial_number}
//                     onChange={handleInputChange}
//                     className={`w-full px-4 py-2.5 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all ${
//                       errors.serial_number ? 'border-red-500' : 'border-gray-300'
//                     }`}
//                     placeholder="ex: ABC123XYZ"
//                   />
//                   {errors.serial_number && (
//                     <p className="text-xs text-red-500">{errors.serial_number}</p>
//                   )}
//                 </div>
//                 <div className="space-y-2">
//                   <label className="block text-sm font-semibold text-gray-700 flex items-center gap-2">
//                     <FileText className="w-4 h-4" />
//                     Carte grise
//                   </label>
//                   <input
//                     type="text"
//                     name="grey_card"
//                     value={formData.grey_card}
//                     onChange={handleInputChange}
//                     className={`w-full px-4 py-2.5 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all ${
//                       errors.grey_card ? 'border-red-500' : 'border-gray-300'
//                     }`}
//                     placeholder="Numéro de carte grise"
//                   />
//                   {errors.grey_card && (
//                     <p className="text-xs text-red-500">{errors.grey_card}</p>
//                   )}
//                 </div>
//                 <div className="space-y-2">
//                   <label className="block text-sm font-semibold text-gray-700">
//                     Nombre de places
//                   </label>
//                   <input
//                     type="number"
//                     name="nb_place"
//                     value={formData.nb_place}
//                     onChange={handleInputChange}
//                     min="1"
//                     max="50"
//                     className={`w-full px-4 py-2.5 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all ${
//                       errors.nb_place ? 'border-red-500' : 'border-gray-300'
//                     }`}
//                   />
//                   {errors.nb_place && (
//                     <p className="text-xs text-red-500">{errors.nb_place}</p>
//                   )}
//                 </div>
//                 <div className="space-y-2">
//                   <label className="block text-sm font-semibold text-gray-700 flex items-center gap-2">
//                     <Calendar className="w-4 h-4" />
//                     Année
//                   </label>
//                   <input
//                     type="number"
//                     name="year"
//                     value={formData.year}
//                     onChange={handleInputChange}
//                     min="1900"
//                     max={new Date().getFullYear() + 1}
//                     className={`w-full px-4 py-2.5 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all ${
//                       errors.year ? 'border-red-500' : 'border-gray-300'
//                     }`}
//                   />
//                   {errors.year && (
//                     <p className="text-xs text-red-500">{errors.year}</p>
//                   )}
//                 </div>
//               </div>
//               {errors.submit && (
//                 <div className="p-4 bg-red-50 border border-red-200 rounded-lg">
//                   <p className="text-sm text-red-600 whitespace-pre-wrap">{errors.submit}</p>
//                 </div>
//               )}
//             </div>
//             <div className="flex gap-3 p-6 border-t border-gray-200 bg-gray-50">
//               <button
//                 type="button"
//                 onClick={onClose}
//                 className="flex-1 px-6 py-3 text-gray-700 bg-white border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors font-medium"
//               >
//                 Annuler
//               </button>
//               <button
//                 type="button"
//                 onClick={handleSubmit}
//                 disabled={isLoading}
//                 className="flex-1 px-6 py-3 text-white bg-blue-500 rounded-lg hover:bg-blue-600 transition-colors font-medium disabled:opacity-50 disabled:cursor-not-allowed"
//               >
//                 {isLoading ? 'Enregistrement...' : 'Enregistrer'}
//               </button>
//             </div>
//           </div>
//         )}
//       </div>
//       <style>{`
//         @keyframes fadeIn {
//           from { opacity: 0; }
//           to { opacity: 1; }
//         }
//         @keyframes slideUp {
//           from { 
//             opacity: 0;
//             transform: translateY(20px);
//           }
//           to { 
//             opacity: 1;
//             transform: translateY(0);
//           }
//         }
//         .animate-fadeIn {
//           animation: fadeIn 0.2s ease-out;
//         }
//         .animate-slideUp {
//           animation: slideUp 0.3s ease-out;
//         }
//       `}</style>
//     </div>
//   );
// }
// src/components/profile/EditCarModal.tsx
__turbopack_context__.s({
    "default": ()=>EditCarModal
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$api$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/api/api.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$profile$2f$Toast$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/profile/Toast.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
;
;
;
function EditCarModal(param) {
    let { car, isOpen, onClose, onSuccess } = param;
    _s();
    const [formData, setFormData] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({
        vehicle_type: car.vehicle_type,
        color: car.color,
        engine_type: car.engine_type,
        model: car.model,
        serial_number: car.serial_number,
        nb_place: car.nb_place,
        grey_card: car.grey_card,
        year: car.year,
        image: car.image || ''
    });
    const [imageFile, setImageFile] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [imagePreview, setImagePreview] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(car.image || '');
    const [errors, setErrors] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({});
    const [isLoading, setIsLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    // États pour stocker les données depuis l'API
    const [vehicleTypes, setVehicleTypes] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [colors, setColors] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [engineTypes, setEngineTypes] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [models, setModels] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [loadingData, setLoadingData] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(true);
    // NOUVEAU : État pour le toast
    const [toast, setToast] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    // ... (garder tous les useEffect et fonctions existantes)
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "EditCarModal.useEffect": ()=>{
            const fetchData = {
                "EditCarModal.useEffect.fetchData": async ()=>{
                    if (!isOpen) return;
                    setLoadingData(true);
                    try {
                        const [vehicleTypesRes, colorsRes, engineTypesRes, modelsRes] = await Promise.all([
                            __TURBOPACK__imported__module__$5b$project$5d2f$api$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].get('/api/vehicle-types/'),
                            __TURBOPACK__imported__module__$5b$project$5d2f$api$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].get('/api/colors/'),
                            __TURBOPACK__imported__module__$5b$project$5d2f$api$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].get('/api/engine-types/'),
                            __TURBOPACK__imported__module__$5b$project$5d2f$api$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].get('/api/models/')
                        ]);
                        setVehicleTypes(vehicleTypesRes.data);
                        setColors(colorsRes.data);
                        setEngineTypes(engineTypesRes.data);
                        setModels(modelsRes.data);
                    } catch (error) {
                        console.error('Erreur lors du chargement des données:', error);
                        setErrors({
                            submit: 'Erreur lors du chargement des données'
                        });
                    } finally{
                        setLoadingData(false);
                    }
                }
            }["EditCarModal.useEffect.fetchData"];
            fetchData();
        }
    }["EditCarModal.useEffect"], [
        isOpen
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "EditCarModal.useEffect": ()=>{
            if (isOpen) {
                document.body.style.overflow = 'hidden';
            } else {
                document.body.style.overflow = 'unset';
            }
            return ({
                "EditCarModal.useEffect": ()=>{
                    document.body.style.overflow = 'unset';
                }
            })["EditCarModal.useEffect"];
        }
    }["EditCarModal.useEffect"], [
        isOpen
    ]);
    const handleInputChange = (e)=>{
        const { name, value } = e.target;
        setFormData((prev)=>({
                ...prev,
                [name]: name === 'nb_place' || name === 'year' || name === 'vehicle_type' || name === 'color' || name === 'engine_type' || name === 'model' ? parseInt(value) : value
            }));
        if (errors[name]) {
            setErrors((prev)=>({
                    ...prev,
                    [name]: ''
                }));
        }
    };
    const handleImageChange = (e)=>{
        var _e_target_files;
        const file = (_e_target_files = e.target.files) === null || _e_target_files === void 0 ? void 0 : _e_target_files[0];
        if (file) {
            if (file.size > 5 * 1024 * 1024) {
                setErrors((prev)=>({
                        ...prev,
                        image: 'L\'image ne doit pas dépasser 5MB'
                    }));
                return;
            }
            setImageFile(file);
            const reader = new FileReader();
            reader.onloadend = ()=>{
                setImagePreview(reader.result);
            };
            reader.readAsDataURL(file);
        }
    };
    const validateForm = ()=>{
        const newErrors = {};
        if (!formData.serial_number.trim()) {
            newErrors.serial_number = 'Le numéro de série est requis';
        }
        if (!formData.grey_card.trim()) {
            newErrors.grey_card = 'La carte grise est requise';
        }
        if (formData.nb_place < 1) {
            newErrors.nb_place = 'Le nombre de places doit être au moins 1';
        }
        if (formData.year < 1900 || formData.year > new Date().getFullYear() + 1) {
            newErrors.year = 'Année invalide';
        }
        setErrors(newErrors);
        return Object.keys(newErrors).length === 0;
    };
    const handleSubmit = async (e)=>{
        e.preventDefault();
        if (!validateForm()) {
            return;
        }
        setIsLoading(true);
        try {
            const data = new FormData();
            data.append('vehicle_type', String(formData.vehicle_type));
            data.append('color', String(formData.color));
            data.append('engine_type', String(formData.engine_type));
            data.append('model', String(formData.model));
            data.append('serial_number', formData.serial_number.toUpperCase().trim());
            data.append('nb_place', String(formData.nb_place));
            data.append('grey_card', formData.grey_card);
            data.append('year', String(formData.year));
            if (imageFile) {
                data.append('image', imageFile);
            }
            await __TURBOPACK__imported__module__$5b$project$5d2f$api$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].patch("/api/cars/".concat(car.id, "/"), data, {
                headers: {
                    'Content-Type': 'multipart/form-data'
                }
            });
            // REMPLACER alert() par Toast
            setToast({
                message: '✅ Voiture modifiée avec succès !',
                type: 'success'
            });
            // Attendre un peu avant de fermer pour que l'utilisateur voie le toast
            setTimeout(()=>{
                onSuccess();
                onClose();
            }, 1500);
        } catch (error) {
            var _err_response;
            console.error('❌ Erreur:', error);
            const err = error;
            if ((_err_response = err.response) === null || _err_response === void 0 ? void 0 : _err_response.data) {
                const errors = err.response.data;
                let msg = 'Erreurs:\n';
                for (const [field, errorMsg] of Object.entries(errors)){
                    msg += "".concat(field, ": ").concat(Array.isArray(errorMsg) ? errorMsg[0] : errorMsg, "\n");
                }
                setErrors({
                    submit: msg
                });
            } else {
                setErrors({
                    submit: 'Erreur lors de la mise à jour'
                });
            }
        } finally{
            setIsLoading(false);
        }
    };
    if (!isOpen) return null;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            toast && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$profile$2f$Toast$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                message: toast.message,
                type: toast.type,
                onClose: ()=>setToast(null)
            }, void 0, false, {
                fileName: "[project]/components/profile/EditCarModal.tsx",
                lineNumber: 757,
                columnNumber: 9
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm animate-fadeIn",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "bg-white rounded-2xl shadow-2xl w-full max-w-4xl max-h-[90vh] overflow-hidden animate-slideUp"
                }, void 0, false, {
                    fileName: "[project]/components/profile/EditCarModal.tsx",
                    lineNumber: 766,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/components/profile/EditCarModal.tsx",
                lineNumber: 764,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true);
}
_s(EditCarModal, "fOtKZvc70aw2drWRfiHTp1QGyb8=");
_c = EditCarModal;
var _c;
__turbopack_context__.k.register(_c, "EditCarModal");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/components/profile/CarCard.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
// import Image from "next/image";
// export interface Car {
//   id: number;
//   brand: string;
//   model: string;
//   year: number | string; // ✅ Accepte number OU string
//   color: string;
//   seats: number;
//   fuelType: string;
//   licensePlate: string;
//   image: string;
// }
// interface CarCardProps {
//   car: Car;
//   onEdit?: (car: Car) => void;
//   onRemove?: (carId: number) => void;
//   className?: string;
// }
// export default function CarCard({
//   car,
//   onEdit,
//   onRemove,
//   className = "",
// }: CarCardProps) {
//   return (
//     <div
//       className={`border border-gray-200 rounded-xl p-6 hover:shadow-md transition ${className}`}
//     >
//       <div className="aspect-video rounded-lg overflow-hidden mb-4 bg-gray-100">
//         <Image
//           src={
//             car.image
//               ? car.image
//               : "https://t3.ftcdn.net/jpg/01/71/13/24/360_F_171132449_uK0OO5XHrjjaqx5JUbJOIoCC3GZP84Mt.jpg"
//           }
//           alt={`${car.brand} ${car.model}`}
//           width={400}
//           height={225}
//           className="w-full h-full object-cover"
//         /> */{"}"}
//       </div>
//       <div className="space-y-3">
//         <div>
//           <h3 className="font-bold text-lg text-gray-900">
//             {car.brand} {car.model}
//           </h3>
//           <p className="text-gray-600 text-sm">
//             {car.year} • {car.color}
//           </p>
//         </div>
//         <div className="flex items-center gap-4 text-sm text-gray-600">
//           <div className="flex items-center gap-1">
//             <span>👥</span>
//             <span>{car.seats} places</span>
//           </div>
//           <div className="flex items-center gap-1">
//             <span>⛽</span>
//             <span>{car.fuelType}</span>
//           </div>
//         </div>
//         <div className="text-sm text-gray-600">
//           <span className="font-medium">Immatriculation:</span> {car.licensePlate}
//         </div>
//         <div className="flex gap-2 pt-2">
//           <button
//             onClick={() => onEdit?.(car)}
//             className="flex-1 px-4 py-2 text-gray-700 border border-gray-300 rounded-lg hover:bg-gray-50 transition text-sm font-medium"
//           >
//             Modifier
//           </button>
//           <button
//             onClick={() => onRemove?.(car.id)}
//             className="flex-1 px-4 py-2 text-gray-700 border border-gray-300 rounded-lg hover:bg-gray-50 transition text-sm font-medium"
//           >
//             Supprimer
//           </button>
//         </div>
//       </div>
//     </div>
//   );
// }
// src/components/profile/CarCard.tsx
__turbopack_context__.s({
    "default": ()=>CarCard
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/image.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$profile$2f$EditCarModal$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/profile/EditCarModal.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$api$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/api/api.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
;
;
;
;
function CarCard(param) {
    let { car, onEdit, onRemove, className = "" } = param;
    _s();
    const [isModalOpen, setIsModalOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [isDeleting, setIsDeleting] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    // Ouvrir le modal
    const handleEditClick = ()=>{
        console.log("🔧 Ouverture du modal pour:", car);
        setIsModalOpen(true);
    };
    // Callback après succès de modification
    const handleSuccess = ()=>{
        console.log("✅ Modification réussie");
        if (onEdit) {
            onEdit(car);
        }
        // Recharger la page pour voir les changements
        window.location.reload();
    };
    // Supprimer la voiture
    const handleRemoveClick = async ()=>{
        if (!window.confirm('Êtes-vous sûr de vouloir supprimer ce véhicule ?')) {
            return;
        }
        setIsDeleting(true);
        try {
            await __TURBOPACK__imported__module__$5b$project$5d2f$api$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].delete("/api/cars/".concat(car.id, "/"));
            alert('✅ Voiture supprimée avec succès !');
            if (onRemove) {
                onRemove(car.id);
            }
            window.location.reload();
        } catch (error) {
            console.error('❌ Erreur:', error);
            alert('❌ Erreur lors de la suppression du véhicule');
        } finally{
            setIsDeleting(false);
        }
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "border border-gray-200 rounded-xl p-6 hover:shadow-md transition ".concat(className),
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "aspect-video rounded-lg overflow-hidden mb-4 bg-gray-100",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            src: car.image ? car.image : "https://t3.ftcdn.net/jpg/01/71/13/24/360_F_171132449_uK0OO5XHrjjaqx5JUbJOIoCC3GZP84Mt.jpg",
                            alt: "".concat(car.brand, " ").concat(car.model),
                            width: 400,
                            height: 225,
                            className: "w-full h-full object-cover"
                        }, void 0, false, {
                            fileName: "[project]/components/profile/CarCard.tsx",
                            lineNumber: 188,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/components/profile/CarCard.tsx",
                        lineNumber: 187,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "space-y-3",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                        className: "font-bold text-lg text-gray-900",
                                        children: [
                                            car.brand,
                                            " ",
                                            car.model
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/components/profile/CarCard.tsx",
                                        lineNumber: 203,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "text-gray-600 text-sm",
                                        children: [
                                            car.year,
                                            " • ",
                                            car.color
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/components/profile/CarCard.tsx",
                                        lineNumber: 206,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/components/profile/CarCard.tsx",
                                lineNumber: 202,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex items-center gap-4 text-sm text-gray-600",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "flex items-center gap-1",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                children: "👥"
                                            }, void 0, false, {
                                                fileName: "[project]/components/profile/CarCard.tsx",
                                                lineNumber: 213,
                                                columnNumber: 15
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                children: [
                                                    car.seats,
                                                    " places"
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/components/profile/CarCard.tsx",
                                                lineNumber: 214,
                                                columnNumber: 15
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/components/profile/CarCard.tsx",
                                        lineNumber: 212,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "flex items-center gap-1",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                children: "⛽"
                                            }, void 0, false, {
                                                fileName: "[project]/components/profile/CarCard.tsx",
                                                lineNumber: 217,
                                                columnNumber: 15
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                children: car.fuelType
                                            }, void 0, false, {
                                                fileName: "[project]/components/profile/CarCard.tsx",
                                                lineNumber: 218,
                                                columnNumber: 15
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/components/profile/CarCard.tsx",
                                        lineNumber: 216,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/components/profile/CarCard.tsx",
                                lineNumber: 211,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "text-sm text-gray-600",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "font-medium",
                                        children: "Immatriculation:"
                                    }, void 0, false, {
                                        fileName: "[project]/components/profile/CarCard.tsx",
                                        lineNumber: 223,
                                        columnNumber: 13
                                    }, this),
                                    " ",
                                    car.licensePlate
                                ]
                            }, void 0, true, {
                                fileName: "[project]/components/profile/CarCard.tsx",
                                lineNumber: 222,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex gap-2 pt-2",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        onClick: handleEditClick,
                                        className: "flex-1 px-4 py-2 text-blue-600 border border-blue-300 rounded-lg hover:bg-blue-50 transition text-sm font-medium",
                                        children: "Modifier"
                                    }, void 0, false, {
                                        fileName: "[project]/components/profile/CarCard.tsx",
                                        lineNumber: 227,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        onClick: handleRemoveClick,
                                        disabled: isDeleting,
                                        className: "flex-1 px-4 py-2 text-red-600 border border-red-300 rounded-lg hover:bg-red-50 transition text-sm font-medium disabled:opacity-50",
                                        children: isDeleting ? 'Suppression...' : 'Supprimer'
                                    }, void 0, false, {
                                        fileName: "[project]/components/profile/CarCard.tsx",
                                        lineNumber: 233,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/components/profile/CarCard.tsx",
                                lineNumber: 226,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/profile/CarCard.tsx",
                        lineNumber: 201,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/profile/CarCard.tsx",
                lineNumber: 184,
                columnNumber: 7
            }, this),
            isModalOpen && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$profile$2f$EditCarModal$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                car: {
                    id: car.id,
                    vehicle_type: car.vehicle_type || 1,
                    color: car.color_id || 1,
                    engine_type: car.engine_type || 1,
                    model: car.model_id || 1,
                    serial_number: car.serial_number || car.licensePlate,
                    nb_place: car.nb_place || car.seats,
                    grey_card: car.grey_card || '',
                    year: typeof car.year === 'string' ? parseInt(car.year) : car.year,
                    image: car.image
                },
                isOpen: isModalOpen,
                onClose: ()=>{
                    console.log("🚪 Fermeture du modal");
                    setIsModalOpen(false);
                },
                onSuccess: handleSuccess
            }, void 0, false, {
                fileName: "[project]/components/profile/CarCard.tsx",
                lineNumber: 246,
                columnNumber: 9
            }, this)
        ]
    }, void 0, true);
}
_s(CarCard, "qtK9r3x2CA93XlqDX8c2e3gMS9E=");
_c = CarCard;
var _c;
__turbopack_context__.k.register(_c, "CarCard");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/components/profile/CarsSection.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": ()=>CarsSection
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$profile$2f$CarCard$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/profile/CarCard.tsx [app-client] (ecmascript)");
;
;
function CarsSection(param) {
    let { cars, onAddCar, onEditCar, onRemoveCar, className = "" } = param;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "bg-white rounded-2xl shadow-xl p-8 mt-8 ".concat(className),
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex justify-between items-center mb-6",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                        className: "text-2xl font-bold text-gray-900",
                        children: "Mes voitures"
                    }, void 0, false, {
                        fileName: "[project]/components/profile/CarsSection.tsx",
                        lineNumber: 21,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        onClick: onAddCar,
                        className: "px-6 py-3 bg-black text-white rounded-xl hover:bg-gray-800 transition font-semibold flex items-center gap-2",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "text-lg",
                                children: "+"
                            }, void 0, false, {
                                fileName: "[project]/components/profile/CarsSection.tsx",
                                lineNumber: 26,
                                columnNumber: 11
                            }, this),
                            "Ajouter une nouvelle voiture"
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/profile/CarsSection.tsx",
                        lineNumber: 22,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/profile/CarsSection.tsx",
                lineNumber: 20,
                columnNumber: 7
            }, this),
            cars.length === 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "text-center py-12",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "text-gray-400 text-6xl mb-4",
                        children: "🚗"
                    }, void 0, false, {
                        fileName: "[project]/components/profile/CarsSection.tsx",
                        lineNumber: 33,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                        className: "text-xl font-semibold text-gray-900 mb-2",
                        children: "Aucune voiture ajoutée pour le moment"
                    }, void 0, false, {
                        fileName: "[project]/components/profile/CarsSection.tsx",
                        lineNumber: 34,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "text-gray-600 mb-6",
                        children: "Ajoutez votre première voiture pour commencer à proposer des trajets"
                    }, void 0, false, {
                        fileName: "[project]/components/profile/CarsSection.tsx",
                        lineNumber: 37,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        onClick: onAddCar,
                        className: "px-6 py-3 bg-black text-white rounded-xl hover:bg-gray-800 transition font-semibold",
                        children: "Ajouter votre première voiture"
                    }, void 0, false, {
                        fileName: "[project]/components/profile/CarsSection.tsx",
                        lineNumber: 40,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/profile/CarsSection.tsx",
                lineNumber: 32,
                columnNumber: 9
            }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6",
                children: cars.map((car)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$profile$2f$CarCard$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        car: car,
                        onEdit: onEditCar,
                        onRemove: onRemoveCar
                    }, car.id, false, {
                        fileName: "[project]/components/profile/CarsSection.tsx",
                        lineNumber: 50,
                        columnNumber: 13
                    }, this))
            }, void 0, false, {
                fileName: "[project]/components/profile/CarsSection.tsx",
                lineNumber: 48,
                columnNumber: 9
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/components/profile/CarsSection.tsx",
        lineNumber: 19,
        columnNumber: 5
    }, this);
}
_c = CarsSection;
var _c;
__turbopack_context__.k.register(_c, "CarsSection");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/components/AddCarModal.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": ()=>AddCarModal
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/image.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$api$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/api/api.ts [app-client] (ecmascript)"); // ✅ Importez l'API directement
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
function AddCarModal(param) {
    let { isOpen, onClose, onSubmit } = param;
    _s();
    const [formData, setFormData] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({
        model: "",
        vehicle_type: "",
        color: "",
        serial_number: "",
        nb_place: 5,
        engine_type: "",
        grey_card: "",
        year: new Date().getFullYear(),
        image: null
    });
    const [imagePreview, setImagePreview] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [loading, setLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [error, setError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    // Data from backend
    const [models, setModels] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [brands, setBrands] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [vehicleTypes, setVehicleTypes] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [colors, setColors] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [engineTypes, setEngineTypes] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [loadingData, setLoadingData] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(true);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "AddCarModal.useEffect": ()=>{
            if (isOpen) {
                console.log("✅ Modal opened, fetching data...");
                fetchAllData();
            }
        }
    }["AddCarModal.useEffect"], [
        isOpen
    ]);
    const fetchAllData = async ()=>{
        try {
            setLoadingData(true);
            setError(""); // Réinitialiser l'erreur
            console.log("🔄 Fetching data from API...");
            const [modelsRes, brandsRes, vehicleTypesRes, colorsRes, engineTypesRes] = await Promise.all([
                __TURBOPACK__imported__module__$5b$project$5d2f$api$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].get("/api/models/"),
                __TURBOPACK__imported__module__$5b$project$5d2f$api$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].get("/api/brands/"),
                __TURBOPACK__imported__module__$5b$project$5d2f$api$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].get("/api/vehicle-types/"),
                __TURBOPACK__imported__module__$5b$project$5d2f$api$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].get("/api/colors/"),
                __TURBOPACK__imported__module__$5b$project$5d2f$api$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].get("/api/engine-types/")
            ]);
            const modelsList = modelsRes.data.results || modelsRes.data || [];
            const brandsList = brandsRes.data.results || brandsRes.data || [];
            const vehicleTypesList = vehicleTypesRes.data.results || vehicleTypesRes.data || [];
            const colorsList = colorsRes.data.results || colorsRes.data || [];
            const engineTypesList = engineTypesRes.data.results || engineTypesRes.data || [];
            console.log("✅ Models loaded:", modelsList);
            console.log("✅ Brands loaded:", brandsList);
            console.log("✅ Vehicle Types loaded:", vehicleTypesList);
            console.log("✅ Colors loaded:", colorsList);
            console.log("✅ Engine Types loaded:", engineTypesList);
            setModels(modelsList);
            setBrands(brandsList);
            setVehicleTypes(vehicleTypesList);
            setColors(colorsList);
            setEngineTypes(engineTypesList);
            // Set default values
            if (modelsList.length > 0) {
                setFormData((prev)=>({
                        ...prev,
                        model: String(modelsList[0].id)
                    }));
            }
            if (vehicleTypesList.length > 0) {
                setFormData((prev)=>({
                        ...prev,
                        vehicle_type: String(vehicleTypesList[0].id)
                    }));
            }
            if (colorsList.length > 0) {
                setFormData((prev)=>({
                        ...prev,
                        color: String(colorsList[0].id)
                    }));
            }
            if (engineTypesList.length > 0) {
                setFormData((prev)=>({
                        ...prev,
                        engine_type: String(engineTypesList[0].id)
                    }));
            }
        } catch (err) {
            var _error_response, _error_response1, _error_response_data, _error_response2, _error_response_data1, _error_response3;
            console.error("❌ Error fetching data:", err);
            // ✅ Type casting pour accéder aux propriétés
            const error = err;
            console.error("❌ Error details:", (_error_response = error.response) === null || _error_response === void 0 ? void 0 : _error_response.data);
            console.error("❌ Error status:", (_error_response1 = error.response) === null || _error_response1 === void 0 ? void 0 : _error_response1.status);
            const errorMessage = ((_error_response2 = error.response) === null || _error_response2 === void 0 ? void 0 : (_error_response_data = _error_response2.data) === null || _error_response_data === void 0 ? void 0 : _error_response_data.detail) || ((_error_response3 = error.response) === null || _error_response3 === void 0 ? void 0 : (_error_response_data1 = _error_response3.data) === null || _error_response_data1 === void 0 ? void 0 : _error_response_data1.message) || error.message || "Failed to load data. Please check your connection and try again.";
            setError(errorMessage);
        } finally{
            setLoadingData(false);
        }
    };
    const handleSubmit = async (e)=>{
        e.preventDefault();
        setError("");
        setLoading(true);
        console.log("=== 🚗 SUBMITTING CAR ===");
        console.log("formData:", formData);
        // Validation stricte
        if (!formData.model || formData.model === "") {
            setError("Please select a car model");
            setLoading(false);
            return;
        }
        if (!formData.vehicle_type || formData.vehicle_type === "") {
            setError("Please select a vehicle type");
            setLoading(false);
            return;
        }
        if (!formData.color || formData.color === "") {
            setError("Please select a color");
            setLoading(false);
            return;
        }
        if (!formData.engine_type || formData.engine_type === "") {
            setError("Please select an engine type");
            setLoading(false);
            return;
        }
        if (!formData.serial_number || formData.serial_number.trim() === "") {
            setError("Please enter a serial number");
            setLoading(false);
            return;
        }
        if (!formData.grey_card || formData.grey_card.trim() === "") {
            setError("Please enter a grey card number");
            setLoading(false);
            return;
        }
        const data = new FormData();
        data.append("model", String(formData.model));
        data.append("vehicle_type", String(formData.vehicle_type));
        data.append("color", String(formData.color));
        data.append("engine_type", String(formData.engine_type));
        data.append("serial_number", formData.serial_number.trim());
        data.append("nb_place", String(formData.nb_place));
        data.append("grey_card", formData.grey_card.trim());
        data.append("year", String(formData.year));
        data.append("is_active", "true");
        if (formData.image) {
            data.append("image", formData.image);
        }
        // Log du FormData
        console.log("📤 FormData being sent:");
        for (const [key, value] of data.entries()){
            console.log("  ".concat(key, ":"), value);
        }
        try {
            const res = await __TURBOPACK__imported__module__$5b$project$5d2f$api$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].post("/api/cars/", data, {
                headers: {
                    'Content-Type': 'multipart/form-data'
                }
            });
            console.log("✅ Car created successfully:", res.data);
            onSubmit(res.data);
            handleClose();
        } catch (err) {
            var _error_response, _error_response1;
            console.error("❌ Error creating car:", err);
            // ✅ Type casting pour accéder aux propriétés
            const error = err;
            console.error("❌ Error response:", (_error_response = error.response) === null || _error_response === void 0 ? void 0 : _error_response.data);
            if ((_error_response1 = error.response) === null || _error_response1 === void 0 ? void 0 : _error_response1.data) {
                const errors = error.response.data;
                if (typeof errors === 'object') {
                    const errorMessages = Object.entries(errors).map((param)=>{
                        let [key, value] = param;
                        return "".concat(key, ": ").concat(Array.isArray(value) ? value.join(', ') : value);
                    }).join('\n');
                    setError(errorMessages);
                } else {
                    setError(String(errors));
                }
            } else {
                setError("An error occurred. Please try again.");
            }
        } finally{
            setLoading(false);
        }
    };
    const handleClose = ()=>{
        setFormData({
            model: models.length > 0 ? String(models[0].id) : "",
            vehicle_type: vehicleTypes.length > 0 ? String(vehicleTypes[0].id) : "",
            color: colors.length > 0 ? String(colors[0].id) : "",
            serial_number: "",
            nb_place: 5,
            engine_type: engineTypes.length > 0 ? String(engineTypes[0].id) : "",
            grey_card: "",
            year: new Date().getFullYear(),
            image: null
        });
        setImagePreview("");
        setError("");
        onClose();
    };
    const handleImageChange = (e)=>{
        var _e_target_files;
        const file = (_e_target_files = e.target.files) === null || _e_target_files === void 0 ? void 0 : _e_target_files[0];
        if (file) {
            if (file.size > 5 * 1024 * 1024) {
                setError("Image size must be less than 5MB");
                return;
            }
            setFormData({
                ...formData,
                image: file
            });
            setImagePreview(URL.createObjectURL(file));
            setError("");
        }
    };
    const getBrandName = (brandId)=>{
        var _brands_find;
        return ((_brands_find = brands.find((b)=>b.id === brandId)) === null || _brands_find === void 0 ? void 0 : _brands_find.name) || "";
    };
    if (!isOpen) return null;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "bg-white rounded-2xl shadow-2xl max-w-3xl w-full max-h-[90vh] overflow-y-auto",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "p-6 border-b border-gray-200",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex justify-between items-center",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                className: "text-2xl font-bold text-gray-900",
                                children: "Add New Car"
                            }, void 0, false, {
                                fileName: "[project]/components/AddCarModal.tsx",
                                lineNumber: 301,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                onClick: handleClose,
                                className: "text-gray-400 hover:text-gray-600 text-2xl",
                                type: "button",
                                children: "×"
                            }, void 0, false, {
                                fileName: "[project]/components/AddCarModal.tsx",
                                lineNumber: 302,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/AddCarModal.tsx",
                        lineNumber: 300,
                        columnNumber: 11
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/components/AddCarModal.tsx",
                    lineNumber: 299,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "p-6 space-y-6",
                    children: [
                        error && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "p-4 bg-red-50 border border-red-200 rounded-lg",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "text-sm text-red-600 whitespace-pre-line",
                                    children: error
                                }, void 0, false, {
                                    fileName: "[project]/components/AddCarModal.tsx",
                                    lineNumber: 315,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    onClick: fetchAllData,
                                    className: "mt-2 text-sm text-blue-600 hover:text-blue-800 underline",
                                    children: "Try again"
                                }, void 0, false, {
                                    fileName: "[project]/components/AddCarModal.tsx",
                                    lineNumber: 316,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/components/AddCarModal.tsx",
                            lineNumber: 314,
                            columnNumber: 13
                        }, this),
                        loadingData ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "text-center py-8",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "inline-block animate-spin rounded-full h-8 w-8 border-b-2 border-gray-900"
                                }, void 0, false, {
                                    fileName: "[project]/components/AddCarModal.tsx",
                                    lineNumber: 327,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "mt-2 text-gray-500",
                                    children: "Loading data..."
                                }, void 0, false, {
                                    fileName: "[project]/components/AddCarModal.tsx",
                                    lineNumber: 328,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/components/AddCarModal.tsx",
                            lineNumber: 326,
                            columnNumber: 13
                        }, this) : models.length === 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "p-4 bg-yellow-50 border border-yellow-200 rounded-lg",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "text-sm text-yellow-800",
                                    children: "⚠️ No car models available. Please add at least one brand and model in the admin panel at:"
                                }, void 0, false, {
                                    fileName: "[project]/components/AddCarModal.tsx",
                                    lineNumber: 332,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                    href: "http://localhost:8000/admin",
                                    target: "_blank",
                                    rel: "noopener noreferrer",
                                    className: "text-blue-600 hover:text-blue-800 underline text-sm mt-2 inline-block",
                                    children: "http://localhost:8000/admin"
                                }, void 0, false, {
                                    fileName: "[project]/components/AddCarModal.tsx",
                                    lineNumber: 335,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/components/AddCarModal.tsx",
                            lineNumber: 331,
                            columnNumber: 13
                        }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("form", {
                            onSubmit: handleSubmit,
                            className: "space-y-6",
                            children: [
                                imagePreview && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "flex justify-center",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "w-64 h-36 rounded-lg overflow-hidden bg-gray-100 relative",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                            src: imagePreview,
                                            alt: "Car preview",
                                            fill: true,
                                            className: "object-cover"
                                        }, void 0, false, {
                                            fileName: "[project]/components/AddCarModal.tsx",
                                            lineNumber: 349,
                                            columnNumber: 21
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/components/AddCarModal.tsx",
                                        lineNumber: 348,
                                        columnNumber: 19
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/components/AddCarModal.tsx",
                                    lineNumber: 347,
                                    columnNumber: 17
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "grid grid-cols-1 md:grid-cols-2 gap-4",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "md:col-span-2",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                    className: "block text-sm font-medium text-gray-700 mb-2",
                                                    children: [
                                                        "Car Model * ",
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                            className: "text-xs text-gray-500"
                                                        }, void 0, false, {
                                                            fileName: "[project]/components/AddCarModal.tsx",
                                                            lineNumber: 363,
                                                            columnNumber: 33
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/components/AddCarModal.tsx",
                                                    lineNumber: 362,
                                                    columnNumber: 19
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                                                    required: true,
                                                    value: formData.model,
                                                    onChange: (e)=>{
                                                        console.log("✅ Model selected:", e.target.value);
                                                        setFormData({
                                                            ...formData,
                                                            model: e.target.value
                                                        });
                                                    },
                                                    className: "w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-gray-500 focus:border-transparent",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                            value: "",
                                                            children: "-- Select a model --"
                                                        }, void 0, false, {
                                                            fileName: "[project]/components/AddCarModal.tsx",
                                                            lineNumber: 374,
                                                            columnNumber: 21
                                                        }, this),
                                                        models.map((model)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                                value: model.id,
                                                                children: [
                                                                    getBrandName(model.brand),
                                                                    " ",
                                                                    model.name
                                                                ]
                                                            }, model.id, true, {
                                                                fileName: "[project]/components/AddCarModal.tsx",
                                                                lineNumber: 376,
                                                                columnNumber: 23
                                                            }, this))
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/components/AddCarModal.tsx",
                                                    lineNumber: 365,
                                                    columnNumber: 19
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/components/AddCarModal.tsx",
                                            lineNumber: 361,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                    className: "block text-sm font-medium text-gray-700 mb-2",
                                                    children: [
                                                        "Vehicle Type * ",
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                            className: "text-xs text-gray-500"
                                                        }, void 0, false, {
                                                            fileName: "[project]/components/AddCarModal.tsx",
                                                            lineNumber: 386,
                                                            columnNumber: 36
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/components/AddCarModal.tsx",
                                                    lineNumber: 385,
                                                    columnNumber: 19
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                                                    required: true,
                                                    value: formData.vehicle_type,
                                                    onChange: (e)=>setFormData({
                                                            ...formData,
                                                            vehicle_type: e.target.value
                                                        }),
                                                    className: "w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-gray-500 focus:border-transparent",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                            value: "",
                                                            children: "-- Select a type --"
                                                        }, void 0, false, {
                                                            fileName: "[project]/components/AddCarModal.tsx",
                                                            lineNumber: 394,
                                                            columnNumber: 21
                                                        }, this),
                                                        vehicleTypes.map((type)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                                value: type.id,
                                                                children: type.name
                                                            }, type.id, false, {
                                                                fileName: "[project]/components/AddCarModal.tsx",
                                                                lineNumber: 396,
                                                                columnNumber: 23
                                                            }, this))
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/components/AddCarModal.tsx",
                                                    lineNumber: 388,
                                                    columnNumber: 19
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/components/AddCarModal.tsx",
                                            lineNumber: 384,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                    className: "block text-sm font-medium text-gray-700 mb-2",
                                                    children: [
                                                        "Color * ",
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                            className: "text-xs text-gray-500"
                                                        }, void 0, false, {
                                                            fileName: "[project]/components/AddCarModal.tsx",
                                                            lineNumber: 406,
                                                            columnNumber: 29
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/components/AddCarModal.tsx",
                                                    lineNumber: 405,
                                                    columnNumber: 19
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                                                    required: true,
                                                    value: formData.color,
                                                    onChange: (e)=>setFormData({
                                                            ...formData,
                                                            color: e.target.value
                                                        }),
                                                    className: "w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-gray-500 focus:border-transparent",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                            value: "",
                                                            children: "-- Select a color --"
                                                        }, void 0, false, {
                                                            fileName: "[project]/components/AddCarModal.tsx",
                                                            lineNumber: 414,
                                                            columnNumber: 21
                                                        }, this),
                                                        colors.map((color)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                                value: color.id,
                                                                children: color.name
                                                            }, color.id, false, {
                                                                fileName: "[project]/components/AddCarModal.tsx",
                                                                lineNumber: 416,
                                                                columnNumber: 23
                                                            }, this))
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/components/AddCarModal.tsx",
                                                    lineNumber: 408,
                                                    columnNumber: 19
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/components/AddCarModal.tsx",
                                            lineNumber: 404,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                    className: "block text-sm font-medium text-gray-700 mb-2",
                                                    children: "Serial Number *"
                                                }, void 0, false, {
                                                    fileName: "[project]/components/AddCarModal.tsx",
                                                    lineNumber: 425,
                                                    columnNumber: 19
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                    type: "text",
                                                    required: true,
                                                    value: formData.serial_number,
                                                    onChange: (e)=>setFormData({
                                                            ...formData,
                                                            serial_number: e.target.value
                                                        }),
                                                    className: "w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-gray-500 focus:border-transparent",
                                                    placeholder: "110 TUN 3000"
                                                }, void 0, false, {
                                                    fileName: "[project]/components/AddCarModal.tsx",
                                                    lineNumber: 426,
                                                    columnNumber: 19
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/components/AddCarModal.tsx",
                                            lineNumber: 424,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                    className: "block text-sm font-medium text-gray-700 mb-2",
                                                    children: "Number of Seats *"
                                                }, void 0, false, {
                                                    fileName: "[project]/components/AddCarModal.tsx",
                                                    lineNumber: 438,
                                                    columnNumber: 19
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                                                    required: true,
                                                    value: formData.nb_place,
                                                    onChange: (e)=>setFormData({
                                                            ...formData,
                                                            nb_place: parseInt(e.target.value)
                                                        }),
                                                    className: "w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-gray-500 focus:border-transparent",
                                                    children: [
                                                        1,
                                                        2,
                                                        3
                                                    ].map((num)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                            value: num,
                                                            children: [
                                                                num,
                                                                " seat",
                                                                num > 1 ? "s" : ""
                                                            ]
                                                        }, num, true, {
                                                            fileName: "[project]/components/AddCarModal.tsx",
                                                            lineNumber: 446,
                                                            columnNumber: 23
                                                        }, this))
                                                }, void 0, false, {
                                                    fileName: "[project]/components/AddCarModal.tsx",
                                                    lineNumber: 439,
                                                    columnNumber: 19
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/components/AddCarModal.tsx",
                                            lineNumber: 437,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                    className: "block text-sm font-medium text-gray-700 mb-2",
                                                    children: [
                                                        "Engine Type * ",
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                            className: "text-xs text-gray-500"
                                                        }, void 0, false, {
                                                            fileName: "[project]/components/AddCarModal.tsx",
                                                            lineNumber: 454,
                                                            columnNumber: 35
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/components/AddCarModal.tsx",
                                                    lineNumber: 453,
                                                    columnNumber: 19
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                                                    required: true,
                                                    value: formData.engine_type,
                                                    onChange: (e)=>setFormData({
                                                            ...formData,
                                                            engine_type: e.target.value
                                                        }),
                                                    className: "w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-gray-500 focus:border-transparent",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                            value: "",
                                                            children: "-- Select engine type --"
                                                        }, void 0, false, {
                                                            fileName: "[project]/components/AddCarModal.tsx",
                                                            lineNumber: 462,
                                                            columnNumber: 21
                                                        }, this),
                                                        engineTypes.map((type)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                                value: type.id,
                                                                children: type.name
                                                            }, type.id, false, {
                                                                fileName: "[project]/components/AddCarModal.tsx",
                                                                lineNumber: 464,
                                                                columnNumber: 23
                                                            }, this))
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/components/AddCarModal.tsx",
                                                    lineNumber: 456,
                                                    columnNumber: 19
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/components/AddCarModal.tsx",
                                            lineNumber: 452,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                    className: "block text-sm font-medium text-gray-700 mb-2",
                                                    children: "Grey Card *"
                                                }, void 0, false, {
                                                    fileName: "[project]/components/AddCarModal.tsx",
                                                    lineNumber: 473,
                                                    columnNumber: 19
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                    type: "text",
                                                    required: true,
                                                    value: formData.grey_card,
                                                    onChange: (e)=>setFormData({
                                                            ...formData,
                                                            grey_card: e.target.value
                                                        }),
                                                    className: "w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-gray-500 focus:border-transparent",
                                                    placeholder: "e.g., GC-1234-5678"
                                                }, void 0, false, {
                                                    fileName: "[project]/components/AddCarModal.tsx",
                                                    lineNumber: 474,
                                                    columnNumber: 19
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/components/AddCarModal.tsx",
                                            lineNumber: 472,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                    className: "block text-sm font-medium text-gray-700 mb-2",
                                                    children: "Year *"
                                                }, void 0, false, {
                                                    fileName: "[project]/components/AddCarModal.tsx",
                                                    lineNumber: 486,
                                                    columnNumber: 19
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                    type: "number",
                                                    required: true,
                                                    min: "1990",
                                                    max: new Date().getFullYear() + 1,
                                                    value: formData.year,
                                                    onChange: (e)=>setFormData({
                                                            ...formData,
                                                            year: parseInt(e.target.value)
                                                        }),
                                                    className: "w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-gray-500 focus:border-transparent"
                                                }, void 0, false, {
                                                    fileName: "[project]/components/AddCarModal.tsx",
                                                    lineNumber: 487,
                                                    columnNumber: 19
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/components/AddCarModal.tsx",
                                            lineNumber: 485,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "md:col-span-2",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                    className: "block text-sm font-medium text-gray-700 mb-2",
                                                    children: "Car Image (Optional, max 5MB)"
                                                }, void 0, false, {
                                                    fileName: "[project]/components/AddCarModal.tsx",
                                                    lineNumber: 500,
                                                    columnNumber: 19
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                    type: "file",
                                                    accept: "image/*",
                                                    onChange: handleImageChange,
                                                    className: "w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-gray-500 focus:border-transparent file:mr-4 file:py-2 file:px-4 file:rounded file:border-0 file:text-sm file:font-semibold file:bg-gray-100 file:text-gray-700 hover:file:bg-gray-200"
                                                }, void 0, false, {
                                                    fileName: "[project]/components/AddCarModal.tsx",
                                                    lineNumber: 501,
                                                    columnNumber: 19
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/components/AddCarModal.tsx",
                                            lineNumber: 499,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/components/AddCarModal.tsx",
                                    lineNumber: 359,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "flex gap-4 pt-4 border-t border-gray-200",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                            type: "button",
                                            onClick: handleClose,
                                            disabled: loading,
                                            className: "flex-1 px-6 py-3 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition font-medium disabled:opacity-50",
                                            children: "Cancel"
                                        }, void 0, false, {
                                            fileName: "[project]/components/AddCarModal.tsx",
                                            lineNumber: 511,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                            type: "submit",
                                            disabled: loading,
                                            className: "flex-1 px-6 py-3 bg-black text-white rounded-lg hover:bg-gray-800 transition font-medium disabled:opacity-50",
                                            children: loading ? "Adding..." : "Add Car"
                                        }, void 0, false, {
                                            fileName: "[project]/components/AddCarModal.tsx",
                                            lineNumber: 519,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/components/AddCarModal.tsx",
                                    lineNumber: 510,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/components/AddCarModal.tsx",
                            lineNumber: 345,
                            columnNumber: 13
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/components/AddCarModal.tsx",
                    lineNumber: 312,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/components/AddCarModal.tsx",
            lineNumber: 298,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/components/AddCarModal.tsx",
        lineNumber: 297,
        columnNumber: 5
    }, this);
}
_s(AddCarModal, "7e4XZxnypo5jWm6MKADWZeahcHQ=");
_c = AddCarModal;
var _c;
__turbopack_context__.k.register(_c, "AddCarModal");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/app/profile/page.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
// "use client";
// import { useState, useEffect } from "react";
// import { useSelector } from "react-redux";
// import api from "../../api/api";
// import type { UserState } from "../../store/userSlice";
// import ProfileCard from "../../components/profile/ProfileCard";
// import TripsSection from "../../components/profile/TripsSection";
// import CarsSection from "../../components/profile/CarsSection";
// import { Car } from "../../components/profile/CarCard";
// import AddCarModal, { CarFormData } from "../../components/AddCarModal";
// interface RootState {
//   user: UserState;
// }
// // Même shape que dans AddCarModal
// // interface CarFormData {
// //   model: string;
// //   vehicle_type: string;
// //   color: string;
// //   serialNumber: string;
// //   seats: number;
// //   engine_type: string;
// //   greyCard: string;
// //   year: number;
// //   image: File | null;
// // }
// export default function ProfilePage() {
//   const user = useSelector((state: RootState) => state.user.user);
//   const [ownedCars, setOwnedCars] = useState<Car[]>([]);
//   const [isModalOpen, setIsModalOpen] = useState(false);
// interface OfferedRide {
//   id: number;
//   from: string;
//   to: string;
//   date: string;
//   price: string;
//   seats: number;
//   seatsAvailable: number;
//   status: string;
// }
// const [offeredRides, setOfferedRides] = useState<OfferedRide[]>([]);
//   // const [reservations, setReservations] = useState<any[]>([]);
// interface Reservation {
//   id: number;
//   from: string;
//   to: string;
//   date: string;
//   driver: string;
//   price: string;
//   status: string;
//   seats: number;
// }
// const [reservations, setReservations] = useState<Reservation[]>([]);
//   // Réservations
//   useEffect(() => {
//     async function fetchReservations() {
//       try {
//         const res = await api.get("/api/reservations/");
//         const data = Array.isArray(res.data) ? res.data : [];
//         // const mapped = data.map((item: any) => {
//         //   const post = item.post;
//         //   return {
//         //     id: item.id,
//         //     from: post?.departure_place || "-",
//         //     to: post?.arrival_place || "-",
//         //     date: post?.departure_date || "-",
//         //     driver:
//         //       post?.user?.first_name && post?.user?.last_name
//         //         ? `${post.user.first_name} ${post.user.last_name}`
//         //         : post?.user?.username || "-",
//         //     price: post?.price ? post.price.toString() : "-",
//         //     status: item.status,
//         //     seats: item.nb_place,
//         //   };
//         // });
//         const mapped = data.map((item: Record<string, unknown>) => {
//   const post = item.post as Record<string, unknown> | undefined;
//   const postUser = post?.user as Record<string, unknown> | undefined;
//   return {
//     id: item.id as number,
//     from: (post?.departure_place as string) || "-",
//     to: (post?.arrival_place as string) || "-",
//     date: (post?.departure_date as string) || "-",
//     driver:
//       postUser?.first_name && postUser?.last_name
//         ? `${postUser.first_name} ${postUser.last_name}`
//         : (postUser?.username as string) || "-",
//     price: post?.price ? (post.price as number).toString() : "-",
//     status: item.status as string,
//     seats: item.nb_place as number,
//   };
// });
//         setReservations(mapped);
//         console.log("Fetched reservations:", mapped);
//       } catch (err) {
//         console.error("Failed to fetch reservations", err);
//       }
//     }
//     fetchReservations();
//   }, []);
//   // Trajets offerts
//   useEffect(() => {
//     async function fetchOfferedRides() {
//       try {
//         const res = await api.get("/api/myPosts/");
//         const data = res.data;
//         // const rides = (Array.isArray(data) ? data : []).map((item: any) => ({
//         //   id: item.id,
//         //   from: item.departure_place,
//         //   to: item.arrival_place,
//         //   date: item.departure_date,
//         //   price: item.price,
//         //   seats: item.car?.nb_place ?? 0,
//         //   seatsAvailable: item.nb_places_disponible ?? 0,
//         //   status: item.status,
//         // }));
//         const rides = (Array.isArray(data) ? data : []).map((item: Record<string, unknown>) => {
//   const car = item.car as Record<string, unknown> | undefined;
//   return {
//     id: item.id as number,
//     from: item.departure_place as string,
//     to: item.arrival_place as string,
//     date: item.departure_date as string,
//     price: item.price as string,
//     seats: (car?.nb_place as number) ?? 0,
//     seatsAvailable: (item.nb_places_disponible as number) ?? 0,
//     status: item.status as string,
//   };
// });
//         setOfferedRides(rides);
//       } catch (err) {
//         console.error("Failed to fetch offered rides", err);
//       }
//     }
//     fetchOfferedRides();
//   }, []);
//   // Voitures possédées
//   // useEffect(() => {
//   //   async function fetchCars() {
//   //     try {
//   //       const res = await api.get("/api/cars/");
//   //       const data = Array.isArray(res.data) ? res.data : [];
//   //       const cars: Car[] = data.map((item: any) => ({
//   //         id: item.id,
//   //         brand: "", // à compléter si ton API renvoie la marque
//   //         model: item.model?.toString() || "",
//   //         year: item.year ?? "",
//   //         color: item.color || "",
//   //         seats: item.nb_place,
//   //         fuelType: item.engine_type,
//   //         licensePlate: item.serial_number,
//   //         image: item.image,
//   //       }));
//   //       setOwnedCars(cars);
//   //     } catch (err) {
//   //       console.error(err);
//   //     }
//   //   }
//   //   fetchCars();
//   // }, []);
//   useEffect(() => {
//   async function fetchCars() {
//     try {
//       const res = await api.get("/api/cars/");
//       const data = Array.isArray(res.data) ? res.data : [];
//       // ✅ Remplacer `any` par un type explicite
//       const cars: Car[] = data.map((item: Record<string, unknown>) => {
//         const modelDetails = item.model_details as Record<string, unknown> | undefined;
//         const brandDetails = modelDetails?.brand as Record<string, unknown> | undefined;
//         const colorDetails = item.color_details as Record<string, unknown> | undefined;
//         const engineTypeDetails = item.engine_type_details as Record<string, unknown> | undefined;
//         return {
//           id: item.id as number,
//           brand: (brandDetails?.name as string) || "",
//           model: (modelDetails?.name as string) || "",
//           year: item.year ? String(item.year) : "",
//           color: (colorDetails?.name as string) || "",
//           seats: (item.nb_place as number) || 0,
//           fuelType: (engineTypeDetails?.name as string) || "",
//           licensePlate: (item.serial_number as string) || "",
//           image: (item.image as string) || "",
//         };
//       });
//       setOwnedCars(cars);
//       console.log("✅ Voitures chargées:", cars);
//     } catch (err) {
//       console.error("❌ Erreur fetch cars:", err);
//     }
//   }
//   fetchCars();
// }, []);
// //   useEffect(() => {
// //   async function fetchCars() {
// //     try {
// //       const res = await api.get("/api/cars/");
// //       const data = Array.isArray(res.data) ? res.data : [];
// //       const cars: Car[] = data.map((item: any) => ({
// //         id: item.id,
// //         // ✅ UTILISER LES DETAILS NESTED
// //         brand: item.model_details?.brand?.name || "",
// //         model: item.model_details?.name || "",
// //         year: item.year?.toString() || "",
// //         color: item.color_details?.name || "",
// //         seats: item.nb_place || 0,
// //         fuelType: item.engine_type_details?.name || "",
// //         licensePlate: item.serial_number || "",
// //         image: item.image || "",
// //       }));
// //       setOwnedCars(cars);
// //       console.log("✅ Voitures chargées:", cars);
// //     } catch (err) {
// //       console.error("❌ Erreur fetch cars:", err);
// //     }
// //   }
// //   fetchCars();
// // }, []);
//   // ✅ Création de voiture côté backend + MAJ state
// //   const handleAddCar = async (formData: CarFormData) => {
// //     if (!user?.id) {
// //       alert("Utilisateur non connecté.");
// //       return;
// //     }
// //     try {
// //       const data = new FormData();
// //       data.append("model", formData.model);                 // ID du Model (ex: "1")
// //     data.append("type", formData.type);                  // ex: "SUV"
// //     data.append("color", formData.color);                // ex: "Silver"
// //     data.append("serial_number", formData.serialNumber.toUpperCase());
// //     data.append("nb_place", String(formData.seats));     // champ nb_place en DB
// //     data.append("engine_type", formData.engineType);     // ex: "Electric"
// //     data.append("grey_card", formData.greyCard || "");
// //     data.append("year", String(formData.year));          // ex: "2025"
// //     if (formData.image) data.append("image", formData.image);
// //     console.log("🚗 FormData envoyée:");
// //     for (const [k, v] of data.entries()) console.log(k, v);
// //     const res = await api.post("/api/cars/", data);
// //     const newCar: Car = {
// //       id: res.data.id,
// //       brand: "", // à remplir si l’API renvoie la marque
// //       model: formData.model,
// //       year: formData.year,
// //       color: formData.color,
// //       seats: formData.seats,
// //       fuelType: formData.engineType,
// //       licensePlate: formData.serialNumber.toUpperCase(),
// //       image: res.data.image || "",
// //     };
// //     setOwnedCars(prev => [...prev, newCar]);
// //     setIsModalOpen(false);
// //     alert("✅ Voiture ajoutée !");
// //   } catch (err: any) {
// //     console.error("❌ ERROR /api/cars/:", err.response?.data || err);
// //     if (err.response?.data) {
// //       const errors = err.response.data as Record<string, any>;
// //       let msg = "Erreurs:\n";
// //       for (const [field, error] of Object.entries(errors)) {
// //         msg += `${field}: ${Array.isArray(error) ? error[0] : error}\n`;
// //       }
// //       alert(msg);
// //     } else {
// //       alert("Erreur serveur 500 lors de la création de la voiture.");
// //     }
// //   }
// // };
// const handleAddCar = async (formData: CarFormData) => {
//   if (!user?.id) {
//     alert("Utilisateur non connecté.");
//     return;
//   }
//   console.log("🔍 formData reçu:", formData);
//   try {
//     const data = new FormData();
//     // utiliser les bons champs
//     const modelId = formData.model ?? "";
//     const vehicleTypeId = formData.vehicle_type ?? "";
//     const colorId = formData.color ?? "";
//     const engineTypeId = formData.engine_type ?? "";
//     console.log("🔍 IDs calculés:", {
//       modelId,
//       vehicleTypeId,
//       colorId,
//       engineTypeId,
//     });
//     if (!modelId || !vehicleTypeId || !colorId || !engineTypeId) {
//       alert("Veuillez sélectionner modèle, type, couleur et type de moteur.");
//       return;
//     }
//     // data.append("model", String(modelId));
//     // data.append("vehicle_type", String(vehicleTypeId));
//     // data.append("color", String(colorId));
//     // const rawSerial = formData.serialNumber ?? "";
//     // const serial = String(rawSerial).toUpperCase().trim();
//     // data.append("serial_number", serial);
//     // data.append("nb_place", String(formData.seats ?? ""));
//     // data.append("engine_type", String(engineTypeId));
//     // data.append("grey_card", formData.greyCard || "");
//     // data.append("year", formData.year ? String(formData.year) : "");
//     data.append("model", String(modelId));
//   data.append("vehicle_type", String(vehicleTypeId));
//   data.append("color", String(colorId));
//   const serial = (formData.serial_number ?? "").toUpperCase().trim();
//   data.append("serial_number", serial);
//   data.append("nb_place", String(formData.nb_place ?? ""));
//   data.append("engine_type", String(engineTypeId));
//   data.append("grey_card", formData.grey_card || "");
//   data.append("year", formData.year ? String(formData.year) : "");
//     if (formData.image) data.append("image", formData.image);
//     console.log("🚗 FormData envoyée:");
//     for (const [k, v] of data.entries()) console.log(k, v);
//       const res = await api.post("/api/cars/", data, {
//       headers: { "Content-Type": "multipart/form-data" },
//     });
//     // construction de newCar…
//   } catch (err) {  // ✅ CORRECTION LIGNE 342: Supprimer : any
//     console.error("❌ ERROR /api/cars/:", err);
//     // ✅ Typage correct pour gérer l'erreur
//     const error = err as { response?: { data?: Record<string, unknown> } };
//     // if (error.response?.data) {
//     //   const errors = error.response.data;
//     //   let msg = "Erreurs:\n";
//     //   for (const [field, errorMsg] of Object.entries(errors)) {
//     //     msg += `${field}: ${Array.isArray(errorMsg) ? errorMsg[0] : errorMsg}\n`;
//     //   }
//     //   alert(msg);
//     // } else {
//     //   alert("Erreur serveur lors de la création de la voiture.");
//     // }
//   }
// };
// //   const handleAddCar = async (formData: CarFormData) => {
// //   if (!user?.id) {
// //     alert("Utilisateur non connecté.");
// //     return;
// //   }
// //   try {
// //     const data = new FormData();
// //     data.append("model", formData.model.toString());
// //     data.append("vehicle_type", formData.type.toString());
// //     data.append("color", formData.color.toString());
// //     // ✅ sécuriser serialNumber
// //     const serial = (formData.serialNumber || "").toString().toUpperCase().trim();
// //     if (!serial) {
// //       alert("La plaque d'immatriculation est obligatoire.");
// //       return;
// //     }
// //     data.append("serial_number", serial);
// //     data.append("nb_place", String(formData.seats));
// //     data.append("engine_type", formData.engineType.toString());
// //     data.append("grey_card", formData.greyCard || "");
// //     data.append("year", formData.year ? String(formData.year) : "");
// //     if (formData.image) data.append("image", formData.image);
// //     const res = await api.post("/api/cars/", data, {
// //       headers: { "Content-Type": "multipart/form-data" },
// //     });
// //     const newCar: Car = {
// //       id: res.data.id,
// //       brand: res.data.model_details?.brand?.name || "",
// //       model: res.data.model_details?.name || "",
// //       year: res.data.year ?? "",
// //       color: res.data.color_details?.name || "",
// //       seats: res.data.nb_place,
// //       fuelType: res.data.engine_type_details?.name || "",
// //       licensePlate: res.data.serial_number || "",
// //       image: res.data.image || "",
// //     };
// //     setOwnedCars(prev => [...prev, newCar]);
// //     setIsModalOpen(false);
// //     alert("✅ Voiture ajoutée !");
// //   } catch (err: any) {
// //     console.error("❌ ERROR /api/cars/:", err.response?.data || err);
// //     if (err.response?.data) {
// //       const errors = err.response.data as Record<string, any>;
// //       let msg = "Erreurs:\n";
// //       for (const [field, error] of Object.entries(errors)) {
// //         msg += `${field}: ${Array.isArray(error) ? error[0] : error}\n`;
// //       }
// //       alert(msg);
// //     } else {
// //       alert("Erreur serveur lors de la création de la voiture.");
// //     }
// //   }
// // };
//   const handleEditCar = (car: Car) => {
//     console.log("Edit car:", car);
//   };
//   const handleRemoveCar = (carId: number) => {
//     setOwnedCars((prev) => prev.filter((car) => car.id !== carId));
//   };
//   const handleCancelReservation = async (tripId: number) => {
//     try {
//       await api.put(`/api/reservations/${tripId}/`, { status: "canceled" });
// setReservations((prev) =>
//         prev.map((r) => (r.id === tripId ? { ...r, status: "canceled" } : r))
//       );
//     } catch (err) {
//       console.error("Failed to cancel reservation", err);
//     }
//   };
//   const handleCancelOfferedRide = async (tripId: number) => {
//     try {
//       await api.put(`/api/posts/${tripId}/`, { status: "canceled" });
// setOfferedRides((prev) =>
//         prev.map((r) => (r.id === tripId ? { ...r, status: "canceled" } : r))
//       );
//     } catch (err) {
//       console.error("Failed to cancel offered ride", err);
//     }
//   };
//   const handleEditOfferedRide = (tripId: number) => {
//     console.log("Edit offered ride:", tripId);
//   };
//   return (
//     <main className="min-h-screen bg-gray-50 py-8">
//       <div className="max-w-6xl mx-auto px-4">
//         {user && <ProfileCard user={user} />}
//         <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
//           <TripsSection
// title="Mes réservations"
//             trips={reservations.filter(
//               (r) => r.status?.toLowerCase() !== "canceled"
//             )}
//             type="reservation"
//             onCancel={handleCancelReservation}
//           />
//           <TripsSection
// title="Mes trajets proposés"
//             trips={offeredRides}
//             type="offered"
//             onCancel={handleCancelOfferedRide}
//             onEdit={handleEditOfferedRide}
//           />
//         </div>
//         <CarsSection
//           cars={ownedCars}
//           onAddCar={() => setIsModalOpen(true)}
//           onEditCar={handleEditCar}
//           onRemoveCar={handleRemoveCar}
//         />
//       </div>
//       <AddCarModal
//         isOpen={isModalOpen}
//         onClose={() => setIsModalOpen(false)}
//         onSubmit={handleAddCar}
//       />
//     </main>
//   );
// }
// src/app/profile/page.tsx
__turbopack_context__.s({
    "default": ()=>ProfilePage
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$redux$2f$dist$2f$react$2d$redux$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-redux/dist/react-redux.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$api$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/api/api.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$profile$2f$ProfileCard$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/profile/ProfileCard.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$profile$2f$TripsSection$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/profile/TripsSection.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$profile$2f$CarsSection$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/profile/CarsSection.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$AddCarModal$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/AddCarModal.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
;
function ProfilePage() {
    _s();
    const user = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$redux$2f$dist$2f$react$2d$redux$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSelector"])({
        "ProfilePage.useSelector[user]": (state)=>state.user.user
    }["ProfilePage.useSelector[user]"]);
    const [ownedCars, setOwnedCars] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [isModalOpen, setIsModalOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [offeredRides, setOfferedRides] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [reservations, setReservations] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    // ============================================================================
    // CHARGER LES RÉSERVATIONS
    // ============================================================================
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "ProfilePage.useEffect": ()=>{
            async function fetchReservations() {
                try {
                    const res = await __TURBOPACK__imported__module__$5b$project$5d2f$api$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].get("/api/reservations/");
                    const data = Array.isArray(res.data) ? res.data : [];
                    const mapped = data.map({
                        "ProfilePage.useEffect.fetchReservations.mapped": (item)=>{
                            const post = item.post;
                            const postUser = post === null || post === void 0 ? void 0 : post.user;
                            return {
                                id: item.id,
                                from: (post === null || post === void 0 ? void 0 : post.departure_place) || "-",
                                to: (post === null || post === void 0 ? void 0 : post.arrival_place) || "-",
                                date: (post === null || post === void 0 ? void 0 : post.departure_date) || "-",
                                driver: (postUser === null || postUser === void 0 ? void 0 : postUser.first_name) && (postUser === null || postUser === void 0 ? void 0 : postUser.last_name) ? "".concat(postUser.first_name, " ").concat(postUser.last_name) : (postUser === null || postUser === void 0 ? void 0 : postUser.username) || "-",
                                price: (post === null || post === void 0 ? void 0 : post.price) ? post.price.toString() : "-",
                                status: item.status,
                                seats: item.nb_place
                            };
                        }
                    }["ProfilePage.useEffect.fetchReservations.mapped"]);
                    setReservations(mapped);
                    console.log("✅ Réservations chargées:", mapped);
                } catch (err) {
                    console.error("❌ Erreur fetch reservations:", err);
                }
            }
            fetchReservations();
        }
    }["ProfilePage.useEffect"], []);
    // ============================================================================
    // CHARGER LES TRAJETS OFFERTS
    // ============================================================================
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "ProfilePage.useEffect": ()=>{
            async function fetchOfferedRides() {
                try {
                    const res = await __TURBOPACK__imported__module__$5b$project$5d2f$api$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].get("/api/myPosts/");
                    const data = res.data;
                    const rides = (Array.isArray(data) ? data : []).map({
                        "ProfilePage.useEffect.fetchOfferedRides.rides": (item)=>{
                            const car = item.car;
                            var _ref, _ref1;
                            return {
                                id: item.id,
                                from: item.departure_place,
                                to: item.arrival_place,
                                date: item.departure_date,
                                price: item.price,
                                seats: (_ref = car === null || car === void 0 ? void 0 : car.nb_place) !== null && _ref !== void 0 ? _ref : 0,
                                seatsAvailable: (_ref1 = item.nb_places_disponible) !== null && _ref1 !== void 0 ? _ref1 : 0,
                                status: item.status
                            };
                        }
                    }["ProfilePage.useEffect.fetchOfferedRides.rides"]);
                    setOfferedRides(rides);
                } catch (err) {
                    console.error("❌ Erreur fetch offered rides:", err);
                }
            }
            fetchOfferedRides();
        }
    }["ProfilePage.useEffect"], []);
    // ============================================================================
    // CHARGER LES VOITURES - MISE À JOUR POUR STOCKER LES IDs
    // ============================================================================
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "ProfilePage.useEffect": ()=>{
            async function fetchCars() {
                try {
                    const res = await __TURBOPACK__imported__module__$5b$project$5d2f$api$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].get("/api/cars/");
                    const data = Array.isArray(res.data) ? res.data : [];
                    const cars = data.map({
                        "ProfilePage.useEffect.fetchCars.cars": (item)=>{
                            const modelDetails = item.model_details;
                            const brandDetails = modelDetails === null || modelDetails === void 0 ? void 0 : modelDetails.brand;
                            const colorDetails = item.color_details;
                            const engineTypeDetails = item.engine_type_details;
                            return {
                                id: item.id,
                                brand: (brandDetails === null || brandDetails === void 0 ? void 0 : brandDetails.name) || "",
                                model: (modelDetails === null || modelDetails === void 0 ? void 0 : modelDetails.name) || "",
                                year: item.year ? String(item.year) : "",
                                color: (colorDetails === null || colorDetails === void 0 ? void 0 : colorDetails.name) || "",
                                seats: item.nb_place || 0,
                                fuelType: (engineTypeDetails === null || engineTypeDetails === void 0 ? void 0 : engineTypeDetails.name) || "",
                                licensePlate: item.serial_number || "",
                                image: item.image || "",
                                // ✅ AJOUTER LES IDs POUR LE MODAL
                                vehicle_type: item.vehicle_type,
                                color_id: item.color,
                                engine_type: item.engine_type,
                                model_id: item.model,
                                nb_place: item.nb_place,
                                serial_number: item.serial_number,
                                grey_card: item.grey_card
                            };
                        }
                    }["ProfilePage.useEffect.fetchCars.cars"]);
                    setOwnedCars(cars);
                    console.log("✅ Voitures chargées:", cars);
                } catch (err) {
                    console.error("❌ Erreur fetch cars:", err);
                }
            }
            fetchCars();
        }
    }["ProfilePage.useEffect"], []);
    // ============================================================================
    // AJOUTER UNE VOITURE
    // ============================================================================
    const handleAddCar = async (formData)=>{
        if (!(user === null || user === void 0 ? void 0 : user.id)) {
            alert("Utilisateur non connecté.");
            return;
        }
        console.log("📝 formData reçu:", formData);
        try {
            const data = new FormData();
            var _formData_model;
            const modelId = (_formData_model = formData.model) !== null && _formData_model !== void 0 ? _formData_model : "";
            var _formData_vehicle_type;
            const vehicleTypeId = (_formData_vehicle_type = formData.vehicle_type) !== null && _formData_vehicle_type !== void 0 ? _formData_vehicle_type : "";
            var _formData_color;
            const colorId = (_formData_color = formData.color) !== null && _formData_color !== void 0 ? _formData_color : "";
            var _formData_engine_type;
            const engineTypeId = (_formData_engine_type = formData.engine_type) !== null && _formData_engine_type !== void 0 ? _formData_engine_type : "";
            console.log("📝 IDs calculés:", {
                modelId,
                vehicleTypeId,
                colorId,
                engineTypeId
            });
            if (!modelId || !vehicleTypeId || !colorId || !engineTypeId) {
                alert("Veuillez sélectionner modèle, type, couleur et type de moteur.");
                return;
            }
            data.append("model", String(modelId));
            data.append("vehicle_type", String(vehicleTypeId));
            data.append("color", String(colorId));
            var _formData_serial_number;
            const serial = ((_formData_serial_number = formData.serial_number) !== null && _formData_serial_number !== void 0 ? _formData_serial_number : "").toUpperCase().trim();
            data.append("serial_number", serial);
            var _formData_nb_place;
            data.append("nb_place", String((_formData_nb_place = formData.nb_place) !== null && _formData_nb_place !== void 0 ? _formData_nb_place : ""));
            data.append("engine_type", String(engineTypeId));
            data.append("grey_card", formData.grey_card || "");
            data.append("year", formData.year ? String(formData.year) : "");
            if (formData.image) data.append("image", formData.image);
            console.log("🚗 FormData envoyée:");
            for (const [k, v] of data.entries())console.log(k, v);
            const res = await __TURBOPACK__imported__module__$5b$project$5d2f$api$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].post("/api/cars/", data, {
                headers: {
                    "Content-Type": "multipart/form-data"
                }
            });
            console.log("✅ Voiture créée:", res.data);
            setIsModalOpen(false);
            alert("✅ Voiture ajoutée !");
            // Recharger les voitures
            window.location.reload();
        } catch (err) {
            var _error_response;
            console.error("❌ ERROR /api/cars/:", err);
            const error = err;
            if ((_error_response = error.response) === null || _error_response === void 0 ? void 0 : _error_response.data) {
                const errors = error.response.data;
                let msg = "Erreurs:\n";
                for (const [field, errorMsg] of Object.entries(errors)){
                    msg += "".concat(field, ": ").concat(Array.isArray(errorMsg) ? errorMsg[0] : errorMsg, "\n");
                }
                alert(msg);
            } else {
                alert("Erreur serveur lors de la création de la voiture.");
            }
        }
    };
    // ============================================================================
    // MODIFIER UNE VOITURE - Le modal gère ça maintenant
    // ============================================================================
    const handleEditCar = (car)=>{
        console.log("✅ Edit car appelé (géré par le modal):", car);
    // Le modal s'ouvre automatiquement depuis CarCard
    };
    // ============================================================================
    // SUPPRIMER UNE VOITURE
    // ============================================================================
    const handleRemoveCar = (carId)=>{
        setOwnedCars((prev)=>prev.filter((car)=>car.id !== carId));
    };
    // ============================================================================
    // ANNULER UNE RÉSERVATION
    // ============================================================================
    const handleCancelReservation = async (tripId)=>{
        try {
            await __TURBOPACK__imported__module__$5b$project$5d2f$api$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].put("/api/reservations/".concat(tripId, "/"), {
                status: "canceled"
            });
            setReservations((prev)=>prev.map((r)=>r.id === tripId ? {
                        ...r,
                        status: "canceled"
                    } : r));
        } catch (err) {
            console.error("Failed to cancel reservation", err);
        }
    };
    // ============================================================================
    // ANNULER UN TRAJET OFFERT
    // ============================================================================
    const handleCancelOfferedRide = async (tripId)=>{
        try {
            await __TURBOPACK__imported__module__$5b$project$5d2f$api$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].put("/api/posts/".concat(tripId, "/"), {
                status: "canceled"
            });
            setOfferedRides((prev)=>prev.map((r)=>r.id === tripId ? {
                        ...r,
                        status: "canceled"
                    } : r));
        } catch (err) {
            console.error("Failed to cancel offered ride", err);
        }
    };
    // ============================================================================
    // MODIFIER UN TRAJET OFFERT
    // ============================================================================
    const handleEditOfferedRide = (tripId)=>{
        console.log("Edit offered ride:", tripId);
    };
    // ============================================================================
    // RENDER
    // ============================================================================
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("main", {
        className: "min-h-screen bg-gray-50 py-8",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "max-w-6xl mx-auto px-4",
                children: [
                    user && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$profile$2f$ProfileCard$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        user: user
                    }, void 0, false, {
                        fileName: "[project]/app/profile/page.tsx",
                        lineNumber: 804,
                        columnNumber: 18
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "grid grid-cols-1 lg:grid-cols-2 gap-8",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$profile$2f$TripsSection$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                title: "Mes réservations",
                                trips: reservations.filter((r)=>{
                                    var _r_status;
                                    return ((_r_status = r.status) === null || _r_status === void 0 ? void 0 : _r_status.toLowerCase()) !== "canceled";
                                }),
                                type: "reservation",
                                onCancel: handleCancelReservation
                            }, void 0, false, {
                                fileName: "[project]/app/profile/page.tsx",
                                lineNumber: 807,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$profile$2f$TripsSection$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                title: "Mes trajets proposés",
                                trips: offeredRides,
                                type: "offered",
                                onCancel: handleCancelOfferedRide,
                                onEdit: handleEditOfferedRide
                            }, void 0, false, {
                                fileName: "[project]/app/profile/page.tsx",
                                lineNumber: 816,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/profile/page.tsx",
                        lineNumber: 806,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$profile$2f$CarsSection$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        cars: ownedCars,
                        onAddCar: ()=>setIsModalOpen(true),
                        onEditCar: handleEditCar,
                        onRemoveCar: handleRemoveCar
                    }, void 0, false, {
                        fileName: "[project]/app/profile/page.tsx",
                        lineNumber: 825,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/profile/page.tsx",
                lineNumber: 803,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$AddCarModal$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                isOpen: isModalOpen,
                onClose: ()=>setIsModalOpen(false),
                onSubmit: handleAddCar
            }, void 0, false, {
                fileName: "[project]/app/profile/page.tsx",
                lineNumber: 833,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/profile/page.tsx",
        lineNumber: 802,
        columnNumber: 5
    }, this);
}
_s(ProfilePage, "hLLwDhoWTzTR+S3cseA6gJzXquc=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$redux$2f$dist$2f$react$2d$redux$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSelector"]
    ];
});
_c = ProfilePage;
var _c;
__turbopack_context__.k.register(_c, "ProfilePage");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
}]);

//# sourceMappingURL=_6ab8355a._.js.map