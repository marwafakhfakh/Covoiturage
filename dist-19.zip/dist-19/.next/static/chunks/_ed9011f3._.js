(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([typeof document === "object" ? document.currentScript : undefined, {

"[project]/api/api.ts [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": ()=>__TURBOPACK__default__export__
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$axios$2f$lib$2f$axios$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/axios/lib/axios.js [app-client] (ecmascript)");
;
const api = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$axios$2f$lib$2f$axios$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].create({
    //baseURL: process.env.NEXT_PUBLIC_API_BASE_URL || "https://app.namlaa.com",
    baseURL: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].env.NEXT_PUBLIC_API_BASE_URL || "https://dev.namlaa.com",
    timeout: 10000
});
// ✅ Intercepteur TOKEN - UNIQUEMENT pour les routes protégées
api.interceptors.request.use((config)=>{
    var _config_url, _config_url1;
    // NE PAS ajouter de token pour les routes d'authentification
    if (((_config_url = config.url) === null || _config_url === void 0 ? void 0 : _config_url.includes('/auth/login')) || ((_config_url1 = config.url) === null || _config_url1 === void 0 ? void 0 : _config_url1.includes('/auth/register'))) {
        console.log('🔓 Requête auth sans token');
        return config;
    }
    const token = localStorage.getItem('auth_token');
    if (token) {
        config.headers.Authorization = "Token ".concat(token);
        console.log('✅ Token envoyé:', token.slice(0, 20) + '...');
    }
    return config;
});
// ✅ Intercepteur réponse pour nettoyer les tokens invalides
api.interceptors.response.use((response)=>response, (error)=>{
    var _error_response;
    if (((_error_response = error.response) === null || _error_response === void 0 ? void 0 : _error_response.status) === 401) {
        localStorage.removeItem('auth_token');
        console.log('🧹 Token invalide supprimé');
    }
    return Promise.reject(error);
});
const __TURBOPACK__default__export__ = api;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/components/common/PageHeader.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": ()=>PageHeader
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
;
function PageHeader(param) {
    let { title, subtitle, searchInfo, resultCount, className = "" } = param;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "bg-white shadow-sm border-b border-gray-200 ".concat(className),
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "max-w-7xl mx-auto px-4 py-6",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                    className: "text-4xl font-bold mb-6 text-center text-gray-900",
                    children: title
                }, void 0, false, {
                    fileName: "[project]/components/common/PageHeader.tsx",
                    lineNumber: 23,
                    columnNumber: 9
                }, this),
                searchInfo && (searchInfo.from || searchInfo.to) ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "text-center mb-4",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: "text-lg text-gray-600",
                            children: [
                                searchInfo.from && searchInfo.to ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                                    children: [
                                        "Rides from",
                                        " ",
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "font-semibold text-gray-900",
                                            children: searchInfo.from
                                        }, void 0, false, {
                                            fileName: "[project]/components/common/PageHeader.tsx",
                                            lineNumber: 33,
                                            columnNumber: 19
                                        }, this),
                                        " ",
                                        "to",
                                        " ",
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "font-semibold text-gray-900",
                                            children: searchInfo.to
                                        }, void 0, false, {
                                            fileName: "[project]/components/common/PageHeader.tsx",
                                            lineNumber: 37,
                                            columnNumber: 19
                                        }, this)
                                    ]
                                }, void 0, true) : searchInfo.from ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                                    children: [
                                        "Rides from",
                                        " ",
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "font-semibold text-gray-900",
                                            children: searchInfo.from
                                        }, void 0, false, {
                                            fileName: "[project]/components/common/PageHeader.tsx",
                                            lineNumber: 44,
                                            columnNumber: 19
                                        }, this)
                                    ]
                                }, void 0, true) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                                    children: [
                                        "Rides to",
                                        " ",
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "font-semibold text-gray-900",
                                            children: searchInfo.to
                                        }, void 0, false, {
                                            fileName: "[project]/components/common/PageHeader.tsx",
                                            lineNumber: 51,
                                            columnNumber: 19
                                        }, this)
                                    ]
                                }, void 0, true),
                                searchInfo.date && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                                    children: [
                                        " ",
                                        "on",
                                        " ",
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "font-semibold text-gray-900",
                                            children: new Date(searchInfo.date).toLocaleDateString()
                                        }, void 0, false, {
                                            fileName: "[project]/components/common/PageHeader.tsx",
                                            lineNumber: 60,
                                            columnNumber: 19
                                        }, this)
                                    ]
                                }, void 0, true)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/components/common/PageHeader.tsx",
                            lineNumber: 29,
                            columnNumber: 13
                        }, this),
                        typeof resultCount === "number" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: "text-sm text-gray-500 mt-2",
                            children: [
                                resultCount,
                                " ride",
                                resultCount !== 1 ? "s" : "",
                                " found"
                            ]
                        }, void 0, true, {
                            fileName: "[project]/components/common/PageHeader.tsx",
                            lineNumber: 67,
                            columnNumber: 15
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/components/common/PageHeader.tsx",
                    lineNumber: 28,
                    columnNumber: 11
                }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "text-center mb-4",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: "text-lg text-gray-600 mb-2",
                            children: subtitle || "All Available Rides"
                        }, void 0, false, {
                            fileName: "[project]/components/common/PageHeader.tsx",
                            lineNumber: 74,
                            columnNumber: 13
                        }, this),
                        typeof resultCount === "number" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: "text-sm text-gray-500",
                            children: [
                                resultCount,
                                " ride",
                                resultCount !== 1 ? "s" : "",
                                " found"
                            ]
                        }, void 0, true, {
                            fileName: "[project]/components/common/PageHeader.tsx",
                            lineNumber: 78,
                            columnNumber: 15
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/components/common/PageHeader.tsx",
                    lineNumber: 73,
                    columnNumber: 11
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/components/common/PageHeader.tsx",
            lineNumber: 22,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/components/common/PageHeader.tsx",
        lineNumber: 21,
        columnNumber: 5
    }, this);
}
_c = PageHeader;
var _c;
__turbopack_context__.k.register(_c, "PageHeader");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/components/common/EmptyState.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": ()=>EmptyState
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/app-dir/link.js [app-client] (ecmascript)");
;
;
function EmptyState(param) {
    let { icon = "🚗", title = "Rejoignez Namlaa pour continuer", description = "Veuillez vous inscrire pour continuer et accéder à toutes les fonctionnalités.", actionText = "S’inscrire", actionHref = "/auth/signup", className = "" } = param;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "text-center py-12 ".concat(className),
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "w-20 h-20 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-6",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                    className: "text-3xl",
                    children: icon
                }, void 0, false, {
                    fileName: "[project]/components/common/EmptyState.tsx",
                    lineNumber: 23,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/components/common/EmptyState.tsx",
                lineNumber: 22,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                className: "text-2xl font-bold text-gray-900 mb-4",
                children: title
            }, void 0, false, {
                fileName: "[project]/components/common/EmptyState.tsx",
                lineNumber: 25,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "text-gray-600 mb-6",
                children: description
            }, void 0, false, {
                fileName: "[project]/components/common/EmptyState.tsx",
                lineNumber: 26,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                href: actionHref,
                className: "inline-block px-6 py-3 bg-black text-white rounded-lg hover:bg-gray-800 transition font-semibold",
                children: actionText
            }, void 0, false, {
                fileName: "[project]/components/common/EmptyState.tsx",
                lineNumber: 27,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/components/common/EmptyState.tsx",
        lineNumber: 21,
        columnNumber: 5
    }, this);
}
_c = EmptyState;
var _c;
__turbopack_context__.k.register(_c, "EmptyState");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/app/rides/page.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
// "use client";
// import { useState, useEffect, useCallback } from "react";
// import api from "../../api/api";
// import PageHeader from "../../components/common/PageHeader";
// import RidesFilterSidebar from "../../components/rides/RidesFilterSidebar";
// import RideCard, { RideData } from "../../components/rides/RideCard";
// import EmptyState from "../../components/common/EmptyState";
// import SearchForm from "../../components/home/SearchForm";
// type SearchParams = {
//   from: string;
//   to: string;
//   date: string;
//   seats: string;
// };
// type Filters = {
//   sortBy: string;
//   services: string[];
//   departureTimeRange: string;
//   seats: string;
// };
// export default function RidesPage() {
//   const [searchParams, setSearchParams] = useState<SearchParams>({
//     from: "",
//     to: "",
//     date: "",
//     seats: "1",
//   });
//   const [filters, setFilters] = useState<Filters>({
//     sortBy: "departure_time",
//     services: [],
//     departureTimeRange: "",
//     seats: "",
//   });
//   const [allRides, setAllRides] = useState<RideData[]>([]);
//   const [availableServices, setAvailableServices] = useState<string[]>([]);
//   const [loading, setLoading] = useState(false);
//   const [filteredRides, setFilteredRides] = useState<RideData[]>([]);
//   const [currentPage, setCurrentPage] = useState(1);
//   const [totalPages, setTotalPages] = useState(1);
//   // Fetch rides
//   const fetchRides = useCallback(async (url: string = "/api/posts/") => {
//     setLoading(true);
//     try {
//       const res = await api.get(url);
//       const rides = Array.isArray(res.data) ? res.data : res.data.results || [];
//       setAllRides(rides);
//     } catch {
//       setAllRides([]);
//     } finally {
//       setLoading(false);
//     }
//   }, []);
//   // Read URL params on first load
//   useEffect(() => {
//     if (typeof window === "undefined") return;
//     const urlParams = new URLSearchParams(window.location.search);
//     const params: SearchParams = {
//       from: urlParams.get("from") || "",
//       to: urlParams.get("to") || "",
//       date: urlParams.get("date") || "",
//       seats: urlParams.get("seats") || "1",
//     };
//     setSearchParams(params);
//     const query = new URLSearchParams();
//     Object.entries(params).forEach(([key, value]) => {
//       if (value) query.append(key, value);
//     });
//     const page = urlParams.get("page");
//     if (page) setCurrentPage(parseInt(page, 10) || 1);
//     fetchRides(`/api/posts/?${query.toString()}`);
//   }, [fetchRides]);
//   // Fetch services
//   useEffect(() => {
//     api
//       .get("/api/services/")
//       .then((res) => {
//         const services = Array.isArray(res.data) ? res.data : [];
//         const names = services
//           .map((s: { name: string }) => s.name)
//           .filter(Boolean);
//         setAvailableServices(names);
//       })
//       .catch(() => setAvailableServices([]));
//   }, []);
//   // Filtering logic
//   const applyFilters = useCallback(
//     (rides: RideData[], search: SearchParams, filter: Filters) => {
//       let filtered = [...rides];
//       if (search.from) {
//         filtered = filtered.filter((ride) =>
//           ride.departure_place
//             .toLowerCase()
//             .includes(search.from.toLowerCase())
//         );
//       }
//       if (search.to) {
//         filtered = filtered.filter((ride) =>
//           ride.arrival_place.toLowerCase().includes(search.to.toLowerCase())
//         );
//       }
//       if (search.seats) {
//         const seatsNeeded = parseInt(search.seats, 10);
//         if (!isNaN(seatsNeeded)) {
//           filtered = filtered.filter(
//             (ride) => ride.nb_places_disponible >= seatsNeeded
//           );
//         }
//       }
//       if (search.date) {
//         filtered = filtered.filter((ride) => {
//           const rideDate = new Date(ride.departure_date)
//             .toISOString()
//             .slice(0, 10);
//           return rideDate === search.date;
//         });
//       }
//       if (filter.services.length > 0) {
//         filtered = filtered.filter((ride) =>
//           filter.services.every((service) =>
//             ride.services.map((s: { name: string }) => s.name)
//               .includes(service)
//           )
//         );
//       }
//       if (filter.departureTimeRange) {
//         const [start, end] = filter.departureTimeRange
//           .split("-")
//           .map(Number);
//         filtered = filtered.filter((ride) => {
//           const hour = new Date(ride.departure_date).getHours();
//           return hour >= start && hour < end;
//         });
//       }
//       filtered.sort((a, b) => {
//         switch (filter.sortBy) {
//           case "departure_time":
//             return (
//               new Date(a.departure_date).getTime() -
//               new Date(b.departure_date).getTime()
//             );
//           case "price_low":
//             return parseFloat(a.price) - parseFloat(b.price);
//           case "price_high":
//             return parseFloat(b.price) - parseFloat(a.price);
//           case "seats":
//             return b.nb_places_disponible - a.nb_places_disponible;
//           default:
//             return 0;
//         }
//       });
//       return filtered;
//     },
//     []
//   );
//   // Apply filters whenever data or filters change
//   useEffect(() => {
//     const filtered = applyFilters(allRides, searchParams, filters);
//     setFilteredRides(filtered);
//     setTotalPages(Math.max(1, Math.ceil(filtered.length / 10)));
//     setCurrentPage(1);
//   }, [allRides, searchParams, filters, applyFilters]);
//   // Pagination
//   const pageSize = 10;
//   const paginatedRides = filteredRides.slice(
//     (currentPage - 1) * pageSize,
//     currentPage * pageSize
//   );
//   // Handlers
//   const handleSearch = (formData: SearchParams) => {
//     const params = new URLSearchParams();
//     Object.entries(formData).forEach(([key, value]) => {
//       if (value) params.append(key, value);
//     });
//     if (typeof window !== "undefined") {
//       window.history.replaceState(null, "", `/rides?${params.toString()}`);
//     }
//     setSearchParams(formData);
//     fetchRides(`/api/posts/?${params.toString()}`);
//   };
//   const handleSortChange = (sortBy: string) => {
//     setFilters((prev) => ({ ...prev, sortBy }));
//   };
//   const handleServiceFilter = (service: string) => {
//     setFilters((prev) => ({
//       ...prev,
//       services: prev.services.includes(service)
//         ? prev.services.filter((s) => s !== service)
//         : [...prev.services, service],
//     }));
//   };
//   const handleClearFilters = () => {
//     setFilters({
//       sortBy: "departure_time",
//       services: [],
//       departureTimeRange: "",
//       seats: "",
//     });
//   };
//   const handleDepartureTimeRangeChange = (range: string) => {
//     setFilters((prev) => ({ ...prev, departureTimeRange: range }));
//   };
//   const handlePageChange = (page: number) => {
//     setCurrentPage(page);
//     if (typeof window !== "undefined") {
//       const urlParams = new URLSearchParams(window.location.search);
//       urlParams.set("page", page.toString());
//       window.history.replaceState(
//         null,
//         "",
//         `/rides?${urlParams.toString()}`
//       );
//     }
//   };
//   return (
//     <main className="min-h-screen bg-gray-50">
//   <SearchForm
//     initialData={searchParams}
//     onSearch={handleSearch}
//     title="Trouver le meilleur trajet pour vous"
//     className="pt-4 pb-0"
//   />
//       <PageHeader
//         title="Trajets disponibles"
//         searchInfo={searchParams}
//         resultCount={filteredRides.length}
//       />
//       <div className="max-w-7xl mx-auto px-4 py-8">
//         <div className="flex gap-8">
//           <RidesFilterSidebar
//             filters={filters}
//             onSortChange={handleSortChange}
//             onServiceFilter={handleServiceFilter}
//             onClearFilters={handleClearFilters}
//             onDepartureTimeRangeChange={handleDepartureTimeRangeChange}
//             availableServices={
//               availableServices.length > 0 ? availableServices : undefined
//             }
//           />
//           <div className="flex-1">
//             {loading ? (
//               <div className="text-center py-8">Charrgement des trajets...</div>
//             ) : paginatedRides.length > 0 ? (
//               <div className="space-y-4">
//                 {paginatedRides.map((ride) => (
//                   <RideCard key={ride.id} ride={ride} />
//                 ))}
//               </div>
//             ) : (
//               <EmptyState />
//             )}
//             {filteredRides.length > 0 && (
//               <div className="flex justify-center items-center gap-4 mt-8">
//                 <button
//                   className="px-4 py-2 border rounded disabled:opacity-50"
//                   onClick={() => handlePageChange(currentPage - 1)}
//                   disabled={currentPage === 1 || loading}
//                 >
//                   Précédent
//                 </button>
//                 <span>
//                   Page {currentPage} of {totalPages}
//                 </span>
//                 <button
//                   className="px-4 py-2 border rounded disabled:opacity-50"
//                   onClick={() => handlePageChange(currentPage + 1)}
//                   disabled={currentPage === totalPages || loading}
//                 >
//                   Suivant
//                 </button>
//               </div>
//             )}
//           </div>
//         </div>
//       </div>
//     </main>
//   );
// }
__turbopack_context__.s({
    "default": ()=>RidesPage
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$api$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/api/api.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$common$2f$PageHeader$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/common/PageHeader.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$rides$2f$RidesFilterSidebar$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/rides/RidesFilterSidebar.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$rides$2f$RideCard$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/rides/RideCard.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$common$2f$EmptyState$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/common/EmptyState.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
function RidesPage() {
    _s();
    const [searchParams, setSearchParams] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({
        from: "",
        to: "",
        date: "",
        seats: "1"
    });
    const [filters, setFilters] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({
        sortBy: "departure_time",
        services: [],
        departureTimeRange: "",
        seats: ""
    });
    const [allRides, setAllRides] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [availableServices, setAvailableServices] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [loading, setLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [filteredRides, setFilteredRides] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [currentPage, setCurrentPage] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(1);
    const [totalPages, setTotalPages] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(1);
    // Fetch rides une seule fois (sans params)
    const fetchRides = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "RidesPage.useCallback[fetchRides]": async ()=>{
            setLoading(true);
            try {
                const res = await __TURBOPACK__imported__module__$5b$project$5d2f$api$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].get("/api/posts/");
                const rides = Array.isArray(res.data) ? res.data : res.data.results || [];
                setAllRides(rides);
            } catch (e) {
                setAllRides([]);
            } finally{
                setLoading(false);
            }
        }
    }["RidesPage.useCallback[fetchRides]"], []);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "RidesPage.useEffect": ()=>{
            fetchRides();
        }
    }["RidesPage.useEffect"], [
        fetchRides
    ]);
    // Fetch services
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "RidesPage.useEffect": ()=>{
            __TURBOPACK__imported__module__$5b$project$5d2f$api$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].get("/api/services/").then({
                "RidesPage.useEffect": (res)=>{
                    const services = Array.isArray(res.data) ? res.data : [];
                    const names = services.map({
                        "RidesPage.useEffect.names": (s)=>s.name
                    }["RidesPage.useEffect.names"]).filter(Boolean);
                    setAvailableServices(names);
                }
            }["RidesPage.useEffect"]).catch({
                "RidesPage.useEffect": ()=>setAvailableServices([])
            }["RidesPage.useEffect"]);
        }
    }["RidesPage.useEffect"], []);
    // Filtrage JSON (délégation + ville)
    const applyFilters = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "RidesPage.useCallback[applyFilters]": (rides, search, filter)=>{
            let filtered = [
                ...rides
            ];
            // ----- De / Vers (délégation + ville) -----
            if (search.from && search.to) {
                const fromVal = search.from.toLowerCase();
                const toVal = search.to.toLowerCase();
                filtered = filtered.filter({
                    "RidesPage.useCallback[applyFilters]": (ride)=>{
                        const depPlace = ride.departure_place.toLowerCase();
                        const depCity = (ride.departure_city || "").toLowerCase();
                        const arrPlace = ride.arrival_place.toLowerCase();
                        const arrCity = (ride.arrival_city || "").toLowerCase();
                        const matchFrom = depPlace.includes(fromVal) || depCity.includes(fromVal);
                        const matchTo = arrPlace.includes(toVal) || arrCity.includes(toVal);
                        return matchFrom && matchTo;
                    }
                }["RidesPage.useCallback[applyFilters]"]);
            } else if (search.from) {
                const fromVal = search.from.toLowerCase();
                filtered = filtered.filter({
                    "RidesPage.useCallback[applyFilters]": (ride)=>{
                        const depPlace = ride.departure_place.toLowerCase();
                        const depCity = (ride.departure_city || "").toLowerCase();
                        return depPlace.includes(fromVal) || depCity.includes(fromVal);
                    }
                }["RidesPage.useCallback[applyFilters]"]);
            } else if (search.to) {
                const toVal = search.to.toLowerCase();
                filtered = filtered.filter({
                    "RidesPage.useCallback[applyFilters]": (ride)=>{
                        const arrPlace = ride.arrival_place.toLowerCase();
                        const arrCity = (ride.arrival_city || "").toLowerCase();
                        return arrPlace.includes(toVal) || arrCity.includes(toVal);
                    }
                }["RidesPage.useCallback[applyFilters]"]);
            }
            // ----- Nombre de places -----
            if (search.seats) {
                const seatsNeeded = parseInt(search.seats, 10);
                if (!isNaN(seatsNeeded)) {
                    filtered = filtered.filter({
                        "RidesPage.useCallback[applyFilters]": (ride)=>ride.nb_places_disponible >= seatsNeeded
                    }["RidesPage.useCallback[applyFilters]"]);
                }
            }
            // ----- Date -----
            if (search.date) {
                filtered = filtered.filter({
                    "RidesPage.useCallback[applyFilters]": (ride)=>{
                        const rideDate = new Date(ride.departure_date).toISOString().slice(0, 10);
                        return rideDate === search.date;
                    }
                }["RidesPage.useCallback[applyFilters]"]);
            }
            // ----- Services -----
            if (filter.services.length > 0) {
                filtered = filtered.filter({
                    "RidesPage.useCallback[applyFilters]": (ride)=>filter.services.every({
                            "RidesPage.useCallback[applyFilters]": (service)=>ride.services.map({
                                    "RidesPage.useCallback[applyFilters]": (s)=>s.name
                                }["RidesPage.useCallback[applyFilters]"]).includes(service)
                        }["RidesPage.useCallback[applyFilters]"])
                }["RidesPage.useCallback[applyFilters]"]);
            }
            // ----- Plage horaire -----
            if (filter.departureTimeRange) {
                const [start, end] = filter.departureTimeRange.split("-").map(Number);
                filtered = filtered.filter({
                    "RidesPage.useCallback[applyFilters]": (ride)=>{
                        const hour = new Date(ride.departure_date).getHours();
                        return hour >= start && hour < end;
                    }
                }["RidesPage.useCallback[applyFilters]"]);
            }
            // ----- Tri -----
            filtered.sort({
                "RidesPage.useCallback[applyFilters]": (a, b)=>{
                    switch(filter.sortBy){
                        case "departure_time":
                            return new Date(a.departure_date).getTime() - new Date(b.departure_date).getTime();
                        case "price_low":
                            return parseFloat(a.price) - parseFloat(b.price);
                        case "price_high":
                            return parseFloat(b.price) - parseFloat(a.price);
                        case "seats":
                            return b.nb_places_disponible - a.nb_places_disponible;
                        default:
                            return 0;
                    }
                }
            }["RidesPage.useCallback[applyFilters]"]);
            return filtered;
        }
    }["RidesPage.useCallback[applyFilters]"], []);
    // Refiltrer
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "RidesPage.useEffect": ()=>{
            const filtered = applyFilters(allRides, searchParams, filters);
            setFilteredRides(filtered);
            setTotalPages(Math.max(1, Math.ceil(filtered.length / 10)));
            setCurrentPage(1);
        }
    }["RidesPage.useEffect"], [
        allRides,
        searchParams,
        filters,
        applyFilters
    ]);
    // Pagination
    const pageSize = 10;
    const paginatedRides = filteredRides.slice((currentPage - 1) * pageSize, currentPage * pageSize);
    // Handlers search
    const handleSearchChange = (e)=>{
        const { name, value } = e.target;
        setSearchParams((prev)=>({
                ...prev,
                [name]: value
            }));
    };
    const handleSearchSubmit = (e)=>{
        e.preventDefault();
    // rien : useEffect + applyFilters se déclenchent déjà
    };
    // Handlers sidebar
    const handleSortChange = (sortBy)=>{
        setFilters((prev)=>({
                ...prev,
                sortBy
            }));
    };
    const handleServiceFilter = (service)=>{
        setFilters((prev)=>({
                ...prev,
                services: prev.services.includes(service) ? prev.services.filter((s)=>s !== service) : [
                    ...prev.services,
                    service
                ]
            }));
    };
    const handleClearFilters = ()=>{
        setFilters({
            sortBy: "departure_time",
            services: [],
            departureTimeRange: "",
            seats: ""
        });
    };
    const handleDepartureTimeRangeChange = (range)=>{
        setFilters((prev)=>({
                ...prev,
                departureTimeRange: range
            }));
    };
    const handlePageChange = (page)=>{
        setCurrentPage(page);
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("main", {
        className: "min-h-screen bg-gray-50",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
                className: "bg-white shadow-sm ",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "max-w-7xl mx-auto px-4 py-6",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("form", {
                        onSubmit: handleSearchSubmit,
                        className: "bg-white border border-gray-200 rounded-2xl p-4 md:p-6 shadow-sm",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "grid grid-cols-1 md:grid-cols-4 gap-4 items-end",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                className: "block text-sm font-medium text-gray-700 mb-1",
                                                children: "De"
                                            }, void 0, false, {
                                                fileName: "[project]/app/rides/page.tsx",
                                                lineNumber: 563,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                type: "text",
                                                name: "from",
                                                value: searchParams.from,
                                                onChange: handleSearchChange,
                                                placeholder: "Ex: Sousse, Tunis...",
                                                className: "w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black focus:border-black"
                                            }, void 0, false, {
                                                fileName: "[project]/app/rides/page.tsx",
                                                lineNumber: 566,
                                                columnNumber: 17
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/app/rides/page.tsx",
                                        lineNumber: 562,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                className: "block text-sm font-medium text-gray-700 mb-1",
                                                children: "Vers"
                                            }, void 0, false, {
                                                fileName: "[project]/app/rides/page.tsx",
                                                lineNumber: 578,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                type: "text",
                                                name: "to",
                                                value: searchParams.to,
                                                onChange: handleSearchChange,
                                                placeholder: "Ex: Sfax, Monastir...",
                                                className: "w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black focus:border-black"
                                            }, void 0, false, {
                                                fileName: "[project]/app/rides/page.tsx",
                                                lineNumber: 581,
                                                columnNumber: 17
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/app/rides/page.tsx",
                                        lineNumber: 577,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                className: "block text-sm font-medium text-gray-700 mb-1",
                                                children: "Nombre de places"
                                            }, void 0, false, {
                                                fileName: "[project]/app/rides/page.tsx",
                                                lineNumber: 593,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                type: "number",
                                                min: 1,
                                                name: "seats",
                                                value: searchParams.seats,
                                                onChange: handleSearchChange,
                                                className: "w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black focus:border-black"
                                            }, void 0, false, {
                                                fileName: "[project]/app/rides/page.tsx",
                                                lineNumber: 596,
                                                columnNumber: 17
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/app/rides/page.tsx",
                                        lineNumber: 592,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                className: "block text-sm font-medium text-gray-700 mb-1",
                                                children: "Date"
                                            }, void 0, false, {
                                                fileName: "[project]/app/rides/page.tsx",
                                                lineNumber: 608,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                type: "date",
                                                name: "date",
                                                value: searchParams.date,
                                                onChange: handleSearchChange,
                                                className: "w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black focus:border-black"
                                            }, void 0, false, {
                                                fileName: "[project]/app/rides/page.tsx",
                                                lineNumber: 611,
                                                columnNumber: 17
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/app/rides/page.tsx",
                                        lineNumber: 607,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/rides/page.tsx",
                                lineNumber: 560,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                type: "submit",
                                className: "mt-4 w-full md:w-auto px-6 py-3 bg-black text-white rounded-lg font-semibold hover:bg-gray-900 transition",
                                children: "Rechercher des trajets"
                            }, void 0, false, {
                                fileName: "[project]/app/rides/page.tsx",
                                lineNumber: 621,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/rides/page.tsx",
                        lineNumber: 556,
                        columnNumber: 11
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/app/rides/page.tsx",
                    lineNumber: 555,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/app/rides/page.tsx",
                lineNumber: 553,
                columnNumber: 15
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$common$2f$PageHeader$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                title: "Trajets disponibles",
                searchInfo: searchParams,
                resultCount: filteredRides.length
            }, void 0, false, {
                fileName: "[project]/app/rides/page.tsx",
                lineNumber: 631,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "max-w-7xl mx-auto px-4 py-8",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex gap-8",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$rides$2f$RidesFilterSidebar$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            filters: filters,
                            onSortChange: handleSortChange,
                            onServiceFilter: handleServiceFilter,
                            onClearFilters: handleClearFilters,
                            onDepartureTimeRangeChange: handleDepartureTimeRangeChange,
                            availableServices: availableServices.length > 0 ? availableServices : undefined
                        }, void 0, false, {
                            fileName: "[project]/app/rides/page.tsx",
                            lineNumber: 639,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex-1",
                            children: [
                                loading ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "text-center py-8",
                                    children: "Chargement des trajets..."
                                }, void 0, false, {
                                    fileName: "[project]/app/rides/page.tsx",
                                    lineNumber: 652,
                                    columnNumber: 15
                                }, this) : paginatedRides.length > 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "space-y-4",
                                    children: paginatedRides.map((ride)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$rides$2f$RideCard$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                            ride: ride
                                        }, ride.id, false, {
                                            fileName: "[project]/app/rides/page.tsx",
                                            lineNumber: 658,
                                            columnNumber: 19
                                        }, this))
                                }, void 0, false, {
                                    fileName: "[project]/app/rides/page.tsx",
                                    lineNumber: 656,
                                    columnNumber: 15
                                }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$common$2f$EmptyState$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                                    fileName: "[project]/app/rides/page.tsx",
                                    lineNumber: 662,
                                    columnNumber: 15
                                }, this),
                                filteredRides.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "flex justify-center items-center gap-4 mt-8",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                            className: "px-4 py-2 border rounded disabled:opacity-50",
                                            onClick: ()=>handlePageChange(currentPage - 1),
                                            disabled: currentPage === 1 || loading,
                                            children: "Précédent"
                                        }, void 0, false, {
                                            fileName: "[project]/app/rides/page.tsx",
                                            lineNumber: 667,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            children: [
                                                "Page ",
                                                currentPage,
                                                " of ",
                                                totalPages
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/app/rides/page.tsx",
                                            lineNumber: 674,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                            className: "px-4 py-2 border rounded disabled:opacity-50",
                                            onClick: ()=>handlePageChange(currentPage + 1),
                                            disabled: currentPage === totalPages || loading,
                                            children: "Suivant"
                                        }, void 0, false, {
                                            fileName: "[project]/app/rides/page.tsx",
                                            lineNumber: 677,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/app/rides/page.tsx",
                                    lineNumber: 666,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/rides/page.tsx",
                            lineNumber: 650,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/rides/page.tsx",
                    lineNumber: 638,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/app/rides/page.tsx",
                lineNumber: 637,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/rides/page.tsx",
        lineNumber: 550,
        columnNumber: 5
    }, this);
}
_s(RidesPage, "XFphwAd4cKmI2GGVjmp18scf2hs=");
_c = RidesPage;
var _c;
__turbopack_context__.k.register(_c, "RidesPage");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
}]);

//# sourceMappingURL=_ed9011f3._.js.map