(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([typeof document === "object" ? document.currentScript : undefined, {

"[project]/components/common/PageHeader.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": ()=>PageHeader
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
;
function PageHeader(param) {
    let { title, subtitle, searchInfo, resultCount, className = "" } = param;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "bg-white shadow-sm border-b border-gray-200 ".concat(className),
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "max-w-7xl mx-auto px-4 py-6",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                    className: "text-4xl font-bold mb-6 text-center text-gray-900",
                    children: title
                }, void 0, false, {
                    fileName: "[project]/components/common/PageHeader.tsx",
                    lineNumber: 23,
                    columnNumber: 9
                }, this),
                searchInfo && (searchInfo.from || searchInfo.to) ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "text-center mb-4",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: "text-lg text-gray-600",
                            children: [
                                searchInfo.from && searchInfo.to ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                                    children: [
                                        "Rides from",
                                        " ",
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "font-semibold text-gray-900",
                                            children: searchInfo.from
                                        }, void 0, false, {
                                            fileName: "[project]/components/common/PageHeader.tsx",
                                            lineNumber: 33,
                                            columnNumber: 19
                                        }, this),
                                        " ",
                                        "to",
                                        " ",
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "font-semibold text-gray-900",
                                            children: searchInfo.to
                                        }, void 0, false, {
                                            fileName: "[project]/components/common/PageHeader.tsx",
                                            lineNumber: 37,
                                            columnNumber: 19
                                        }, this)
                                    ]
                                }, void 0, true) : searchInfo.from ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                                    children: [
                                        "Rides from",
                                        " ",
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "font-semibold text-gray-900",
                                            children: searchInfo.from
                                        }, void 0, false, {
                                            fileName: "[project]/components/common/PageHeader.tsx",
                                            lineNumber: 44,
                                            columnNumber: 19
                                        }, this)
                                    ]
                                }, void 0, true) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                                    children: [
                                        "Rides to",
                                        " ",
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "font-semibold text-gray-900",
                                            children: searchInfo.to
                                        }, void 0, false, {
                                            fileName: "[project]/components/common/PageHeader.tsx",
                                            lineNumber: 51,
                                            columnNumber: 19
                                        }, this)
                                    ]
                                }, void 0, true),
                                searchInfo.date && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                                    children: [
                                        " ",
                                        "on",
                                        " ",
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "font-semibold text-gray-900",
                                            children: new Date(searchInfo.date).toLocaleDateString()
                                        }, void 0, false, {
                                            fileName: "[project]/components/common/PageHeader.tsx",
                                            lineNumber: 60,
                                            columnNumber: 19
                                        }, this)
                                    ]
                                }, void 0, true)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/components/common/PageHeader.tsx",
                            lineNumber: 29,
                            columnNumber: 13
                        }, this),
                        typeof resultCount === "number" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: "text-sm text-gray-500 mt-2",
                            children: [
                                resultCount,
                                " ride",
                                resultCount !== 1 ? "s" : "",
                                " found"
                            ]
                        }, void 0, true, {
                            fileName: "[project]/components/common/PageHeader.tsx",
                            lineNumber: 67,
                            columnNumber: 15
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/components/common/PageHeader.tsx",
                    lineNumber: 28,
                    columnNumber: 11
                }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "text-center mb-4",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: "text-lg text-gray-600 mb-2",
                            children: subtitle || "Tous les trajets disponibles"
                        }, void 0, false, {
                            fileName: "[project]/components/common/PageHeader.tsx",
                            lineNumber: 74,
                            columnNumber: 13
                        }, this),
                        typeof resultCount === "number" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: "text-sm text-gray-500",
                            children: [
                                resultCount,
                                " trajet",
                                resultCount !== 1 ? "s" : "",
                                " trouvé"
                            ]
                        }, void 0, true, {
                            fileName: "[project]/components/common/PageHeader.tsx",
                            lineNumber: 78,
                            columnNumber: 15
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/components/common/PageHeader.tsx",
                    lineNumber: 73,
                    columnNumber: 11
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/components/common/PageHeader.tsx",
            lineNumber: 22,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/components/common/PageHeader.tsx",
        lineNumber: 21,
        columnNumber: 5
    }, this);
}
_c = PageHeader;
var _c;
__turbopack_context__.k.register(_c, "PageHeader");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/components/rides/RidesFilterSidebar.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": ()=>RidesFilterSidebar
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
;
// const departureTimeRanges = [
//   { value: "", label: "Any Time" },
//   { value: "0-6", label: "00:00 - 06:00" },
//   { value: "6-12", label: "06:00 - 12:00" },
//   { value: "12-18", label: "12:00 - 18:00" },
//   { value: "18-24", label: "18:00 - 24:00" },
// ];
// const defaultSortOptions: FilterOption[] = [
//   { value: "departure_time", label: "Departure Time" },
//   { value: "price_low", label: "Price: Low to High" },
//   { value: "price_high", label: "Price: High to Low" },
//   { value: "seats", label: "Available Seats" },
// ];
const departureTimeRanges = [
    {
        value: "",
        label: "À tout moment"
    },
    {
        value: "0-6",
        label: "00:00 - 06:00"
    },
    {
        value: "6-12",
        label: "06:00 - 12:00"
    },
    {
        value: "12-18",
        label: "12:00 - 18:00"
    },
    {
        value: "18-24",
        label: "18:00 - 24:00"
    }
];
const defaultSortOptions = [
    {
        value: "departure_time",
        label: "Heure de départ"
    },
    {
        value: "price_low",
        label: "Prix : du plus bas au plus élevé"
    },
    {
        value: "price_high",
        label: "Prix : du plus élevé au plus bas"
    },
    {
        value: "seats",
        label: "Places disponibles"
    }
];
const defaultServices = [
    "Air Conditioning",
    "Music System",
    "WiFi",
    "Phone Charger",
    "Snacks",
    "Water",
    "Pet Friendly",
    "Non-Smoking",
    "Luggage Space"
];
function RidesFilterSidebar(param) {
    let { filters, onSortChange, onServiceFilter, onClearFilters, onDepartureTimeRangeChange, availableServices = defaultServices, className = "" } = param;
    const hasActiveFilters = filters.services.length > 0 || filters.sortBy !== "departure_time";
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "w-80 flex-shrink-0 ".concat(className),
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "bg-white rounded-2xl shadow-xl p-6 sticky top-8",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                    className: "text-xl font-bold text-gray-900 mb-6",
                    children: "Filters"
                }, void 0, false, {
                    fileName: "[project]/components/rides/RidesFilterSidebar.tsx",
                    lineNumber: 77,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "mb-6",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                            className: "text-sm font-semibold text-gray-700 mb-3",
                            children: "Trier par"
                        }, void 0, false, {
                            fileName: "[project]/components/rides/RidesFilterSidebar.tsx",
                            lineNumber: 81,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "space-y-2",
                            children: defaultSortOptions.map((option)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                    className: "flex items-center cursor-pointer",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                            type: "radio",
                                            name: "sortBy",
                                            value: option.value,
                                            checked: filters.sortBy === option.value,
                                            onChange: (e)=>onSortChange(e.target.value),
                                            className: "w-4 h-4 text-gray-600 border-gray-300 focus:ring-gray-500"
                                        }, void 0, false, {
                                            fileName: "[project]/components/rides/RidesFilterSidebar.tsx",
                                            lineNumber: 88,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "ml-3 text-sm text-gray-700",
                                            children: option.label
                                        }, void 0, false, {
                                            fileName: "[project]/components/rides/RidesFilterSidebar.tsx",
                                            lineNumber: 96,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, option.value, true, {
                                    fileName: "[project]/components/rides/RidesFilterSidebar.tsx",
                                    lineNumber: 84,
                                    columnNumber: 15
                                }, this))
                        }, void 0, false, {
                            fileName: "[project]/components/rides/RidesFilterSidebar.tsx",
                            lineNumber: 82,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/components/rides/RidesFilterSidebar.tsx",
                    lineNumber: 80,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "mb-6",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                            className: "text-sm font-semibold text-gray-700 mb-3",
                            children: "Heure de départ"
                        }, void 0, false, {
                            fileName: "[project]/components/rides/RidesFilterSidebar.tsx",
                            lineNumber: 106,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "space-y-2",
                            children: departureTimeRanges.map((range)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                    className: "flex items-center cursor-pointer",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                            type: "radio",
                                            name: "departureTimeRange",
                                            value: range.value,
                                            checked: filters.departureTimeRange === range.value,
                                            onChange: (e)=>onDepartureTimeRangeChange(e.target.value),
                                            className: "w-4 h-4 text-gray-600 border-gray-300 focus:ring-gray-500"
                                        }, void 0, false, {
                                            fileName: "[project]/components/rides/RidesFilterSidebar.tsx",
                                            lineNumber: 115,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "ml-3 text-sm text-gray-700",
                                            children: range.label
                                        }, void 0, false, {
                                            fileName: "[project]/components/rides/RidesFilterSidebar.tsx",
                                            lineNumber: 123,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, range.value, true, {
                                    fileName: "[project]/components/rides/RidesFilterSidebar.tsx",
                                    lineNumber: 111,
                                    columnNumber: 15
                                }, this))
                        }, void 0, false, {
                            fileName: "[project]/components/rides/RidesFilterSidebar.tsx",
                            lineNumber: 109,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/components/rides/RidesFilterSidebar.tsx",
                    lineNumber: 105,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                            className: "text-sm font-semibold text-gray-700 mb-3",
                            children: "Services"
                        }, void 0, false, {
                            fileName: "[project]/components/rides/RidesFilterSidebar.tsx",
                            lineNumber: 133,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "space-y-2 max-h-64 overflow-y-auto",
                            children: availableServices.map((service)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                    className: "flex items-center cursor-pointer",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                            type: "checkbox",
                                            checked: filters.services.includes(service),
                                            onChange: ()=>onServiceFilter(service),
                                            className: "w-4 h-4 text-gray-600 border-gray-300 rounded focus:ring-gray-500"
                                        }, void 0, false, {
                                            fileName: "[project]/components/rides/RidesFilterSidebar.tsx",
                                            lineNumber: 137,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "ml-3 text-sm text-gray-700",
                                            children: service
                                        }, void 0, false, {
                                            fileName: "[project]/components/rides/RidesFilterSidebar.tsx",
                                            lineNumber: 143,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, service, true, {
                                    fileName: "[project]/components/rides/RidesFilterSidebar.tsx",
                                    lineNumber: 136,
                                    columnNumber: 15
                                }, this))
                        }, void 0, false, {
                            fileName: "[project]/components/rides/RidesFilterSidebar.tsx",
                            lineNumber: 134,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/components/rides/RidesFilterSidebar.tsx",
                    lineNumber: 132,
                    columnNumber: 9
                }, this),
                hasActiveFilters && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                    onClick: onClearFilters,
                    className: "mt-6 w-full px-4 py-2 text-sm text-gray-600 border border-gray-300 rounded-lg hover:bg-gray-50 transition",
                    children: "Réinitialiser tous les filtres"
                }, void 0, false, {
                    fileName: "[project]/components/rides/RidesFilterSidebar.tsx",
                    lineNumber: 151,
                    columnNumber: 11
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/components/rides/RidesFilterSidebar.tsx",
            lineNumber: 76,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/components/rides/RidesFilterSidebar.tsx",
        lineNumber: 75,
        columnNumber: 5
    }, this);
}
_c = RidesFilterSidebar;
var _c;
__turbopack_context__.k.register(_c, "RidesFilterSidebar");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/components/rides/RideCard.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
// import Link from "next/link";
// import Image from "next/image";
// export interface RideData {
//   id: number;
//   user: {
//     id: number;
//     first_name: string;
//     last_name: string;
//     username: string;
//     email?: string;
//     review_score?: number;
//     review_numbers?: number;
//     professional?: boolean;
//     current_package_plan?: { package: string };
//     subscription_status?: string;
//     joining_date?: string;
//     date_joined?: string;
//     avatar?: string;
//     profile_picture?: string;
//     phone_number?: string;
//     bio?: string;
//     active?: boolean;
//   };
//   car: {
//     id: number;
//   model_details?: {
//     id: number;
//     name: string;
//     brand: {
//       id: number;
//       name: string;
//     };
//   },    type: string;
//     color: string;
//       color_details?: { id: number; name: string; code: string } | null;
//     serial_number: string;
//     nb_place: number;
//     engine_type: string;
//     grey_card: string;
//     year?: number;
//     image?: string | null;
//     owner: number;
//   };
//   services: {
//     id: number;
//     name: string;
//     description: string;
//     active: boolean;
//     logo: string | null;
//   }[];
//   departure_date: string;
//   departure_place: string;
//   departure_city?: string; // Nom de la ville de départ
//   arrival_place: string;
//   arrival_city?: string; // Nom de la ville d'arrivée
//   status: string;
//   nb_places_disponible: number;
//   price: string;
//   equivalent_price?: string | null;
//   round_trip: boolean;
// }
// interface RideCardProps {
//   ride: RideData;
//   className?: string;
// }
// function renderStars(rating: number) {
//   const stars = [];
//   const fullStars = Math.floor(rating);
//   const hasHalfStar = rating % 1 >= 0.5;
//   for (let i = 0; i < fullStars; i++) {
//     stars.push(
//       <span key={i} className="text-yellow-400">
//         ★
//       </span>
//     );
//   }
//   if (hasHalfStar) {
//     stars.push(
//       <span key="half" className="text-yellow-400">
//         ☆
//       </span>
//     );
//   }
//   for (let i = stars.length; i < 5; i++) {
//     stars.push(
//       <span key={i} className="text-gray-300">
//         ☆
//       </span>
//     );
//   }
//   return stars;
// }
// export default function RideCard({ ride, className = "" }: RideCardProps) {
//   //  const departure = new Date(ride.departure_date);
//   // const now = new Date();
//   //   const FOUR_HOURS_MS = 4 * 60 * 60 * 1000;
//   // if (now.getTime() - departure.getTime() > FOUR_HOURS_MS) {
//   //   return null;
//   // }
//   // Driver info
//   const user = ride.user;
//   const name =
//     `${user.first_name || ""} ${user.last_name || ""}`.trim() || user.username;
//   const avatar =
//     user.avatar ||
//     user.profile_picture ||
//     "https://static.vecteezy.com/system/resources/thumbnails/020/765/399/small_2x/default-profile-account-unknown-icon-black-silhouette-free-vector.jpg";
//   const rating = user.review_score || 0;
//   const reviewNumbers = user.review_numbers || 0;
//   const isProfessional = user.professional;
//   // Car info
//   const car = ride.car;
//   const carName = car.model_details?.brand.name
//     ? `${car.model_details.name} (${car.type}, ${car.color_details?.name})`
//     : `${car.type}, ${car.color_details?.name}`;
//   // Services
//   const services = ride.services.map((s) => s.name);
//   return (
//     <Link
//       href={`/rides/${ride.id}`}
//       className={`block bg-white border border-gray-200 rounded-2xl shadow-lg hover:shadow-xl transition-all duration-300 p-6 group ${className}`}
//     >
//       <div className="flex items-center justify-between">
//         {/* Left Side - Driver & Route */}
//         <div className="flex items-center gap-6 flex-1">
//           {/* Driver Info */}
//           <div className="flex items-center gap-4">
//             <Image
//               src={avatar}
//               alt={name}
//               width={64}
//               height={64}
//               className="rounded-full border-2 border-gray-200 shadow-md"
//             />
//             <div>
//               <div className="font-semibold text-lg text-gray-900 group-hover:text-gray-700 transition flex items-center gap-2">
//                 {name}
//                 {isProfessional && (
//                   <span className="ml-2 px-2 py-1 bg-blue-100 text-blue-700 text-xs rounded-full font-semibold">
//                     Pro
//                   </span>
//                 )}
//               </div>
//               <div className="text-sm text-gray-500">{carName}</div>
//               <div className="flex items-center gap-1 mt-1">
//                 {renderStars(rating)}
//                 <span className="text-sm text-gray-500 ml-1">
//                   ({rating.toFixed(1)})
//                 </span>
//                 <span className="text-gray-400 text-xs ml-2">
//                   {reviewNumbers} reviews
//                 </span>
//               </div>
//             </div>
//           </div>
//           {/* Route */}
//           <div className="flex-1 min-w-0">
//             <div className="flex items-center gap-3 mb-2">
//               {/* Départ */}
//               <div className="flex flex-col">
//                 <div className="text-xl font-bold text-gray-900">
//                   {ride.departure_place}
//                 </div>
//                 {ride.departure_city && (
//                   <div className="text-xs text-gray-500 mt-0.5">
//                     {ride.departure_city}
//                   </div>
//                 )}
//               </div>
//               <div className="text-gray-400 text-2xl">→</div>
//               {/* Arrivée */}
//               <div className="flex flex-col">
//                 <div className="text-xl font-bold text-gray-900">
//                   {ride.arrival_place}
//                 </div>
//                 {ride.arrival_city && (
//                   <div className="text-xs text-gray-500 mt-0.5">
//                     {ride.arrival_city}
//                   </div>
//                 )}
//               </div>
//             </div>
//             {/* Date & Time */}
//             <div className="text-sm text-gray-600">
//               {new Date(ride.departure_date).toLocaleDateString("en-US", {
//                 weekday: "short",
//                 month: "short",
//                 day: "numeric",
//                 year: "numeric",
//                   timeZone: "UTC",          // empêche l’ajout de +1h
//   })}{" "}
//   at{" "}
//               {new Date(ride.departure_date).toLocaleTimeString("en-US", {
//                 hour: "2-digit",
//                 minute: "2-digit",
//                     timeZone: "UTC",          // affiche l’heure telle que stockée
//               })}
//             </div>
//             {/* Services */}
//             <div className="flex flex-wrap gap-1 mt-2">
//               {services.slice(0, 4).map((service, index) => (
//                 <span
//                   key={index}
//                   className="px-2 py-1 bg-gray-100 text-gray-600 text-xs rounded-full"
//                 >
//                   {service}
//                 </span>
//               ))}
//               {services.length > 4 && (
//                 <span className="px-2 py-1 bg-gray-200 text-gray-500 text-xs rounded-full">
//                   +{services.length - 4} more
//                 </span>
//               )}
//             </div>
//           </div>
//         </div>
//         {/* Right Side - Price & Seats */}
//         <div className="text-right flex-shrink-0 ml-6 min-w-[120px]">
//           <div className="text-3xl font-bold text-gray-900 mb-2">
//             {ride.price} TND
//           </div>
//           <div className="flex items-center gap-1 text-sm text-gray-500 justify-end">
//             <span>👥</span>
//             <span>
//               {ride.nb_places_disponible} seat
//               {ride.nb_places_disponible !== 1 ? "s" : ""} left
//             </span>
//           </div>
//           {ride.round_trip && (
//             <div className="mt-1 text-xs text-blue-600 font-semibold">
//               Round Trip
//             </div>
//           )}
//         </div>
//       </div>
//     </Link>
//   );
// }
__turbopack_context__.s({
    "default": ()=>RideCard
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/app-dir/link.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/image.js [app-client] (ecmascript)");
;
;
;
function renderStars(rating) {
    const stars = [];
    const fullStars = Math.floor(rating);
    const hasHalfStar = rating % 1 >= 0.5;
    for(let i = 0; i < fullStars; i++){
        stars.push(/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
            className: "text-yellow-400 text-xs",
            children: "★"
        }, "full-".concat(i), false, {
            fileName: "[project]/components/rides/RideCard.tsx",
            lineNumber: 328,
            columnNumber: 7
        }, this));
    }
    if (hasHalfStar) {
        stars.push(/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
            className: "text-yellow-400 text-xs",
            children: "☆"
        }, "half", false, {
            fileName: "[project]/components/rides/RideCard.tsx",
            lineNumber: 336,
            columnNumber: 7
        }, this));
    }
    for(let i = stars.length; i < 5; i++){
        stars.push(/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
            className: "text-gray-300 text-xs",
            children: "☆"
        }, "empty-".concat(i), false, {
            fileName: "[project]/components/rides/RideCard.tsx",
            lineNumber: 344,
            columnNumber: 7
        }, this));
    }
    return stars;
}
function RideCard(param) {
    let { ride, className = "" } = param;
    var _car_model_details, _car_color_details, _car_color_details1;
    // Driver info
    const user = ride.user;
    const name = "".concat(user.first_name || "", " ").concat(user.last_name || "").trim() || user.username;
    const avatar = user.avatar || user.profile_picture || "https://static.vecteezy.com/system/resources/thumbnails/020/765/399/small_2x/default-profile-account-unknown-icon-black-silhouette-free-vector.jpg";
    const rating = user.review_score || 0;
    const reviewNumbers = user.review_numbers || 0;
    const isProfessional = user.professional;
    // Car info
    const car = ride.car;
    const carName = ((_car_model_details = car.model_details) === null || _car_model_details === void 0 ? void 0 : _car_model_details.brand.name) ? "".concat(car.model_details.name, " (").concat(car.type, ", ").concat((_car_color_details = car.color_details) === null || _car_color_details === void 0 ? void 0 : _car_color_details.name, ")") : "".concat(car.type, ", ").concat((_car_color_details1 = car.color_details) === null || _car_color_details1 === void 0 ? void 0 : _car_color_details1.name);
    // Services
    const services = ride.services.map((s)=>s.name);
    const departureDate = new Date(ride.departure_date);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
        href: "/rides/".concat(ride.id),
        className: "block w-full ".concat(className),
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "w-full bg-white border border-gray-200 rounded-2xl shadow-lg hover:shadow-xl transition-all duration-300 p-4 sm:p-6 group",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex flex-col md:flex-row md:items-center md:justify-between gap-4",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex flex-col sm:flex-row gap-4 md:gap-6 flex-1",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex items-center gap-3 sm:gap-4",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                        src: avatar,
                                        alt: name,
                                        width: 64,
                                        height: 64,
                                        className: "w-14 h-14 sm:w-16 sm:h-16 rounded-full border-2 border-gray-200 shadow-md object-cover flex-shrink-0"
                                    }, void 0, false, {
                                        fileName: "[project]/components/rides/RideCard.tsx",
                                        lineNumber: 386,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "font-semibold text-base sm:text-lg text-gray-900 group-hover:text-gray-700 transition flex items-center gap-2",
                                                children: [
                                                    name,
                                                    isProfessional && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: "px-2 py-1 bg-blue-100 text-blue-700 text-[10px] sm:text-xs rounded-full font-semibold",
                                                        children: "Pro"
                                                    }, void 0, false, {
                                                        fileName: "[project]/components/rides/RideCard.tsx",
                                                        lineNumber: 397,
                                                        columnNumber: 21
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/components/rides/RideCard.tsx",
                                                lineNumber: 394,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "text-xs sm:text-sm text-gray-500 line-clamp-1",
                                                children: carName
                                            }, void 0, false, {
                                                fileName: "[project]/components/rides/RideCard.tsx",
                                                lineNumber: 402,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "flex items-center gap-1 mt-1 text-xs",
                                                children: [
                                                    renderStars(rating),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: "text-gray-500 ml-1",
                                                        children: [
                                                            "(",
                                                            rating.toFixed(1),
                                                            ")"
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/components/rides/RideCard.tsx",
                                                        lineNumber: 407,
                                                        columnNumber: 19
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: "text-gray-400 text-[11px] ml-2",
                                                        children: [
                                                            reviewNumbers,
                                                            " reviews"
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/components/rides/RideCard.tsx",
                                                        lineNumber: 410,
                                                        columnNumber: 19
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/components/rides/RideCard.tsx",
                                                lineNumber: 405,
                                                columnNumber: 17
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/components/rides/RideCard.tsx",
                                        lineNumber: 393,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/components/rides/RideCard.tsx",
                                lineNumber: 385,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex-1 min-w-0",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "flex items-start gap-3 mb-2",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "flex flex-col flex-1 min-w-0",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "text-base sm:text-xl font-bold text-gray-900 truncate",
                                                        children: ride.departure_place
                                                    }, void 0, false, {
                                                        fileName: "[project]/components/rides/RideCard.tsx",
                                                        lineNumber: 422,
                                                        columnNumber: 19
                                                    }, this),
                                                    ride.departure_city && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "text-xs text-gray-500 mt-0.5 truncate",
                                                        children: ride.departure_city
                                                    }, void 0, false, {
                                                        fileName: "[project]/components/rides/RideCard.tsx",
                                                        lineNumber: 426,
                                                        columnNumber: 21
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/components/rides/RideCard.tsx",
                                                lineNumber: 421,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "text-gray-400 text-lg sm:text-2xl mt-1 sm:mt-0",
                                                children: "→"
                                            }, void 0, false, {
                                                fileName: "[project]/components/rides/RideCard.tsx",
                                                lineNumber: 432,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "flex flex-col flex-1 min-w-0 text-right sm:text-left",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "text-base sm:text-xl font-bold text-gray-900 truncate",
                                                        children: ride.arrival_place
                                                    }, void 0, false, {
                                                        fileName: "[project]/components/rides/RideCard.tsx",
                                                        lineNumber: 438,
                                                        columnNumber: 19
                                                    }, this),
                                                    ride.arrival_city && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "text-xs text-gray-500 mt-0.5 truncate",
                                                        children: ride.arrival_city
                                                    }, void 0, false, {
                                                        fileName: "[project]/components/rides/RideCard.tsx",
                                                        lineNumber: 442,
                                                        columnNumber: 21
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/components/rides/RideCard.tsx",
                                                lineNumber: 437,
                                                columnNumber: 17
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/components/rides/RideCard.tsx",
                                        lineNumber: 419,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "text-xs sm:text-sm text-gray-600",
                                        children: [
                                            departureDate.toLocaleDateString("en-US", {
                                                weekday: "short",
                                                month: "short",
                                                day: "numeric",
                                                year: "numeric",
                                                timeZone: "UTC"
                                            }),
                                            " ",
                                            "at",
                                            " ",
                                            departureDate.toLocaleTimeString("en-US", {
                                                hour: "2-digit",
                                                minute: "2-digit",
                                                timeZone: "UTC"
                                            })
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/components/rides/RideCard.tsx",
                                        lineNumber: 450,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "flex flex-wrap gap-1 mt-2",
                                        children: [
                                            services.slice(0, 4).map((service, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: "px-2 py-1 bg-gray-100 text-gray-600 text-[11px] sm:text-xs rounded-full",
                                                    children: service
                                                }, index, false, {
                                                    fileName: "[project]/components/rides/RideCard.tsx",
                                                    lineNumber: 469,
                                                    columnNumber: 19
                                                }, this)),
                                            services.length > 4 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "px-2 py-1 bg-gray-200 text-gray-500 text-[11px] sm:text-xs rounded-full",
                                                children: [
                                                    "+",
                                                    services.length - 4,
                                                    " more"
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/components/rides/RideCard.tsx",
                                                lineNumber: 477,
                                                columnNumber: 19
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/components/rides/RideCard.tsx",
                                        lineNumber: 467,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/components/rides/RideCard.tsx",
                                lineNumber: 418,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/rides/RideCard.tsx",
                        lineNumber: 383,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex flex-row md:flex-col items-end justify-between md:justify-center text-right flex-shrink-0 md:ml-6 min-w-[120px]",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "text-xl sm:text-3xl font-bold text-gray-900 mb-1 sm:mb-2",
                                children: [
                                    ride.price,
                                    " TND"
                                ]
                            }, void 0, true, {
                                fileName: "[project]/components/rides/RideCard.tsx",
                                lineNumber: 487,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex items-center gap-1 text-xs sm:text-sm text-gray-500 justify-end",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        children: "👥"
                                    }, void 0, false, {
                                        fileName: "[project]/components/rides/RideCard.tsx",
                                        lineNumber: 491,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        children: [
                                            ride.nb_places_disponible,
                                            " seat",
                                            ride.nb_places_disponible !== 1 ? "s" : "",
                                            " left"
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/components/rides/RideCard.tsx",
                                        lineNumber: 492,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/components/rides/RideCard.tsx",
                                lineNumber: 490,
                                columnNumber: 13
                            }, this),
                            ride.round_trip && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "mt-1 text-[11px] sm:text-xs text-blue-600 font-semibold",
                                children: "Round Trip"
                            }, void 0, false, {
                                fileName: "[project]/components/rides/RideCard.tsx",
                                lineNumber: 498,
                                columnNumber: 15
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/rides/RideCard.tsx",
                        lineNumber: 486,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/rides/RideCard.tsx",
                lineNumber: 381,
                columnNumber: 9
            }, this)
        }, void 0, false, {
            fileName: "[project]/components/rides/RideCard.tsx",
            lineNumber: 379,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/components/rides/RideCard.tsx",
        lineNumber: 378,
        columnNumber: 5
    }, this);
}
_c = RideCard;
var _c;
__turbopack_context__.k.register(_c, "RideCard");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/components/common/EmptyState.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": ()=>EmptyState
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/app-dir/link.js [app-client] (ecmascript)");
;
;
function EmptyState(param) {
    let { icon = "🚗", title = "Rejoignez Namlaa pour continuer", description = "Veuillez vous inscrire pour continuer et accéder à toutes les fonctionnalités.", actionText = "S’inscrire", actionHref = "/auth/signup", className = "" } = param;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "text-center py-12 ".concat(className),
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "w-20 h-20 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-6",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                    className: "text-3xl",
                    children: icon
                }, void 0, false, {
                    fileName: "[project]/components/common/EmptyState.tsx",
                    lineNumber: 23,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/components/common/EmptyState.tsx",
                lineNumber: 22,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                className: "text-2xl font-bold text-gray-900 mb-4",
                children: title
            }, void 0, false, {
                fileName: "[project]/components/common/EmptyState.tsx",
                lineNumber: 25,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "text-gray-600 mb-6",
                children: description
            }, void 0, false, {
                fileName: "[project]/components/common/EmptyState.tsx",
                lineNumber: 26,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                href: actionHref,
                className: "inline-block px-6 py-3 bg-black text-white rounded-lg hover:bg-gray-800 transition font-semibold",
                children: actionText
            }, void 0, false, {
                fileName: "[project]/components/common/EmptyState.tsx",
                lineNumber: 27,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/components/common/EmptyState.tsx",
        lineNumber: 21,
        columnNumber: 5
    }, this);
}
_c = EmptyState;
var _c;
__turbopack_context__.k.register(_c, "EmptyState");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/app/rides/page.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
// "use client";
// import { useState, useEffect, useCallback } from "react";
// import api from "../../api/api";
// import PageHeader from "../../components/common/PageHeader";
// import RidesFilterSidebar from "../../components/rides/RidesFilterSidebar";
// import RideCard, { RideData } from "../../components/rides/RideCard";
// import EmptyState from "../../components/common/EmptyState";
// import SearchForm from "../../components/home/SearchForm";
// type SearchParams = {
//   from: string;
//   to: string;
//   date: string;
//   seats: string;
// };
// type Filters = {
//   sortBy: string;
//   services: string[];
//   departureTimeRange: string;
//   seats: string;
// };
// export default function RidesPage() {
//   const [searchParams, setSearchParams] = useState<SearchParams>({
//     from: "",
//     to: "",
//     date: "",
//     seats: "1",
//   });
//   const [filters, setFilters] = useState<Filters>({
//     sortBy: "departure_time",
//     services: [],
//     departureTimeRange: "",
//     seats: "",
//   });
//   const [allRides, setAllRides] = useState<RideData[]>([]);
//   const [availableServices, setAvailableServices] = useState<string[]>([]);
//   const [loading, setLoading] = useState(false);
//   const [filteredRides, setFilteredRides] = useState<RideData[]>([]);
//   const [currentPage, setCurrentPage] = useState(1);
//   const [totalPages, setTotalPages] = useState(1);
//   // Fetch rides
//   const fetchRides = useCallback(async (url: string = "/api/posts/") => {
//     setLoading(true);
//     try {
//       const res = await api.get(url);
//       const rides = Array.isArray(res.data) ? res.data : res.data.results || [];
//       setAllRides(rides);
//     } catch {
//       setAllRides([]);
//     } finally {
//       setLoading(false);
//     }
//   }, []);
//   // Read URL params on first load
//   useEffect(() => {
//     if (typeof window === "undefined") return;
//     const urlParams = new URLSearchParams(window.location.search);
//     const params: SearchParams = {
//       from: urlParams.get("from") || "",
//       to: urlParams.get("to") || "",
//       date: urlParams.get("date") || "",
//       seats: urlParams.get("seats") || "1",
//     };
//     setSearchParams(params);
//     const query = new URLSearchParams();
//     Object.entries(params).forEach(([key, value]) => {
//       if (value) query.append(key, value);
//     });
//     const page = urlParams.get("page");
//     if (page) setCurrentPage(parseInt(page, 10) || 1);
//     fetchRides(`/api/posts/?${query.toString()}`);
//   }, [fetchRides]);
//   // Fetch services
//   useEffect(() => {
//     api
//       .get("/api/services/")
//       .then((res) => {
//         const services = Array.isArray(res.data) ? res.data : [];
//         const names = services
//           .map((s: { name: string }) => s.name)
//           .filter(Boolean);
//         setAvailableServices(names);
//       })
//       .catch(() => setAvailableServices([]));
//   }, []);
//   // Filtering logic
//   const applyFilters = useCallback(
//     (rides: RideData[], search: SearchParams, filter: Filters) => {
//       let filtered = [...rides];
//       if (search.from) {
//         filtered = filtered.filter((ride) =>
//           ride.departure_place
//             .toLowerCase()
//             .includes(search.from.toLowerCase())
//         );
//       }
//       if (search.to) {
//         filtered = filtered.filter((ride) =>
//           ride.arrival_place.toLowerCase().includes(search.to.toLowerCase())
//         );
//       }
//       if (search.seats) {
//         const seatsNeeded = parseInt(search.seats, 10);
//         if (!isNaN(seatsNeeded)) {
//           filtered = filtered.filter(
//             (ride) => ride.nb_places_disponible >= seatsNeeded
//           );
//         }
//       }
//       if (search.date) {
//         filtered = filtered.filter((ride) => {
//           const rideDate = new Date(ride.departure_date)
//             .toISOString()
//             .slice(0, 10);
//           return rideDate === search.date;
//         });
//       }
//       if (filter.services.length > 0) {
//         filtered = filtered.filter((ride) =>
//           filter.services.every((service) =>
//             ride.services.map((s: { name: string }) => s.name)
//               .includes(service)
//           )
//         );
//       }
//       if (filter.departureTimeRange) {
//         const [start, end] = filter.departureTimeRange
//           .split("-")
//           .map(Number);
//         filtered = filtered.filter((ride) => {
//           const hour = new Date(ride.departure_date).getHours();
//           return hour >= start && hour < end;
//         });
//       }
//       filtered.sort((a, b) => {
//         switch (filter.sortBy) {
//           case "departure_time":
//             return (
//               new Date(a.departure_date).getTime() -
//               new Date(b.departure_date).getTime()
//             );
//           case "price_low":
//             return parseFloat(a.price) - parseFloat(b.price);
//           case "price_high":
//             return parseFloat(b.price) - parseFloat(a.price);
//           case "seats":
//             return b.nb_places_disponible - a.nb_places_disponible;
//           default:
//             return 0;
//         }
//       });
//       return filtered;
//     },
//     []
//   );
//   // Apply filters whenever data or filters change
//   useEffect(() => {
//     const filtered = applyFilters(allRides, searchParams, filters);
//     setFilteredRides(filtered);
//     setTotalPages(Math.max(1, Math.ceil(filtered.length / 10)));
//     setCurrentPage(1);
//   }, [allRides, searchParams, filters, applyFilters]);
//   // Pagination
//   const pageSize = 10;
//   const paginatedRides = filteredRides.slice(
//     (currentPage - 1) * pageSize,
//     currentPage * pageSize
//   );
//   // Handlers
//   const handleSearch = (formData: SearchParams) => {
//     const params = new URLSearchParams();
//     Object.entries(formData).forEach(([key, value]) => {
//       if (value) params.append(key, value);
//     });
//     if (typeof window !== "undefined") {
//       window.history.replaceState(null, "", `/rides?${params.toString()}`);
//     }
//     setSearchParams(formData);
//     fetchRides(`/api/posts/?${params.toString()}`);
//   };
//   const handleSortChange = (sortBy: string) => {
//     setFilters((prev) => ({ ...prev, sortBy }));
//   };
//   const handleServiceFilter = (service: string) => {
//     setFilters((prev) => ({
//       ...prev,
//       services: prev.services.includes(service)
//         ? prev.services.filter((s) => s !== service)
//         : [...prev.services, service],
//     }));
//   };
//   const handleClearFilters = () => {
//     setFilters({
//       sortBy: "departure_time",
//       services: [],
//       departureTimeRange: "",
//       seats: "",
//     });
//   };
//   const handleDepartureTimeRangeChange = (range: string) => {
//     setFilters((prev) => ({ ...prev, departureTimeRange: range }));
//   };
//   const handlePageChange = (page: number) => {
//     setCurrentPage(page);
//     if (typeof window !== "undefined") {
//       const urlParams = new URLSearchParams(window.location.search);
//       urlParams.set("page", page.toString());
//       window.history.replaceState(
//         null,
//         "",
//         `/rides?${urlParams.toString()}`
//       );
//     }
//   };
//   return (
//     <main className="min-h-screen bg-gray-50">
//   <SearchForm
//     initialData={searchParams}
//     onSearch={handleSearch}
//     title="Trouver le meilleur trajet pour vous"
//     className="pt-4 pb-0"
//   />
//       <PageHeader
//         title="Trajets disponibles"
//         searchInfo={searchParams}
//         resultCount={filteredRides.length}
//       />
//       <div className="max-w-7xl mx-auto px-4 py-8">
//         <div className="flex gap-8">
//           <RidesFilterSidebar
//             filters={filters}
//             onSortChange={handleSortChange}
//             onServiceFilter={handleServiceFilter}
//             onClearFilters={handleClearFilters}
//             onDepartureTimeRangeChange={handleDepartureTimeRangeChange}
//             availableServices={
//               availableServices.length > 0 ? availableServices : undefined
//             }
//           />
//           <div className="flex-1">
//             {loading ? (
//               <div className="text-center py-8">Charrgement des trajets...</div>
//             ) : paginatedRides.length > 0 ? (
//               <div className="space-y-4">
//                 {paginatedRides.map((ride) => (
//                   <RideCard key={ride.id} ride={ride} />
//                 ))}
//               </div>
//             ) : (
//               <EmptyState />
//             )}
//             {filteredRides.length > 0 && (
//               <div className="flex justify-center items-center gap-4 mt-8">
//                 <button
//                   className="px-4 py-2 border rounded disabled:opacity-50"
//                   onClick={() => handlePageChange(currentPage - 1)}
//                   disabled={currentPage === 1 || loading}
//                 >
//                   Précédent
//                 </button>
//                 <span>
//                   Page {currentPage} of {totalPages}
//                 </span>
//                 <button
//                   className="px-4 py-2 border rounded disabled:opacity-50"
//                   onClick={() => handlePageChange(currentPage + 1)}
//                   disabled={currentPage === totalPages || loading}
//                 >
//                   Suivant
//                 </button>
//               </div>
//             )}
//           </div>
//         </div>
//       </div>
//     </main>
//   );
// }
__turbopack_context__.s({
    "default": ()=>RidesPage
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$api$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/api/api.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$common$2f$PageHeader$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/common/PageHeader.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$rides$2f$RidesFilterSidebar$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/rides/RidesFilterSidebar.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$rides$2f$RideCard$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/rides/RideCard.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$common$2f$EmptyState$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/common/EmptyState.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
function RidesPage() {
    _s();
    const [searchParams, setSearchParams] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({
        from: "",
        to: "",
        date: "",
        seats: "1"
    });
    const [filters, setFilters] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({
        sortBy: "departure_time",
        services: [],
        departureTimeRange: "",
        seats: ""
    });
    const [allRides, setAllRides] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [availableServices, setAvailableServices] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [loading, setLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [filteredRides, setFilteredRides] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [currentPage, setCurrentPage] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(1);
    const [totalPages, setTotalPages] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(1);
    // Fetch rides une seule fois (sans params)
    const fetchRides = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "RidesPage.useCallback[fetchRides]": async ()=>{
            setLoading(true);
            try {
                const res = await __TURBOPACK__imported__module__$5b$project$5d2f$api$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].get("/api/posts/");
                const rides = Array.isArray(res.data) ? res.data : res.data.results || [];
                setAllRides(rides);
            } catch (e) {
                setAllRides([]);
            } finally{
                setLoading(false);
            }
        }
    }["RidesPage.useCallback[fetchRides]"], []);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "RidesPage.useEffect": ()=>{
            fetchRides();
        }
    }["RidesPage.useEffect"], [
        fetchRides
    ]);
    // Fetch services
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "RidesPage.useEffect": ()=>{
            __TURBOPACK__imported__module__$5b$project$5d2f$api$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].get("/api/services/").then({
                "RidesPage.useEffect": (res)=>{
                    const services = Array.isArray(res.data) ? res.data : [];
                    const names = services.map({
                        "RidesPage.useEffect.names": (s)=>s.name
                    }["RidesPage.useEffect.names"]).filter(Boolean);
                    setAvailableServices(names);
                }
            }["RidesPage.useEffect"]).catch({
                "RidesPage.useEffect": ()=>setAvailableServices([])
            }["RidesPage.useEffect"]);
        }
    }["RidesPage.useEffect"], []);
    // Filtrage JSON (délégation + ville)
    const applyFilters = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "RidesPage.useCallback[applyFilters]": (rides, search, filter)=>{
            let filtered = [
                ...rides
            ];
            // ----- De / Vers (délégation + ville) -----
            if (search.from && search.to) {
                const fromVal = search.from.toLowerCase();
                const toVal = search.to.toLowerCase();
                filtered = filtered.filter({
                    "RidesPage.useCallback[applyFilters]": (ride)=>{
                        const depPlace = ride.departure_place.toLowerCase();
                        const depCity = (ride.departure_city || "").toLowerCase();
                        const arrPlace = ride.arrival_place.toLowerCase();
                        const arrCity = (ride.arrival_city || "").toLowerCase();
                        const matchFrom = depPlace.includes(fromVal) || depCity.includes(fromVal);
                        const matchTo = arrPlace.includes(toVal) || arrCity.includes(toVal);
                        return matchFrom && matchTo;
                    }
                }["RidesPage.useCallback[applyFilters]"]);
            } else if (search.from) {
                const fromVal = search.from.toLowerCase();
                filtered = filtered.filter({
                    "RidesPage.useCallback[applyFilters]": (ride)=>{
                        const depPlace = ride.departure_place.toLowerCase();
                        const depCity = (ride.departure_city || "").toLowerCase();
                        return depPlace.includes(fromVal) || depCity.includes(fromVal);
                    }
                }["RidesPage.useCallback[applyFilters]"]);
            } else if (search.to) {
                const toVal = search.to.toLowerCase();
                filtered = filtered.filter({
                    "RidesPage.useCallback[applyFilters]": (ride)=>{
                        const arrPlace = ride.arrival_place.toLowerCase();
                        const arrCity = (ride.arrival_city || "").toLowerCase();
                        return arrPlace.includes(toVal) || arrCity.includes(toVal);
                    }
                }["RidesPage.useCallback[applyFilters]"]);
            }
            // ----- Nombre de places -----
            if (search.seats) {
                const seatsNeeded = parseInt(search.seats, 10);
                if (!isNaN(seatsNeeded)) {
                    filtered = filtered.filter({
                        "RidesPage.useCallback[applyFilters]": (ride)=>ride.nb_places_disponible >= seatsNeeded
                    }["RidesPage.useCallback[applyFilters]"]);
                }
            }
            // ----- Date -----
            if (search.date) {
                filtered = filtered.filter({
                    "RidesPage.useCallback[applyFilters]": (ride)=>{
                        const rideDate = new Date(ride.departure_date).toISOString().slice(0, 10);
                        return rideDate === search.date;
                    }
                }["RidesPage.useCallback[applyFilters]"]);
            }
            // ----- Services -----
            if (filter.services.length > 0) {
                filtered = filtered.filter({
                    "RidesPage.useCallback[applyFilters]": (ride)=>filter.services.every({
                            "RidesPage.useCallback[applyFilters]": (service)=>ride.services.map({
                                    "RidesPage.useCallback[applyFilters]": (s)=>s.name
                                }["RidesPage.useCallback[applyFilters]"]).includes(service)
                        }["RidesPage.useCallback[applyFilters]"])
                }["RidesPage.useCallback[applyFilters]"]);
            }
            // ----- Plage horaire -----
            if (filter.departureTimeRange) {
                const [start, end] = filter.departureTimeRange.split("-").map(Number);
                filtered = filtered.filter({
                    "RidesPage.useCallback[applyFilters]": (ride)=>{
                        const hour = new Date(ride.departure_date).getHours();
                        return hour >= start && hour < end;
                    }
                }["RidesPage.useCallback[applyFilters]"]);
            }
            // ----- Tri -----
            filtered.sort({
                "RidesPage.useCallback[applyFilters]": (a, b)=>{
                    switch(filter.sortBy){
                        case "departure_time":
                            return new Date(a.departure_date).getTime() - new Date(b.departure_date).getTime();
                        case "price_low":
                            return parseFloat(a.price) - parseFloat(b.price);
                        case "price_high":
                            return parseFloat(b.price) - parseFloat(a.price);
                        case "seats":
                            return b.nb_places_disponible - a.nb_places_disponible;
                        default:
                            return 0;
                    }
                }
            }["RidesPage.useCallback[applyFilters]"]);
            return filtered;
        }
    }["RidesPage.useCallback[applyFilters]"], []);
    // Refiltrer
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "RidesPage.useEffect": ()=>{
            const filtered = applyFilters(allRides, searchParams, filters);
            setFilteredRides(filtered);
            setTotalPages(Math.max(1, Math.ceil(filtered.length / 10)));
            setCurrentPage(1);
        }
    }["RidesPage.useEffect"], [
        allRides,
        searchParams,
        filters,
        applyFilters
    ]);
    // Pagination
    const pageSize = 10;
    const paginatedRides = filteredRides.slice((currentPage - 1) * pageSize, currentPage * pageSize);
    // Handlers search
    const handleSearchChange = (e)=>{
        const { name, value } = e.target;
        setSearchParams((prev)=>({
                ...prev,
                [name]: value
            }));
    };
    const handleSearchSubmit = (e)=>{
        e.preventDefault();
    // rien : useEffect + applyFilters se déclenchent déjà
    };
    // Handlers sidebar
    const handleSortChange = (sortBy)=>{
        setFilters((prev)=>({
                ...prev,
                sortBy
            }));
    };
    const handleServiceFilter = (service)=>{
        setFilters((prev)=>({
                ...prev,
                services: prev.services.includes(service) ? prev.services.filter((s)=>s !== service) : [
                    ...prev.services,
                    service
                ]
            }));
    };
    const handleClearFilters = ()=>{
        setFilters({
            sortBy: "departure_time",
            services: [],
            departureTimeRange: "",
            seats: ""
        });
    };
    const handleDepartureTimeRangeChange = (range)=>{
        setFilters((prev)=>({
                ...prev,
                departureTimeRange: range
            }));
    };
    const handlePageChange = (page)=>{
        setCurrentPage(page);
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("main", {
        className: "min-h-screen bg-gray-50",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
                className: "bg-white shadow-sm ",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "max-w-7xl mx-auto px-4 py-6",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("form", {
                        onSubmit: handleSearchSubmit,
                        className: "bg-white border border-gray-200 rounded-2xl p-4 md:p-6 shadow-sm",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "grid grid-cols-1 md:grid-cols-4 gap-4 items-end",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                className: "block text-sm font-medium text-gray-700 mb-1",
                                                children: "De"
                                            }, void 0, false, {
                                                fileName: "[project]/app/rides/page.tsx",
                                                lineNumber: 563,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                type: "text",
                                                name: "from",
                                                value: searchParams.from,
                                                onChange: handleSearchChange,
                                                placeholder: "Ex: Sousse, Tunis...",
                                                className: "w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black focus:border-black"
                                            }, void 0, false, {
                                                fileName: "[project]/app/rides/page.tsx",
                                                lineNumber: 566,
                                                columnNumber: 17
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/app/rides/page.tsx",
                                        lineNumber: 562,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                className: "block text-sm font-medium text-gray-700 mb-1",
                                                children: "Vers"
                                            }, void 0, false, {
                                                fileName: "[project]/app/rides/page.tsx",
                                                lineNumber: 578,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                type: "text",
                                                name: "to",
                                                value: searchParams.to,
                                                onChange: handleSearchChange,
                                                placeholder: "Ex: Sfax, Monastir...",
                                                className: "w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black focus:border-black"
                                            }, void 0, false, {
                                                fileName: "[project]/app/rides/page.tsx",
                                                lineNumber: 581,
                                                columnNumber: 17
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/app/rides/page.tsx",
                                        lineNumber: 577,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                className: "block text-sm font-medium text-gray-700 mb-1",
                                                children: "Nombre de places"
                                            }, void 0, false, {
                                                fileName: "[project]/app/rides/page.tsx",
                                                lineNumber: 593,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                type: "number",
                                                min: 1,
                                                name: "seats",
                                                value: searchParams.seats,
                                                onChange: handleSearchChange,
                                                className: "w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black focus:border-black"
                                            }, void 0, false, {
                                                fileName: "[project]/app/rides/page.tsx",
                                                lineNumber: 596,
                                                columnNumber: 17
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/app/rides/page.tsx",
                                        lineNumber: 592,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                className: "block text-sm font-medium text-gray-700 mb-1",
                                                children: "Date"
                                            }, void 0, false, {
                                                fileName: "[project]/app/rides/page.tsx",
                                                lineNumber: 608,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                type: "date",
                                                name: "date",
                                                value: searchParams.date,
                                                onChange: handleSearchChange,
                                                className: "w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black focus:border-black"
                                            }, void 0, false, {
                                                fileName: "[project]/app/rides/page.tsx",
                                                lineNumber: 611,
                                                columnNumber: 17
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/app/rides/page.tsx",
                                        lineNumber: 607,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/rides/page.tsx",
                                lineNumber: 560,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                type: "submit",
                                className: "mt-4 w-full md:w-auto px-6 py-3 bg-black text-white rounded-lg font-semibold hover:bg-gray-900 transition",
                                children: "Rechercher des trajets"
                            }, void 0, false, {
                                fileName: "[project]/app/rides/page.tsx",
                                lineNumber: 621,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/rides/page.tsx",
                        lineNumber: 556,
                        columnNumber: 11
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/app/rides/page.tsx",
                    lineNumber: 555,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/app/rides/page.tsx",
                lineNumber: 553,
                columnNumber: 15
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$common$2f$PageHeader$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                title: "Trajets disponibles",
                searchInfo: searchParams,
                resultCount: filteredRides.length
            }, void 0, false, {
                fileName: "[project]/app/rides/page.tsx",
                lineNumber: 631,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "max-w-7xl mx-auto px-4 py-8",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex flex-col md:flex-row gap-8",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "w-full md:w-1/3 lg:w-1/4",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$rides$2f$RidesFilterSidebar$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                filters: filters,
                                onSortChange: handleSortChange,
                                onServiceFilter: handleServiceFilter,
                                onClearFilters: handleClearFilters,
                                onDepartureTimeRangeChange: handleDepartureTimeRangeChange,
                                availableServices: availableServices.length > 0 ? availableServices : undefined
                            }, void 0, false, {
                                fileName: "[project]/app/rides/page.tsx",
                                lineNumber: 641,
                                columnNumber: 7
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/app/rides/page.tsx",
                            lineNumber: 640,
                            columnNumber: 5
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "w-full md:flex-1",
                            children: [
                                loading ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "text-center py-8",
                                    children: "Chargement des trajets..."
                                }, void 0, false, {
                                    fileName: "[project]/app/rides/page.tsx",
                                    lineNumber: 656,
                                    columnNumber: 9
                                }, this) : paginatedRides.length > 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "space-y-4",
                                    children: paginatedRides.map((ride)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$rides$2f$RideCard$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                            ride: ride
                                        }, ride.id, false, {
                                            fileName: "[project]/app/rides/page.tsx",
                                            lineNumber: 660,
                                            columnNumber: 13
                                        }, this))
                                }, void 0, false, {
                                    fileName: "[project]/app/rides/page.tsx",
                                    lineNumber: 658,
                                    columnNumber: 9
                                }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$common$2f$EmptyState$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                                    fileName: "[project]/app/rides/page.tsx",
                                    lineNumber: 664,
                                    columnNumber: 9
                                }, this),
                                filteredRides.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "flex justify-center items-center gap-4 mt-8",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                            className: "px-4 py-2 border rounded disabled:opacity-50",
                                            onClick: ()=>handlePageChange(currentPage - 1),
                                            disabled: currentPage === 1 || loading,
                                            children: "Précédent"
                                        }, void 0, false, {
                                            fileName: "[project]/app/rides/page.tsx",
                                            lineNumber: 669,
                                            columnNumber: 11
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            children: [
                                                "Page ",
                                                currentPage,
                                                " of ",
                                                totalPages
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/app/rides/page.tsx",
                                            lineNumber: 676,
                                            columnNumber: 11
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                            className: "px-4 py-2 border rounded disabled:opacity-50",
                                            onClick: ()=>handlePageChange(currentPage + 1),
                                            disabled: currentPage === totalPages || loading,
                                            children: "Suivant"
                                        }, void 0, false, {
                                            fileName: "[project]/app/rides/page.tsx",
                                            lineNumber: 679,
                                            columnNumber: 11
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/app/rides/page.tsx",
                                    lineNumber: 668,
                                    columnNumber: 9
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/rides/page.tsx",
                            lineNumber: 654,
                            columnNumber: 5
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/rides/page.tsx",
                    lineNumber: 638,
                    columnNumber: 3
                }, this)
            }, void 0, false, {
                fileName: "[project]/app/rides/page.tsx",
                lineNumber: 637,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/rides/page.tsx",
        lineNumber: 550,
        columnNumber: 5
    }, this);
}
_s(RidesPage, "XFphwAd4cKmI2GGVjmp18scf2hs=");
_c = RidesPage;
var _c;
__turbopack_context__.k.register(_c, "RidesPage");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
}]);

//# sourceMappingURL=_fab6a941._.js.map