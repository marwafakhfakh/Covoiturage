(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/_63cb4981._.js",
  "static/chunks/node_modules_2c2f08ea._.js"
],
    source: "dynamic"
});
