(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_969a6c83._.js",
  "static/chunks/_16f1cb64._.js"
],
    source: "dynamic"
});
