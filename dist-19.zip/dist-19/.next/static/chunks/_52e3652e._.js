(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([typeof document === "object" ? document.currentScript : undefined, {

"[project]/components/offer/FormSection.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": ()=>FormSection
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
;
function FormSection(param) {
    let { title, children, className = "" } = param;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "space-y-6 ".concat(className),
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                className: "text-2xl font-semibold text-gray-900 border-b pb-2",
                children: title
            }, void 0, false, {
                fileName: "[project]/components/offer/FormSection.tsx",
                lineNumber: 16,
                columnNumber: 7
            }, this),
            children
        ]
    }, void 0, true, {
        fileName: "[project]/components/offer/FormSection.tsx",
        lineNumber: 15,
        columnNumber: 5
    }, this);
}
_c = FormSection;
var _c;
__turbopack_context__.k.register(_c, "FormSection");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/components/common/SuccessMessage.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": ()=>SuccessMessage
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
;
function SuccessMessage(param) {
    let { icon = "✅", title = "Success!", description = "Your action has been completed successfully.", actionText = "Continue", onAction, className = "" } = param;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "text-center py-12 ".concat(className),
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "w-20 h-20 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-6",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                    className: "text-3xl",
                    children: icon
                }, void 0, false, {
                    fileName: "[project]/components/common/SuccessMessage.tsx",
                    lineNumber: 21,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/components/common/SuccessMessage.tsx",
                lineNumber: 20,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                className: "text-2xl font-bold text-gray-900 mb-4",
                children: title
            }, void 0, false, {
                fileName: "[project]/components/common/SuccessMessage.tsx",
                lineNumber: 23,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "text-gray-600 mb-6",
                children: description
            }, void 0, false, {
                fileName: "[project]/components/common/SuccessMessage.tsx",
                lineNumber: 24,
                columnNumber: 7
            }, this),
            onAction && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                onClick: onAction,
                className: "px-6 py-3 bg-black text-white rounded-lg hover:bg-gray-800 transition font-semibold",
                children: actionText
            }, void 0, false, {
                fileName: "[project]/components/common/SuccessMessage.tsx",
                lineNumber: 26,
                columnNumber: 9
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/components/common/SuccessMessage.tsx",
        lineNumber: 19,
        columnNumber: 5
    }, this);
}
_c = SuccessMessage;
var _c;
__turbopack_context__.k.register(_c, "SuccessMessage");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/app/offer/page.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
// // // "use client";
// // // import { useState, useEffect } from "react";
// // // import { useSelector } from "react-redux";
// // // import FormSection from "../../components/offer/FormSection";
// // // import SuccessMessage from "../../components/common/SuccessMessage";
// // // import api from "../../api/api";
// // // import type { RootState } from "../../store";
// // // import dynamic from "next/dynamic";               // ✅ ajouté
// // // // import DelegationMap, { Delegation } from "./DelegationMap";
// // // // import DelegationMapLeaflet, { Delegation } from "./DelegationMapLeaflet";
// // // // import RouteMapLeaflet from "./RouteMapLeaflet";
// // // const RouteMapLeaflet = dynamic(() => import("./RouteMapLeaflet"), {
// // //   ssr: false,
// // // });
// // // import type { Delegation } from "./DelegationMapLeaflet";
// // // type Car = {
// // //   id: number;
// // //   model_details?: {
// // //     id: number;
// // //     name: string;
// // //     brand: {
// // //       id: number;
// // //       name: string;
// // //     };
// // //   } | null;
// // //   type: string;
// // //   color: string;
// // //     color_details?: { id: number; name: string; code: string } | null;
// // //   serial_number: string;
// // //   nb_place: number;
// // //   engine_type: string;
// // //   grey_card: string;
// // //   year: number | null;
// // //   image: string | null;
// // //   owner: number;
// // // };
// // // type Service = {
// // //   id: number;
// // //   name: string;
// // //   description: string;
// // //   active: boolean;
// // //   logo: string | null;
// // // };
// // // type OfferForm = {
// // //   departure_place: string;
// // //   arrival_place: string;
// // //   departure_date: string;
// // //   price: string;
// // //   nb_places_disponible: string;
// // //   selected_car_id: string;
// // //   services: number[];
// // //   description: string;
// // // };
// // // export default function OfferRidePage() {
// // //   const user = useSelector((state: RootState) => state.user.user);
// // //   const [form, setForm] = useState<OfferForm>({
// // //     departure_place: "",
// // //     arrival_place: "",
// // //     departure_date: "",
// // //     price: "",
// // //     nb_places_disponible: "",
// // //     selected_car_id: "",
// // //     services: [],
// // //     description: "",
// // //   });
// // //   const [success, setSuccess] = useState(false);
// // //   const [error, setError] = useState<string | null>(null);
// // //   const [ownedCars, setOwnedCars] = useState<Car[]>([]);
// // //   const [services, setServices] = useState<Service[]>([]);
// // //   const [delegations, setDelegations] = useState<Delegation[]>([]);
// // //   const [loading, setLoading] = useState(true);
// // //   // Pour l’instant on ne recalcule pas la distance avec lat/lng
// // //   // const distanceKm = 0;
// // //   // const estimatedPrice = 0;
// // //   useEffect(() => {
// // //     async function fetchData() {
// // //       setLoading(true);
// // //       try {
// // //         const [carsRes, servicesRes, delegationsRes] = await Promise.all([
// // //           api.get("/api/cars/"),
// // //           api.get("/api/services/"),
// // //           api.get("/api/delegations/"),
// // //         ]);
// // //         const cars = Array.isArray(carsRes.data)
// // //           ? carsRes.data
// // //           : carsRes.data.results || [];
// // //         const delegs = Array.isArray(delegationsRes.data)
// // //           ? delegationsRes.data
// // //           : delegationsRes.data.results || [];
// // //         setOwnedCars(cars);
// // //         setServices(servicesRes.data.results || servicesRes.data || []);
// // //         setDelegations(delegs);
// // //       } catch (error) {
// // //         console.error("Error fetching data for offer page:", error);
// // //         setError("Unable to load data. Please try again later.");
// // //       } finally {
// // //         setLoading(false);
// // //       }
// // //     }
// // //     if (user) {
// // //       fetchData();
// // //     }
// // //   }, [user]);
// // //   const handleChange = (
// // //     e: React.ChangeEvent<
// // //       HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement
// // //     >
// // //   ) => {
// // //     setForm((prev) => ({ ...prev, [e.target.name]: e.target.value }));
// // //   };
// // //   const handleServiceChange = (serviceId: number) => {
// // //     setForm((prev) => ({
// // //       ...prev,
// // //       services: prev.services.includes(serviceId)
// // //         ? prev.services.filter((s) => s !== serviceId)
// // //         : [...prev.services, serviceId],
// // //     }));
// // //   };
// // //   const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
// // //     e.preventDefault();
// // //     setError(null);
// // //     const selectedCar = ownedCars.find(
// // //       (car) => car.id === parseInt(form.selected_car_id)
// // //     );
// // //     try {
// // //       await api.post("/api/posts/", {
// // //         ...form,
// // //         user: user?.id,
// // //         car: selectedCar?.id,
// // //         status: "open",
// // //         services: form.services,
// // //       });
// // //       setSuccess(true);
// // //     } catch (err) {
// // //       console.error('❌ Error publishing ride:', err);
// // //       if (err && typeof err === 'object' && 'response' in err) {
// // //         const error = err as { response?: { data?: { detail?: string; [key: string]: unknown } } };
// // //         const detail = error.response?.data?.detail;
// // //         const allErrors = error.response?.data 
// // //           ? Object.values(error.response.data).flat().join(" ")
// // //           : "";
// // //         setError(detail || allErrors || "An error occurred while publishing your ride.");
// // //       } else {
// // //         setError("An error occurred while publishing your ride.");
// // //       }}
// // //   };
// // //   const selectedCar = ownedCars.find(
// // //     (car) => car.id === parseInt(form.selected_car_id)
// // //   );
// // //    //const [departureQuery] = useState('');
// // //   // const filteredDepartureDelegations = delegations.filter((d) => d.name.toLowerCase().includes(departureQuery.toLowerCase())
// // //   // );
// // //   return (
// // //     <main className="min-h-screen bg-gray-50 py-8">
// // //       <div className="max-w-4xl mx-auto px-4">
// // //         <div className="bg-white rounded-2xl shadow-xl p-8">
// // //           <h1 className="text-4xl font-bold mb-8 text-center text-gray-900">
// // //             Partger votre trajet
// // //           </h1>
// // //           {error && (
// // //             <div className="mb-4 p-4 bg-red-100 text-red-700 rounded-lg border border-red-200">
// // //               {error}
// // //             </div>
// // //           )}
// // //           {success ? (
// // //             <SuccessMessage
// // //               title="Ride Offered Successfully!"
// // //               description="Your ride has been posted and is now available for bookings."
// // //               actionText="Offer Another Ride"
// // //               onAction={() => setSuccess(false)}
// // //             />
// // //           ) : loading ? (
// // //             <div className="text-center text-gray-500 py-12">Loading...</div>
// // //           ) : (
// // //             <form onSubmit={handleSubmit} className="space-y-8">
// // //               {/* Route Section */}
// // //               <FormSection title="Route Information">
// // //                   {/* Bloc carte Leaflet au-dessus des selects */}
// // //                   <RouteMapLeaflet
// // //                     delegations={delegations}
// // //                     departureName={form.departure_place}
// // //                     arrivalName={form.arrival_place}
// // //                   />
// // //                   {/* Tes selects restent comme avant dessous */}
// // //                   <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-4">
// // //                       {/* <div className="space-y-2">
// // //                         <label className="block text-sm font-semibold text-gray-700">
// // //                           Departure Location
// // //                         </label>
// // //                         <input
// // //                           type="text"
// // //                           value={departureQuery}
// // //                           onChange={(e) => setDepartureQuery(e.target.value)}
// // //                           placeholder="Rechercher une délégation..."
// // //                           className="w-full mb-2 p-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-gray-500 focus:border-transparent"
// // //                         />
// // //                         <select
// // //                           name="departure_place"
// // //                           value={form.departure_place}
// // //                           onChange={handleChange}
// // //                           className="w-full p-4 border border-gray-300 rounded-xl focus:ring-2 focus:ring-gray-500 focus:border-transparent bg-white"
// // //                           required
// // //                         >
// // //                           <option value="">Select departure</option>
// // //                           {filteredDepartureDelegations.map((d) => (
// // //                             <option key={d.id} value={d.name}>
// // //                               {d.name}
// // //                             </option>
// // //                           ))}
// // //                         </select>
// // //                       </div> */}
// // //                     <div className="space-y-2">
// // //                       <label className="block text-sm font-semibold text-gray-700">
// // //                         Departure Location
// // //                       </label>
// // //                       <select
// // //                         name="departure_place"
// // //                         value={form.departure_place}
// // //                         className="w-full p-4 border border-gray-300 rounded-xl focus:ring-2 focus:ring-gray-500 focus:border-transparent transition bg-white"
// // //                         onChange={handleChange}
// // //                         required
// // //                       >
// // //                         <option value="">Select departure</option>
// // //                         {delegations.map((d) => (
// // //                           <option key={d.id} value={d.name}>
// // //                             {d.name}
// // //                           </option>
// // //                         ))}
// // //                       </select>
// // //                     </div>
// // //                     <div className="space-y-2">
// // //                       <label className="block text-sm font-semibold text-gray-700">
// // //                         Arrival Location
// // //                       </label>
// // //                       <select
// // //                         name="arrival_place"
// // //                         value={form.arrival_place}
// // //                         className="w-full p-4 border border-gray-300 rounded-xl focus:ring-2 focus:ring-gray-500 focus:border-transparent transition bg-white"
// // //                         onChange={handleChange}
// // //                         required
// // //                       >
// // //                         <option value="">Select arrival</option>
// // //                         {delegations.map((d) => (
// // //                           <option key={d.id} value={d.name}>
// // //                             {d.name}
// // //                           </option>
// // //                         ))}
// // //                       </select>
// // //                     </div>
// // //                   </div>
// // //                 </FormSection>
// // //               {/* Trip Details Section */}
// // //               <FormSection title="Planning et Disponibilité">
// // //                 <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
// // //                   <div className="space-y-2">
// // //                     <label className="block text-sm font-semibold text-gray-700">
// // //                       Date & Time
// // //                     </label>
// // //                     <input
// // //                       name="departure_date"
// // //                       type="datetime-local"
// // //                       value={form.departure_date}
// // //                       className="w-full p-4 border border-gray-300 rounded-xl focus:ring-2 focus:ring-gray-500 focus:border-transparent transition bg-white"
// // //                       onChange={handleChange}
// // //                       required
// // //                     />
// // //                   </div>
// // //                   <div className="space-y-2">
// // //                     <label className="block text-sm font-semibold text-gray-700">
// // //                       Prix du siège (TND)
// // //                     </label>
// // //                     <input
// // //                       name="price"
// // //                       placeholder="25"
// // //                       type="number"
// // //                       min="1"
// // //                       value={form.price}
// // //                       className="w-full p-4 border border-gray-300 rounded-xl focus:ring-2 focus:ring-gray-500 focus:border-transparent transition bg-white"
// // //                       onChange={handleChange}
// // //                       required
// // //                     />
// // //                   </div>
// // //                   <div className="space-y-2">
// // //                     <label className="block text-sm font-semibold text-gray-700">
// // //                       Siège disponibles
// // //                     </label>
// // //                     <select
// // //                       name="nb_places_disponible"
// // //                       value={form.nb_places_disponible}
// // //                       className="w-full p-4 border border-gray-300 rounded-xl focus:ring-2 focus:ring-gray-500 focus:border-transparent transition bg-white"
// // //                       onChange={handleChange}
// // //                       required
// // //                     >
// // //                       <option value="">Choisir les sièges</option>
// // //                       {selectedCar &&
// // //                         Array.from(
// // //                           { length: selectedCar.nb_place - 1 },
// // //                           (_, i) => i + 1
// // //                         ).map((num) => (
// // //                           <option key={num} value={num.toString()}>
// // //                             {num} seat{num > 1 ? "s" : ""}
// // //                           </option>
// // //                         ))}
// // //                       {!selectedCar && (
// // //                         <>
// // //                           <option value="1">1 Place</option>
// // //                           <option value="2">2 Places</option>
// // //                           <option value="3">3 Places</option>
// // //                           <option value="4">4 Places</option>
// // //                         </>
// // //                       )}
// // //                     </select>
// // //                   </div>
// // //                 </div>
// // //               </FormSection>
// // //               {/* Car Selection Section */}
// // //               <FormSection title="Vehicle Information">
// // //                 <div className="space-y-4">
// // //                   <div className="space-y-2">
// // //                     <label className="block text-sm font-semibold text-gray-700">
// // //                       Choisir votre voiture
// // //                     </label>
// // //                    <select
// // //   name="selected_car_id"
// // //   value={form.selected_car_id}
// // //   className="w-full p-4 border border-gray-300 rounded-xl focus:ring-2 focus:ring-gray-500 focus:border-transparent transition bg-white"
// // //   onChange={handleChange}
// // //   required
// // // >
// // //   <option value="">
// // //     Choisir une voiture depuis votre collection
// // //   </option>
// // //   {ownedCars.map((car) => (
// // //     <option key={car.id} value={car.id.toString()}>
// // //       {car.model_details?.brand.name || "Voiture"} {car.model_details?.name} ({car.year || "-"}){" - "}
// // //       {car.color_details?.name} - {car.serial_number}
// // //     </option>
// // //   ))}
// // // </select>
// // //                   </div>
// // //                   {ownedCars.length === 0 && (
// // //                     <div className="bg-gray-50 rounded-xl p-6 border border-gray-200 text-center">
// // //                       <div className="text-gray-400 text-4xl mb-3">🚗</div>
// // //                       <h3 className="font-semibold text-gray-900 mb-2">
// // //                         Aucune voiture disponible
// // //                       </h3>
// // //                       <p className="text-gray-600 mb-4">
// // //                         Vous devez ajouter un véhicule à votre compte avant de proposer des trajets.
// // //                       </p>
// // //                       <button
// // //                         type="button"
// // //                         className="px-4 py-2 bg-black text-white rounded-lg hover:bg-gray-800 transition font-medium"
// // //                         onClick={() => (window.location.href = "/profile")}
// // //                       >
// // //                         Ajouter un véhicule
// // //                       </button>
// // //                     </div>
// // //                   )}
// // //                 </div>
// // //               </FormSection>
// // //               {/* Services Section */}
// // //               <FormSection title="Services & accessoires">
// // //                 <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
// // //                   {services.map((service) => (
// // //                     <label
// // //                       key={service.id}
// // //                       className="flex items-center space-x-3 cursor-pointer"
// // //                     >
// // //                       <input
// // //                         type="checkbox"
// // //                         checked={form.services.includes(service.id)}
// // //                         onChange={() => handleServiceChange(service.id)}
// // //                         className="w-5 h-5 text-gray-600 border-gray-300 rounded focus:ring-gray-500"
// // //                       />
// // //                       <span className="text-sm font-medium text-gray-700">
// // //                         {service.name}
// // //                       </span>
// // //                     </label>
// // //                   ))}
// // //                 </div>
// // //               </FormSection>
// // //               {/* Description Section */}
// // //               <FormSection title="Information supplémentaire">
// // //                 <div className="space-y-2">
// // //                   <label className="block text-sm font-semibold text-gray-700">
// // //                     Description (Optional)
// // //                   </label>
// // //                   <textarea
// // //                     name="description"
// // //                     value={form.description}
// // //                     placeholder="Mettre des informations additionnelles pour votre trajets, préférences et détails."
// // //                     rows={4}
// // //                     className="w-full p-4 border border-gray-300 rounded-xl focus:ring-2 focus:ring-gray-500 focus:border-transparent transition bg-white resize-none"
// // //                     onChange={handleChange}
// // //                   />
// // //                 </div>
// // //               </FormSection>
// // //               <button
// // //                 type="submit"
// // //                 className="w-full py-4 bg-black text-white rounded-xl font-semibold text-lg hover:bg-gray-800 transition transform hover:scale-105 shadow-lg"
// // //                 disabled={ownedCars.length === 0}
// // //               >
// // //                 Publier votre trajet
// // //                             </button>
// // //             </form>
// // //           )}
// // //         </div>
// // //       </div>
// // //     </main>
// // //   );
// // // }
// // "use client";
// // import { useState, useEffect } from "react";
// // import { useSelector } from "react-redux";
// // import FormSection from "../../components/offer/FormSection";
// // import SuccessMessage from "../../components/common/SuccessMessage";
// // import api from "../../api/api";
// // import type { RootState } from "../../store";
// // import dynamic from "next/dynamic";
// // const RouteMapLeaflet = dynamic(() => import("./RouteMapLeaflet"), {
// //   ssr: false,
// // });
// // import type { Delegation } from "./DelegationMapLeaflet";
// // type Car = {
// //   id: number;
// //   model_details?: {
// //     id: number;
// //     name: string;
// //     brand: {
// //       id: number;
// //       name: string;
// //     };
// //   } | null;
// //   type: string;
// //   color: string;
// //   color_details?: { id: number; name: string; code: string } | null;
// //   serial_number: string;
// //   nb_place: number;
// //   engine_type: string;
// //   grey_card: string;
// //   year: number | null;
// //   image: string | null;
// //   owner: number;
// // };
// // type Service = {
// //   id: number;
// //   name: string;
// //   description: string;
// //   active: boolean;
// //   logo: string | null;
// // };
// // type OfferForm = {
// //   departure_place: string;
// //   arrival_place: string;
// //   departure_date: string;
// //   price: string;
// //   nb_places_disponible: string;
// //   selected_car_id: string;
// //   services: number[];
// //   description: string;
// // };
// // export default function OfferRidePage() {
// //   const user = useSelector((state: RootState) => state.user.user);
// //   const getDefaultDateTime = () => {
// //     const now = new Date();
// //     now.setHours(now.getHours() + 2); // Ajouter 1 heures au temps actuel
// //     // Format: YYYY-MM-DDTHH:MM
// //     return now.toISOString().slice(0, 16);
// //   };
// //   const [form, setForm] = useState<OfferForm>({
// //     departure_place: "",
// //     arrival_place: "",
// //     departure_date: getDefaultDateTime(),
// //     price: "",
// //     nb_places_disponible: "",
// //     selected_car_id: "",
// //     services: [],
// //     description: "",
// //   });
// //   const [success, setSuccess] = useState(false);
// //   const [error, setError] = useState<string | null>(null);
// //   const [ownedCars, setOwnedCars] = useState<Car[]>([]);
// //   const [services, setServices] = useState<Service[]>([]);
// //   const [delegations, setDelegations] = useState<Delegation[]>([]);
// //   const [loading, setLoading] = useState(true);
// //   // État pour savoir si le prix a été modifié manuellement
// //   const [priceManuallyEdited, setPriceManuallyEdited] = useState(false);
// //   useEffect(() => {
// //     async function fetchData() {
// //       setLoading(true);
// //       try {
// //         const [carsRes, servicesRes, delegationsRes] = await Promise.all([
// //           api.get("/api/cars/"),
// //           api.get("/api/services/"),
// //           api.get("/api/delegations/"),
// //         ]);
// //         const cars = Array.isArray(carsRes.data)
// //           ? carsRes.data
// //           : carsRes.data.results || [];
// //         const delegs = Array.isArray(delegationsRes.data)
// //           ? delegationsRes.data
// //           : delegationsRes.data.results || [];
// //         setOwnedCars(cars);
// //         setServices(servicesRes.data.results || servicesRes.data || []);
// //         setDelegations(delegs);
// //       } catch (error) {
// //         console.error("Error fetching data for offer page:", error);
// //         setError("Unable to load data. Please try again later.");
// //       } finally {
// //         setLoading(false);
// //       }
// //     }
// //     if (user) {
// //       fetchData();
// //     }
// //   }, [user]);
// //   const handleChange = (
// //     e: React.ChangeEvent<
// //       HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement
// //     >
// //   ) => {
// //     const { name, value } = e.target;
// //     // Si l'utilisateur modifie le prix manuellement
// //     if (name === "price") {
// //       setPriceManuallyEdited(true);
// //     }
// //     setForm((prev) => ({ ...prev, [name]: value }));
// //   };
// //   const handleServiceChange = (serviceId: number) => {
// //     setForm((prev) => ({
// //       ...prev,
// //       services: prev.services.includes(serviceId)
// //         ? prev.services.filter((s) => s !== serviceId)
// //         : [...prev.services, serviceId],
// //     }));
// //   };
// // const [lastSuggestedPrice, setLastSuggestedPrice] = useState<string | null>(null);
// // const handleDistanceCalculated = (distance: number, suggestedPrice: number) => {
// //   // ne rien faire si l'utilisateur a modifié le prix
// //   if (priceManuallyEdited) return;
// //   const newPrice = suggestedPrice.toFixed(1); // ou toString()
// //   // si le prix suggéré n'a pas changé, ne pas appeler setForm
// //   if (lastSuggestedPrice === newPrice) return;
// //   setLastSuggestedPrice(newPrice);
// //   setForm(prev => ({ ...prev, price: newPrice }));
// // };
// //   // Réinitialiser le flag quand l'utilisateur change de départ ou d'arrivée
// //   useEffect(() => {
// //     setPriceManuallyEdited(false);
// //   }, [form.departure_place, form.arrival_place]);
// //   const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
// //     e.preventDefault();
// //     setError(null);
// //     const selectedCar = ownedCars.find(
// //       (car) => car.id === parseInt(form.selected_car_id)
// //     );
// //     try {
// //       await api.post("/api/posts/", {
// //         ...form,
// //         user: user?.id,
// //         car: selectedCar?.id,
// //         status: "open",
// //         services: form.services,
// //       });
// //       setSuccess(true);
// //     } catch (err) {
// //       console.error('❌ Error publishing ride:', err);
// //       if (err && typeof err === 'object' && 'response' in err) {
// //         const error = err as { response?: { data?: { detail?: string; [key: string]: unknown } } };
// //         const detail = error.response?.data?.detail;
// //         const allErrors = error.response?.data 
// //           ? Object.values(error.response.data).flat().join(" ")
// //           : "";
// //         setError(detail || allErrors || "An error occurred while publishing your ride.");
// //       } else {
// //         setError("An error occurred while publishing your ride.");
// //       }
// //     }
// //   };
// //   const selectedCar = ownedCars.find(
// //     (car) => car.id === parseInt(form.selected_car_id)
// //   );
// //   return (
// //     <main className="min-h-screen bg-gray-50 py-8">
// //       <div className="max-w-4xl mx-auto px-4">
// //         <div className="bg-white rounded-2xl shadow-xl p-8">
// //           <h1 className="text-4xl font-bold mb-8 text-center text-gray-900">
// //             Partager votre trajet
// //           </h1>
// //           {error && (
// //             <div className="mb-4 p-4 bg-red-100 text-red-700 rounded-lg border border-red-200">
// //               {error}
// //             </div>
// //           )}
// //           {success ? (
// //             <SuccessMessage
// //               title="Ride Offered Successfully!"
// //               description="Your ride has been posted and is now available for bookings."
// //               actionText="Offer Another Ride"
// //               onAction={() => setSuccess(false)}
// //             />
// //           ) : loading ? (
// //             <div className="text-center text-gray-500 py-12">Loading...</div>
// //           ) : (
// //             <form onSubmit={handleSubmit} className="space-y-8">
// //               {/* Route Section */}
// //               <FormSection title="Route Information">
// //                 <RouteMapLeaflet
// //                   delegations={delegations}
// //                   departureName={form.departure_place}
// //                   arrivalName={form.arrival_place}
// //                   onDistanceCalculated={handleDistanceCalculated}
// //                 />
// //                 <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-4">
// //                   <div className="space-y-2">
// //                     <label className="block text-sm font-semibold text-gray-700">
// //                       Departure Location
// //                     </label>
// //                     <select
// //                       name="departure_place"
// //                       value={form.departure_place}
// //                       className="w-full p-4 border border-gray-300 rounded-xl focus:ring-2 focus:ring-gray-500 focus:border-transparent transition bg-white"
// //                       onChange={handleChange}
// //                       required
// //                     >
// //                       <option value="">Select departure</option>
// //                       {delegations.map((d) => (
// //                         <option key={d.id} value={d.name}>
// //                           {d.name}
// //                         </option>
// //                       ))}
// //                     </select>
// //                   </div>
// //                   <div className="space-y-2">
// //                     <label className="block text-sm font-semibold text-gray-700">
// //                       Arrival Location
// //                     </label>
// //                     <select
// //                       name="arrival_place"
// //                       value={form.arrival_place}
// //                       className="w-full p-4 border border-gray-300 rounded-xl focus:ring-2 focus:ring-gray-500 focus:border-transparent transition bg-white"
// //                       onChange={handleChange}
// //                       required
// //                     >
// //                       <option value="">Select arrival</option>
// //                       {delegations.map((d) => (
// //                         <option key={d.id} value={d.name}>
// //                           {d.name}
// //                         </option>
// //                       ))}
// //                     </select>
// //                   </div>
// //                 </div>
// //               </FormSection>
// //               {/* Trip Details Section */}
// //               <FormSection title="Planning et Disponibilité">
// //                 <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
// //                   <div className="space-y-2">
// //                     <label className="block text-sm font-semibold text-gray-700">
// //                       Date & Time
// //                     </label>
// //                     <input
// //                       name="departure_date"
// //                       type="datetime-local"
// //                       value={form.departure_date}
// //                       className="w-full p-4 border border-gray-300 rounded-xl focus:ring-2 focus:ring-gray-500 focus:border-transparent transition bg-white"
// //                       onChange={handleChange}
// //                       required
// //                     />
// //                   </div>
// //                   <div className="space-y-2">
// //                     <label className="block text-sm font-semibold text-gray-700">
// //                       Prix du siège (TND)
// //                       {!priceManuallyEdited && form.price && (
// //                         <span className="ml-2 text-xs text-blue-600">✨ Auto-calculé</span>
// //                       )}
// //                     </label>
// //                     <input
// //                       name="price"
// //                       placeholder="Prix calculé automatiquement"
// //                       type="number"
// //                       min="1"
// //                       step="0.5"
// //                       value={form.price}
// //                       className="w-full p-4 border border-gray-300 rounded-xl focus:ring-2 focus:ring-gray-500 focus:border-transparent transition bg-white"
// //                       onChange={handleChange}
// //                       required
// //                     />
// //                     {priceManuallyEdited && (
// //                       <p className="text-xs text-gray-500 mt-1">
// //                         Prix modifié manuellement
// //                       </p>
// //                     )}
// //                   </div>
// //                   <div className="space-y-2">
// //                     <label className="block text-sm font-semibold text-gray-700">
// //                       Sièges disponibles
// //                     </label>
// //                     <select
// //                       name="nb_places_disponible"
// //                       value={form.nb_places_disponible}
// //                       className="w-full p-4 border border-gray-300 rounded-xl focus:ring-2 focus:ring-gray-500 focus:border-transparent transition bg-white"
// //                       onChange={handleChange}
// //                       required
// //                     >
// //                       <option value="">Choisir les sièges</option>
// //                       {selectedCar &&
// //                         Array.from(
// //                           { length: selectedCar.nb_place - 1 },
// //                           (_, i) => i + 1
// //                         ).map((num) => (
// //                           <option key={num} value={num.toString()}>
// //                             {num} seat{num > 1 ? "s" : ""}
// //                           </option>
// //                         ))}
// //                       {!selectedCar && (
// //                         <>
// //                           <option value="1">1 Place</option>
// //                           <option value="2">2 Places</option>
// //                           <option value="3">3 Places</option>
// //                           <option value="4">4 Places</option>
// //                         </>
// //                       )}
// //                     </select>
// //                   </div>
// //                 </div>
// //               </FormSection>
// //               {/* Car Selection Section */}
// //               <FormSection title="Vehicle Information">
// //                 <div className="space-y-4">
// //                   <div className="space-y-2">
// //                     <label className="block text-sm font-semibold text-gray-700">
// //                       Choisir votre voiture
// //                     </label>
// //                     <select
// //                       name="selected_car_id"
// //                       value={form.selected_car_id}
// //                       className="w-full p-4 border border-gray-300 rounded-xl focus:ring-2 focus:ring-gray-500 focus:border-transparent transition bg-white"
// //                       onChange={handleChange}
// //                       required
// //                     >
// //                       <option value="">
// //                         Choisir une voiture depuis votre collection
// //                       </option>
// //                       {ownedCars.map((car) => (
// //                         <option key={car.id} value={car.id.toString()}>
// //                           {car.model_details?.brand.name || "Voiture"} {car.model_details?.name} ({car.year || "-"}){" - "}
// //                           {car.color_details?.name} - {car.serial_number}
// //                         </option>
// //                       ))}
// //                     </select>
// //                   </div>
// //                   {ownedCars.length === 0 && (
// //                     <div className="bg-gray-50 rounded-xl p-6 border border-gray-200 text-center">
// //                       <div className="text-gray-400 text-4xl mb-3">🚗</div>
// //                       <h3 className="font-semibold text-gray-900 mb-2">
// //                         Aucune voiture disponible
// //                       </h3>
// //                       <p className="text-gray-600 mb-4">
// //                         Vous devez ajouter un véhicule à votre compte avant de proposer des trajets.
// //                       </p>
// //                       <button
// //                         type="button"
// //                         className="px-4 py-2 bg-black text-white rounded-lg hover:bg-gray-800 transition font-medium"
// //                         onClick={() => (window.location.href = "/profile")}
// //                       >
// //                         Ajouter un véhicule
// //                       </button>
// //                     </div>
// //                   )}
// //                 </div>
// //               </FormSection>
// //               {/* Services Section */}
// //               <FormSection title="Services & accessoires">
// //                 <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
// //                   {services.map((service) => (
// //                     <label
// //                       key={service.id}
// //                       className="flex items-center space-x-3 cursor-pointer"
// //                     >
// //                       <input
// //                         type="checkbox"
// //                         checked={form.services.includes(service.id)}
// //                         onChange={() => handleServiceChange(service.id)}
// //                         className="w-5 h-5 text-gray-600 border-gray-300 rounded focus:ring-gray-500"
// //                       />
// //                       <span className="text-sm font-medium text-gray-700">
// //                         {service.name}
// //                       </span>
// //                     </label>
// //                   ))}
// //                 </div>
// //               </FormSection>
// //               {/* Description Section */}
// //               <FormSection title="Information supplémentaire">
// //                 <div className="space-y-2">
// //                   <label className="block text-sm font-semibold text-gray-700">
// //                     Description (Optional)
// //                   </label>
// //                   <textarea
// //                     name="description"
// //                     value={form.description}
// //                     placeholder="Mettre des informations additionnelles pour votre trajets, préférences et détails."
// //                     rows={4}
// //                     className="w-full p-4 border border-gray-300 rounded-xl focus:ring-2 focus:ring-gray-500 focus:border-transparent transition bg-white resize-none"
// //                     onChange={handleChange}
// //                   />
// //                 </div>
// //               </FormSection>
// //               <button
// //                 type="submit"
// //                 className="w-full py-4 bg-black text-white rounded-xl font-semibold text-lg hover:bg-gray-800 transition transform hover:scale-105 shadow-lg"
// //                 disabled={ownedCars.length === 0}
// //               >
// //                 Publier votre trajet
// //               </button>
// //             </form>
// //           )}
// //         </div>
// //       </div>
// //     </main>
// //   );
// // }
// "use client";
// import { useState, useEffect } from "react";
// import { useSelector } from "react-redux";
// import FormSection from "../../components/offer/FormSection";
// import SuccessMessage from "../../components/common/SuccessMessage";
// import api from "../../api/api";
// import type { RootState } from "../../store";
// import dynamic from "next/dynamic";
// const RouteMapLeaflet = dynamic(() => import("./RouteMapLeaflet"), {
//   ssr: false,
// });
// import type { Delegation } from "./DelegationMapLeaflet";
// type Car = {
//   id: number;
//   model_details?: {
//     id: number;
//     name: string;
//     brand: {
//       id: number;
//       name: string;
//     };
//   } | null;
//   type: string;
//   color: string;
//   color_details?: { id: number; name: string; code: string } | null;
//   serial_number: string;
//   nb_place: number;
//   engine_type: string;
//   grey_card: string;
//   year: number | null;
//   image: string | null;
//   owner: number;
// };
// type Service = {
//   id: number;
//   name: string;
//   description: string;
//   active: boolean;
//   logo: string | null;
// };
// type OfferForm = {
//   departure_place: string;
//   arrival_place: string;
//   departure_date: string;
//   price: string;
//   nb_places_disponible: string;
//   selected_car_id: string;
//   services: number[];
//   description: string;
// };
// export default function OfferRidePage() {
//   const user = useSelector((state: RootState) => state.user.user);
//   const getDefaultDateTime = () => {
//     const now = new Date();
//     now.setHours(now.getHours() + 2);
//     return now.toISOString().slice(0, 16);
//   };
//   const [form, setForm] = useState<OfferForm>({
//     departure_place: "",
//     arrival_place: "",
//     departure_date: getDefaultDateTime(),
//     price: "",
//     nb_places_disponible: "",
//     selected_car_id: "",
//     services: [],
//     description: "",
//   });
//   const [success, setSuccess] = useState(false);
//   const [error, setError] = useState<string | null>(null);
//   const [ownedCars, setOwnedCars] = useState<Car[]>([]);
//   const [services, setServices] = useState<Service[]>([]);
//   const [delegations, setDelegations] = useState<Delegation[]>([]);
//   const [loading, setLoading] = useState(true);
//   const [priceManuallyEdited, setPriceManuallyEdited] = useState(false);
//   useEffect(() => {
//     async function fetchData() {
//       setLoading(true);
//       try {
//         const [carsRes, servicesRes, delegationsRes] = await Promise.all([
//           api.get("/api/cars/"),
//           api.get("/api/services/"),
//           api.get("/api/delegations/"),
//         ]);
//         const cars = Array.isArray(carsRes.data)
//           ? carsRes.data
//           : carsRes.data.results || [];
//         const delegs = Array.isArray(delegationsRes.data)
//           ? delegationsRes.data
//           : delegationsRes.data.results || [];
//         setOwnedCars(cars);
//         setServices(servicesRes.data.results || servicesRes.data || []);
//         setDelegations(delegs);
//       } catch (error) {
//         console.error("Error fetching data for offer page:", error);
//         setError("Unable to load data. Please try again later.");
//       } finally {
//         setLoading(false);
//       }
//     }
//     if (user) {
//       fetchData();
//     }
//   }, [user]);
//   const handleChange = (
//     e: React.ChangeEvent<
//       HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement
//     >
//   ) => {
//     const { name, value } = e.target;
//     if (name === "price") {
//       setPriceManuallyEdited(true);
//     }
//     setForm((prev) => ({ ...prev, [name]: value }));
//   };
//   const handleServiceChange = (serviceId: number) => {
//     setForm((prev) => ({
//       ...prev,
//       services: prev.services.includes(serviceId)
//         ? prev.services.filter((s) => s !== serviceId)
//         : [...prev.services, serviceId],
//     }));
//   };
//   const [lastSuggestedPrice, setLastSuggestedPrice] = useState<string | null>(null);
//   const handleDistanceCalculated = (distance: number, suggestedPrice: number) => {
//     if (priceManuallyEdited) return;
//     const newPrice = suggestedPrice.toFixed(1);
//     if (lastSuggestedPrice === newPrice) return;
//     setLastSuggestedPrice(newPrice);
//     setForm(prev => ({ ...prev, price: newPrice }));
//   };
//   useEffect(() => {
//     setPriceManuallyEdited(false);
//   }, [form.departure_place, form.arrival_place]);
//   const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
//     e.preventDefault();
//     setError(null);
//     const selectedCar = ownedCars.find(
//       (car) => car.id === parseInt(form.selected_car_id)
//     );
//     try {
//       // ✅ CORRECTION : Envoyer services_ids au lieu de services
//       const postData = {
//         departure_place: form.departure_place,
//         arrival_place: form.arrival_place,
//         departure_date: form.departure_date,
//         price: form.price,
//         nb_places_disponible: form.nb_places_disponible,
//         description: form.description,
//         user: user?.id,
//         car: selectedCar?.id,
//         status: "open",
//         services_ids: form.services, // ✅ Utiliser services_ids comme défini dans le serializer
//       };
//       console.log('📤 Données envoyées:', postData); // Pour debug
//       await api.post("/api/posts/", postData);
//       setSuccess(true);
//       // Réinitialiser le formulaire après succès
//       setForm({
//         departure_place: "",
//         arrival_place: "",
//         departure_date: getDefaultDateTime(),
//         price: "",
//         nb_places_disponible: "",
//         selected_car_id: "",
//         services: [],
//         description: "",
//       });
//     } catch (err) {
//       console.error('❌ Error publishing ride:', err);
//       if (err && typeof err === 'object' && 'response' in err) {
//         const error = err as { response?: { data?: { detail?: string; [key: string]: unknown } } };
//         const detail = error.response?.data?.detail;
//         const allErrors = error.response?.data 
//           ? Object.values(error.response.data).flat().join(" ")
//           : "";
//         setError(detail || allErrors || "An error occurred while publishing your ride.");
//       } else {
//         setError("An error occurred while publishing your ride.");
//       }
//     }
//   };
//   const selectedCar = ownedCars.find(
//     (car) => car.id === parseInt(form.selected_car_id)
//   );
//   return (
//     <main className="min-h-screen bg-gray-50 py-8">
//       <div className="max-w-4xl mx-auto px-4">
//         <div className="bg-white rounded-2xl shadow-xl p-8">
//           <h1 className="text-4xl font-bold mb-8 text-center text-gray-900">
//             Partager votre trajet
//           </h1>
//           {error && (
//             <div className="mb-4 p-4 bg-red-100 text-red-700 rounded-lg border border-red-200">
//               {error}
//             </div>
//           )}
//           {success ? (
//             <SuccessMessage
//               title="Ride Offered Successfully!"
//               description="Your ride has been posted and is now available for bookings."
//               actionText="Offer Another Ride"
//               onAction={() => setSuccess(false)}
//             />
//           ) : loading ? (
//             <div className="text-center text-gray-500 py-12">Loading...</div>
//           ) : (
//             <form onSubmit={handleSubmit} className="space-y-8">
//               {/* Route Section */}
//               <FormSection title="Route Information">
//                 <RouteMapLeaflet
//                   delegations={delegations}
//                   departureName={form.departure_place}
//                   arrivalName={form.arrival_place}
//                   onDistanceCalculated={handleDistanceCalculated}
//                 />
//                 <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-4">
//                   <div className="space-y-2">
//                     <label className="block text-sm font-semibold text-gray-700">
//                       Departure Location
//                     </label>
//                     <select
//                       name="departure_place"
//                       value={form.departure_place}
//                       className="w-full p-4 border border-gray-300 rounded-xl focus:ring-2 focus:ring-gray-500 focus:border-transparent transition bg-white"
//                       onChange={handleChange}
//                       required
//                     >
//                       <option value="">Select departure</option>
//                       {delegations.map((d) => (
//                         <option key={d.id} value={d.name}>
//                           {d.name}
//                         </option>
//                       ))}
//                     </select>
//                   </div>
//                   <div className="space-y-2">
//                     <label className="block text-sm font-semibold text-gray-700">
//                       Arrival Location
//                     </label>
//                     <select
//                       name="arrival_place"
//                       value={form.arrival_place}
//                       className="w-full p-4 border border-gray-300 rounded-xl focus:ring-2 focus:ring-gray-500 focus:border-transparent transition bg-white"
//                       onChange={handleChange}
//                       required
//                     >
//                       <option value="">Select arrival</option>
//                       {delegations.map((d) => (
//                         <option key={d.id} value={d.name}>
//                           {d.name}
//                         </option>
//                       ))}
//                     </select>
//                   </div>
//                 </div>
//               </FormSection>
//               {/* Trip Details Section */}
//               <FormSection title="Planning et Disponibilité">
//                 <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
//                   <div className="space-y-2">
//                     <label className="block text-sm font-semibold text-gray-700">
//                       Date & Time
//                     </label>
//                     <input
//                       name="departure_date"
//                       type="datetime-local"
//                       value={form.departure_date}
//                       className="w-full p-4 border border-gray-300 rounded-xl focus:ring-2 focus:ring-gray-500 focus:border-transparent transition bg-white"
//                       onChange={handleChange}
//                       required
//                     />
//                   </div>
//                   <div className="space-y-2">
//                     <label className="block text-sm font-semibold text-gray-700">
//                       Prix du siège (TND)
//                       {!priceManuallyEdited && form.price && (
//                         <span className="ml-2 text-xs text-blue-600">✨ Auto-calculé</span>
//                       )}
//                     </label>
//                     <input
//                       name="price"
//                       placeholder="Prix calculé automatiquement"
//                       type="number"
//                       min="1"
//                       step="0.5"
//                       value={form.price}
//                       className="w-full p-4 border border-gray-300 rounded-xl focus:ring-2 focus:ring-gray-500 focus:border-transparent transition bg-white"
//                       onChange={handleChange}
//                       required
//                     />
//                     {priceManuallyEdited && (
//                       <p className="text-xs text-gray-500 mt-1">
//                         Prix modifié manuellement
//                       </p>
//                     )}
//                   </div>
//                   <div className="space-y-2">
//                     <label className="block text-sm font-semibold text-gray-700">
//                       Sièges disponibles
//                     </label>
//                     <select
//                       name="nb_places_disponible"
//                       value={form.nb_places_disponible}
//                       className="w-full p-4 border border-gray-300 rounded-xl focus:ring-2 focus:ring-gray-500 focus:border-transparent transition bg-white"
//                       onChange={handleChange}
//                       required
//                     >
//                       <option value="">Choisir les sièges</option>
//                       {selectedCar &&
//                         Array.from(
//                           { length: selectedCar.nb_place - 1 },
//                           (_, i) => i + 1
//                         ).map((num) => (
//                           <option key={num} value={num.toString()}>
//                             {num} seat{num > 1 ? "s" : ""}
//                           </option>
//                         ))}
//                       {!selectedCar && (
//                         <>
//                           <option value="1">1 Place</option>
//                           <option value="2">2 Places</option>
//                           <option value="3">3 Places</option>
//                           <option value="4">4 Places</option>
//                         </>
//                       )}
//                     </select>
//                   </div>
//                 </div>
//               </FormSection>
//               {/* Car Selection Section */}
//               <FormSection title="Vehicle Information">
//                 <div className="space-y-4">
//                   <div className="space-y-2">
//                     <label className="block text-sm font-semibold text-gray-700">
//                       Choisir votre voiture
//                     </label>
//                     <select
//                       name="selected_car_id"
//                       value={form.selected_car_id}
//                       className="w-full p-4 border border-gray-300 rounded-xl focus:ring-2 focus:ring-gray-500 focus:border-transparent transition bg-white"
//                       onChange={handleChange}
//                       required
//                     >
//                       <option value="">
//                         Choisir une voiture depuis votre collection
//                       </option>
//                       {ownedCars.map((car) => (
//                         <option key={car.id} value={car.id.toString()}>
//                           {car.model_details?.brand.name || "Voiture"} {car.model_details?.name} ({car.year || "-"}){" - "}
//                           {car.color_details?.name} - {car.serial_number}
//                         </option>
//                       ))}
//                     </select>
//                   </div>
//                   {ownedCars.length === 0 && (
//                     <div className="bg-gray-50 rounded-xl p-6 border border-gray-200 text-center">
//                       <div className="text-gray-400 text-4xl mb-3">🚗</div>
//                       <h3 className="font-semibold text-gray-900 mb-2">
//                         Aucune voiture disponible
//                       </h3>
//                       <p className="text-gray-600 mb-4">
//                         Vous devez ajouter un véhicule à votre compte avant de proposer des trajets.
//                       </p>
//                       <button
//                         type="button"
//                         className="px-4 py-2 bg-black text-white rounded-lg hover:bg-gray-800 transition font-medium"
//                         onClick={() => (window.location.href = "/profile")}
//                       >
//                         Ajouter un véhicule
//                       </button>
//                     </div>
//                   )}
//                 </div>
//               </FormSection>
//               {/* Services Section */}
//               <FormSection title="Services & accessoires">
//                 <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
//                   {services.map((service) => (
//                     <label
//                       key={service.id}
//                       className="flex items-center space-x-3 cursor-pointer"
//                     >
//                       <input
//                         type="checkbox"
//                         checked={form.services.includes(service.id)}
//                         onChange={() => handleServiceChange(service.id)}
//                         className="w-5 h-5 text-gray-600 border-gray-300 rounded focus:ring-gray-500"
//                       />
//                       <span className="text-sm font-medium text-gray-700">
//                         {service.name}
//                       </span>
//                     </label>
//                   ))}
//                 </div>
//               </FormSection>
//               {/* Description Section */}
//               <FormSection title="Information supplémentaire">
//                 <div className="space-y-2">
//                   <label className="block text-sm font-semibold text-gray-700">
//                     Description (Optional)
//                   </label>
//                   <textarea
//                     name="description"
//                     value={form.description}
//                     placeholder="Mettre des informations additionnelles pour votre trajets, préférences et détails."
//                     rows={4}
//                     className="w-full p-4 border border-gray-300 rounded-xl focus:ring-2 focus:ring-gray-500 focus:border-transparent transition bg-white resize-none"
//                     onChange={handleChange}
//                   />
//                 </div>
//               </FormSection>
//               <button
//                 type="submit"
//                 className="w-full py-4 bg-black text-white rounded-xl font-semibold text-lg hover:bg-gray-800 transition transform hover:scale-105 shadow-lg"
//                 disabled={ownedCars.length === 0}
//               >
//                 Publier votre trajet
//               </button>
//             </form>
//           )}
//         </div>
//       </div>
//     </main>
//   );
// }
__turbopack_context__.s({
    "default": ()=>OfferRidePage
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$redux$2f$dist$2f$react$2d$redux$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-redux/dist/react-redux.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$offer$2f$FormSection$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/offer/FormSection.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$common$2f$SuccessMessage$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/common/SuccessMessage.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$api$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/api/api.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$shared$2f$lib$2f$app$2d$dynamic$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/shared/lib/app-dynamic.js [app-client] (ecmascript)");
;
;
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
const RouteMapLeaflet = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$shared$2f$lib$2f$app$2d$dynamic$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(()=>__turbopack_context__.r("[project]/app/offer/RouteMapLeaflet.tsx [app-client] (ecmascript, next/dynamic entry, async loader)")(__turbopack_context__.i), {
    loadableGenerated: {
        modules: [
            "[project]/app/offer/RouteMapLeaflet.tsx [app-client] (ecmascript, next/dynamic entry)"
        ]
    },
    ssr: false
});
_c = RouteMapLeaflet;
const SingleLocationMap = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$shared$2f$lib$2f$app$2d$dynamic$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(()=>__turbopack_context__.r("[project]/app/offer/SingleLocationMapProps.tsx [app-client] (ecmascript, next/dynamic entry, async loader)")(__turbopack_context__.i), {
    loadableGenerated: {
        modules: [
            "[project]/app/offer/SingleLocationMapProps.tsx [app-client] (ecmascript, next/dynamic entry)"
        ]
    },
    ssr: false
});
_c1 = SingleLocationMap;
function OfferRidePage() {
    _s();
    const user = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$redux$2f$dist$2f$react$2d$redux$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSelector"])({
        "OfferRidePage.useSelector[user]": (state)=>state.user.user
    }["OfferRidePage.useSelector[user]"]);
    const getDefaultDateTime = ()=>{
        const now = new Date();
        now.setHours(now.getHours() + 2);
        return now.toISOString().slice(0, 16);
    };
    const [form, setForm] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({
        departure_place: "",
        arrival_place: "",
        departure_date: getDefaultDateTime(),
        price: "",
        nb_places_disponible: "",
        selected_car_id: "",
        services: [],
        description: ""
    });
    const [success, setSuccess] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [error, setError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [ownedCars, setOwnedCars] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [services, setServices] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [delegations, setDelegations] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [loading, setLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(true);
    const [priceManuallyEdited, setPriceManuallyEdited] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [lastSuggestedPrice, setLastSuggestedPrice] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    // États pour les coordonnées précises
    const [preciseDepartureCoords, setPreciseDepartureCoords] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [preciseArrivalCoords, setPreciseArrivalCoords] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    // Réinitialiser les coordonnées précises quand l'utilisateur change de ville
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "OfferRidePage.useEffect": ()=>{
            setPreciseDepartureCoords(null);
        }
    }["OfferRidePage.useEffect"], [
        form.departure_place
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "OfferRidePage.useEffect": ()=>{
            setPreciseArrivalCoords(null);
        }
    }["OfferRidePage.useEffect"], [
        form.arrival_place
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "OfferRidePage.useEffect": ()=>{
            async function fetchData() {
                setLoading(true);
                try {
                    const [carsRes, servicesRes, delegationsRes] = await Promise.all([
                        __TURBOPACK__imported__module__$5b$project$5d2f$api$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].get("/api/cars/"),
                        __TURBOPACK__imported__module__$5b$project$5d2f$api$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].get("/api/services/"),
                        __TURBOPACK__imported__module__$5b$project$5d2f$api$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].get("/api/delegations/")
                    ]);
                    const cars = Array.isArray(carsRes.data) ? carsRes.data : carsRes.data.results || [];
                    const delegs = Array.isArray(delegationsRes.data) ? delegationsRes.data : delegationsRes.data.results || [];
                    setOwnedCars(cars);
                    setServices(servicesRes.data.results || servicesRes.data || []);
                    setDelegations(delegs);
                } catch (error) {
                    console.error("Error fetching data for offer page:", error);
                    setError("Unable to load data. Please try again later.");
                } finally{
                    setLoading(false);
                }
            }
            if (user) {
                fetchData();
            }
        }
    }["OfferRidePage.useEffect"], [
        user
    ]);
    const handleChange = (e)=>{
        const { name, value } = e.target;
        if (name === "price") {
            setPriceManuallyEdited(true);
        }
        setForm((prev)=>({
                ...prev,
                [name]: value
            }));
    };
    const handleServiceChange = (serviceId)=>{
        setForm((prev)=>({
                ...prev,
                services: prev.services.includes(serviceId) ? prev.services.filter((s)=>s !== serviceId) : [
                    ...prev.services,
                    serviceId
                ]
            }));
    };
    const handleDistanceCalculated = (distance, suggestedPrice)=>{
        if (priceManuallyEdited) return;
        const newPrice = suggestedPrice.toFixed(1);
        if (lastSuggestedPrice === newPrice) return;
        setLastSuggestedPrice(newPrice);
        setForm((prev)=>({
                ...prev,
                price: newPrice
            }));
    };
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "OfferRidePage.useEffect": ()=>{
            setPriceManuallyEdited(false);
        }
    }["OfferRidePage.useEffect"], [
        form.departure_place,
        form.arrival_place
    ]);
    const handleSubmit = async (e)=>{
        e.preventDefault();
        setError(null);
        const selectedCar = ownedCars.find((car)=>car.id === parseInt(form.selected_car_id));
        try {
            const postData = {
                departure_place: form.departure_place,
                arrival_place: form.arrival_place,
                departure_date: form.departure_date,
                price: form.price,
                nb_places_disponible: form.nb_places_disponible,
                description: form.description,
                user: user === null || user === void 0 ? void 0 : user.id,
                car: selectedCar === null || selectedCar === void 0 ? void 0 : selectedCar.id,
                status: "open",
                services_ids: form.services,
                // Ajouter les coordonnées précises si elles existent
                departure_coords: preciseDepartureCoords,
                arrival_coords: preciseArrivalCoords
            };
            console.log('📤 Données envoyées:', postData);
            await __TURBOPACK__imported__module__$5b$project$5d2f$api$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].post("/api/posts/", postData);
            setSuccess(true);
            // Réinitialiser le formulaire après succès
            setForm({
                departure_place: "",
                arrival_place: "",
                departure_date: getDefaultDateTime(),
                price: "",
                nb_places_disponible: "",
                selected_car_id: "",
                services: [],
                description: ""
            });
            setPreciseDepartureCoords(null);
            setPreciseArrivalCoords(null);
        } catch (err) {
            console.error('❌ Error publishing ride:', err);
            if (err && typeof err === 'object' && 'response' in err) {
                var _error_response_data, _error_response, _error_response1;
                const error = err;
                const detail = (_error_response = error.response) === null || _error_response === void 0 ? void 0 : (_error_response_data = _error_response.data) === null || _error_response_data === void 0 ? void 0 : _error_response_data.detail;
                const allErrors = ((_error_response1 = error.response) === null || _error_response1 === void 0 ? void 0 : _error_response1.data) ? Object.values(error.response.data).flat().join(" ") : "";
                setError(detail || allErrors || "An error occurred while publishing your ride.");
            } else {
                setError("An error occurred while publishing your ride.");
            }
        }
    };
    const selectedCar = ownedCars.find((car)=>car.id === parseInt(form.selected_car_id));
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("main", {
        className: "min-h-screen bg-gray-50 py-8",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "max-w-4xl mx-auto px-4",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "bg-white rounded-2xl shadow-xl p-8",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                        className: "text-4xl font-bold mb-8 text-center text-gray-900",
                        children: "Partager votre trajet"
                    }, void 0, false, {
                        fileName: "[project]/app/offer/page.tsx",
                        lineNumber: 1623,
                        columnNumber: 11
                    }, this),
                    error && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "mb-4 p-4 bg-red-100 text-red-700 rounded-lg border border-red-200",
                        children: error
                    }, void 0, false, {
                        fileName: "[project]/app/offer/page.tsx",
                        lineNumber: 1628,
                        columnNumber: 13
                    }, this),
                    success ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$common$2f$SuccessMessage$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        title: "Ride Offered Successfully!",
                        description: "Your ride has been posted and is now available for bookings.",
                        actionText: "Offer Another Ride",
                        onAction: ()=>setSuccess(false)
                    }, void 0, false, {
                        fileName: "[project]/app/offer/page.tsx",
                        lineNumber: 1633,
                        columnNumber: 13
                    }, this) : loading ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "text-center text-gray-500 py-12",
                        children: "Loading..."
                    }, void 0, false, {
                        fileName: "[project]/app/offer/page.tsx",
                        lineNumber: 1640,
                        columnNumber: 13
                    }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("form", {
                        onSubmit: handleSubmit,
                        className: "space-y-8",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$offer$2f$FormSection$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                title: "Route Information",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(RouteMapLeaflet, {
                                        delegations: delegations,
                                        departureName: form.departure_place,
                                        arrivalName: form.arrival_place,
                                        onDistanceCalculated: handleDistanceCalculated
                                    }, void 0, false, {
                                        fileName: "[project]/app/offer/page.tsx",
                                        lineNumber: 1646,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "grid grid-cols-1 md:grid-cols-2 gap-6 mt-6",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "space-y-2",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                        className: "block text-sm font-semibold text-gray-700",
                                                        children: "Departure Location"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/offer/page.tsx",
                                                        lineNumber: 1656,
                                                        columnNumber: 21
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                                                        name: "departure_place",
                                                        value: form.departure_place,
                                                        className: "w-full p-4 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent transition bg-white",
                                                        onChange: handleChange,
                                                        required: true,
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                                value: "",
                                                                children: "Sélectionner le départ"
                                                            }, void 0, false, {
                                                                fileName: "[project]/app/offer/page.tsx",
                                                                lineNumber: 1666,
                                                                columnNumber: 23
                                                            }, this),
                                                            delegations.map((d)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                                    value: d.name,
                                                                    children: d.name
                                                                }, d.id, false, {
                                                                    fileName: "[project]/app/offer/page.tsx",
                                                                    lineNumber: 1668,
                                                                    columnNumber: 25
                                                                }, this))
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/app/offer/page.tsx",
                                                        lineNumber: 1659,
                                                        columnNumber: 21
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/app/offer/page.tsx",
                                                lineNumber: 1655,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "space-y-2",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                        className: "block text-sm font-semibold text-gray-700",
                                                        children: "Arrival Location"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/offer/page.tsx",
                                                        lineNumber: 1676,
                                                        columnNumber: 21
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                                                        name: "arrival_place",
                                                        value: form.arrival_place,
                                                        className: "w-full p-4 border border-gray-300 rounded-xl focus:ring-2 focus:ring-green-500 focus:border-transparent transition bg-white",
                                                        onChange: handleChange,
                                                        required: true,
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                                value: "",
                                                                children: "Sélectionner l arrivee"
                                                            }, void 0, false, {
                                                                fileName: "[project]/app/offer/page.tsx",
                                                                lineNumber: 1686,
                                                                columnNumber: 23
                                                            }, this),
                                                            delegations.map((d)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                                    value: d.name,
                                                                    children: d.name
                                                                }, d.id, false, {
                                                                    fileName: "[project]/app/offer/page.tsx",
                                                                    lineNumber: 1688,
                                                                    columnNumber: 25
                                                                }, this))
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/app/offer/page.tsx",
                                                        lineNumber: 1679,
                                                        columnNumber: 21
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/app/offer/page.tsx",
                                                lineNumber: 1675,
                                                columnNumber: 19
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/app/offer/page.tsx",
                                        lineNumber: 1654,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "grid grid-cols-1 md:grid-cols-2 gap-6 mt-6",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(SingleLocationMap, {
                                                delegations: delegations,
                                                selectedLocation: form.departure_place,
                                                label: "🏁 Zoom sur le lieu de départ",
                                                markerColor: "departure",
                                                onPreciseLocationSelect: (lat, lng)=>{
                                                    setPreciseDepartureCoords({
                                                        lat,
                                                        lng
                                                    });
                                                    console.log('Position précise départ:', {
                                                        lat,
                                                        lng
                                                    });
                                                }
                                            }, void 0, false, {
                                                fileName: "[project]/app/offer/page.tsx",
                                                lineNumber: 1698,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(SingleLocationMap, {
                                                delegations: delegations,
                                                selectedLocation: form.arrival_place,
                                                label: "🎯 Zoom sur le lieu d'arrivée",
                                                markerColor: "arrival",
                                                onPreciseLocationSelect: (lat, lng)=>{
                                                    setPreciseArrivalCoords({
                                                        lat,
                                                        lng
                                                    });
                                                    console.log('Position précise arrivée:', {
                                                        lat,
                                                        lng
                                                    });
                                                }
                                            }, void 0, false, {
                                                fileName: "[project]/app/offer/page.tsx",
                                                lineNumber: 1709,
                                                columnNumber: 19
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/app/offer/page.tsx",
                                        lineNumber: 1697,
                                        columnNumber: 17
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/offer/page.tsx",
                                lineNumber: 1644,
                                columnNumber: 15
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$offer$2f$FormSection$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                title: "Planning et Disponibilité",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "grid grid-cols-1 md:grid-cols-3 gap-6",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "space-y-2",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                    className: "block text-sm font-semibold text-gray-700",
                                                    children: "Date & Time"
                                                }, void 0, false, {
                                                    fileName: "[project]/app/offer/page.tsx",
                                                    lineNumber: 1726,
                                                    columnNumber: 21
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                    name: "departure_date",
                                                    type: "datetime-local",
                                                    value: form.departure_date,
                                                    className: "w-full p-4 border border-gray-300 rounded-xl focus:ring-2 focus:ring-gray-500 focus:border-transparent transition bg-white",
                                                    onChange: handleChange,
                                                    required: true
                                                }, void 0, false, {
                                                    fileName: "[project]/app/offer/page.tsx",
                                                    lineNumber: 1729,
                                                    columnNumber: 21
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/app/offer/page.tsx",
                                            lineNumber: 1725,
                                            columnNumber: 19
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "space-y-2",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                    className: "block text-sm font-semibold text-gray-700",
                                                    children: [
                                                        "Prix du siège (TND)",
                                                        !priceManuallyEdited && form.price && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                            className: "ml-2 text-xs text-blue-600",
                                                            children: "✨ Auto-calculé"
                                                        }, void 0, false, {
                                                            fileName: "[project]/app/offer/page.tsx",
                                                            lineNumber: 1743,
                                                            columnNumber: 25
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/app/offer/page.tsx",
                                                    lineNumber: 1740,
                                                    columnNumber: 21
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                    name: "price",
                                                    placeholder: "Prix calculé automatiquement",
                                                    type: "number",
                                                    min: "1",
                                                    step: "0.5",
                                                    value: form.price,
                                                    className: "w-full p-4 border border-gray-300 rounded-xl focus:ring-2 focus:ring-gray-500 focus:border-transparent transition bg-white",
                                                    onChange: handleChange,
                                                    required: true
                                                }, void 0, false, {
                                                    fileName: "[project]/app/offer/page.tsx",
                                                    lineNumber: 1746,
                                                    columnNumber: 21
                                                }, this),
                                                priceManuallyEdited && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                    className: "text-xs text-gray-500 mt-1",
                                                    children: "Prix modifié manuellement"
                                                }, void 0, false, {
                                                    fileName: "[project]/app/offer/page.tsx",
                                                    lineNumber: 1758,
                                                    columnNumber: 23
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/app/offer/page.tsx",
                                            lineNumber: 1739,
                                            columnNumber: 19
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "space-y-2",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                    className: "block text-sm font-semibold text-gray-700",
                                                    children: "Sièges disponibles"
                                                }, void 0, false, {
                                                    fileName: "[project]/app/offer/page.tsx",
                                                    lineNumber: 1765,
                                                    columnNumber: 21
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                                                    name: "nb_places_disponible",
                                                    value: form.nb_places_disponible,
                                                    className: "w-full p-4 border border-gray-300 rounded-xl focus:ring-2 focus:ring-gray-500 focus:border-transparent transition bg-white",
                                                    onChange: handleChange,
                                                    required: true,
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                            value: "",
                                                            children: "Choisir les sièges"
                                                        }, void 0, false, {
                                                            fileName: "[project]/app/offer/page.tsx",
                                                            lineNumber: 1775,
                                                            columnNumber: 23
                                                        }, this),
                                                        selectedCar && Array.from({
                                                            length: selectedCar.nb_place - 1
                                                        }, (_, i)=>i + 1).map((num)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                                value: num.toString(),
                                                                children: [
                                                                    num,
                                                                    " seat",
                                                                    num > 1 ? "s" : ""
                                                                ]
                                                            }, num, true, {
                                                                fileName: "[project]/app/offer/page.tsx",
                                                                lineNumber: 1781,
                                                                columnNumber: 27
                                                            }, this)),
                                                        !selectedCar && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                                    value: "1",
                                                                    children: "1 Place"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/app/offer/page.tsx",
                                                                    lineNumber: 1787,
                                                                    columnNumber: 27
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                                    value: "2",
                                                                    children: "2 Places"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/app/offer/page.tsx",
                                                                    lineNumber: 1788,
                                                                    columnNumber: 27
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                                    value: "3",
                                                                    children: "3 Places"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/app/offer/page.tsx",
                                                                    lineNumber: 1789,
                                                                    columnNumber: 27
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                                    value: "4",
                                                                    children: "4 Places"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/app/offer/page.tsx",
                                                                    lineNumber: 1790,
                                                                    columnNumber: 27
                                                                }, this)
                                                            ]
                                                        }, void 0, true)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/app/offer/page.tsx",
                                                    lineNumber: 1768,
                                                    columnNumber: 21
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/app/offer/page.tsx",
                                            lineNumber: 1764,
                                            columnNumber: 19
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/app/offer/page.tsx",
                                    lineNumber: 1724,
                                    columnNumber: 17
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/app/offer/page.tsx",
                                lineNumber: 1723,
                                columnNumber: 15
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$offer$2f$FormSection$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                title: "Vehicle Information",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "space-y-4",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "space-y-2",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                    className: "block text-sm font-semibold text-gray-700",
                                                    children: "Choisir votre voiture"
                                                }, void 0, false, {
                                                    fileName: "[project]/app/offer/page.tsx",
                                                    lineNumber: 1802,
                                                    columnNumber: 21
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                                                    name: "selected_car_id",
                                                    value: form.selected_car_id,
                                                    className: "w-full p-4 border border-gray-300 rounded-xl focus:ring-2 focus:ring-gray-500 focus:border-transparent transition bg-white",
                                                    onChange: handleChange,
                                                    required: true,
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                            value: "",
                                                            children: "Choisir une voiture depuis votre collection"
                                                        }, void 0, false, {
                                                            fileName: "[project]/app/offer/page.tsx",
                                                            lineNumber: 1812,
                                                            columnNumber: 23
                                                        }, this),
                                                        ownedCars.map((car)=>{
                                                            var _car_model_details, _car_model_details1, _car_color_details;
                                                            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                                value: car.id.toString(),
                                                                children: [
                                                                    ((_car_model_details = car.model_details) === null || _car_model_details === void 0 ? void 0 : _car_model_details.brand.name) || "Voiture",
                                                                    " ",
                                                                    (_car_model_details1 = car.model_details) === null || _car_model_details1 === void 0 ? void 0 : _car_model_details1.name,
                                                                    " (",
                                                                    car.year || "-",
                                                                    ")",
                                                                    " - ",
                                                                    (_car_color_details = car.color_details) === null || _car_color_details === void 0 ? void 0 : _car_color_details.name,
                                                                    " - ",
                                                                    car.serial_number
                                                                ]
                                                            }, car.id, true, {
                                                                fileName: "[project]/app/offer/page.tsx",
                                                                lineNumber: 1816,
                                                                columnNumber: 25
                                                            }, this);
                                                        })
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/app/offer/page.tsx",
                                                    lineNumber: 1805,
                                                    columnNumber: 21
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/app/offer/page.tsx",
                                            lineNumber: 1801,
                                            columnNumber: 19
                                        }, this),
                                        ownedCars.length === 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "bg-gray-50 rounded-xl p-6 border border-gray-200 text-center",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "text-gray-400 text-4xl mb-3",
                                                    children: "🚗"
                                                }, void 0, false, {
                                                    fileName: "[project]/app/offer/page.tsx",
                                                    lineNumber: 1826,
                                                    columnNumber: 23
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                                    className: "font-semibold text-gray-900 mb-2",
                                                    children: "Aucune voiture disponible"
                                                }, void 0, false, {
                                                    fileName: "[project]/app/offer/page.tsx",
                                                    lineNumber: 1827,
                                                    columnNumber: 23
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                    className: "text-gray-600 mb-4",
                                                    children: "Vous devez ajouter un véhicule à votre compte avant de proposer des trajets."
                                                }, void 0, false, {
                                                    fileName: "[project]/app/offer/page.tsx",
                                                    lineNumber: 1830,
                                                    columnNumber: 23
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                    type: "button",
                                                    className: "px-4 py-2 bg-black text-white rounded-lg hover:bg-gray-800 transition font-medium",
                                                    onClick: ()=>window.location.href = "/profile",
                                                    children: "Ajouter un véhicule"
                                                }, void 0, false, {
                                                    fileName: "[project]/app/offer/page.tsx",
                                                    lineNumber: 1833,
                                                    columnNumber: 23
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/app/offer/page.tsx",
                                            lineNumber: 1825,
                                            columnNumber: 21
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/app/offer/page.tsx",
                                    lineNumber: 1800,
                                    columnNumber: 17
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/app/offer/page.tsx",
                                lineNumber: 1799,
                                columnNumber: 15
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$offer$2f$FormSection$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                title: "Services & accessoires",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "grid grid-cols-2 md:grid-cols-3 gap-4",
                                    children: services.map((service)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                            className: "flex items-center space-x-3 cursor-pointer",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                    type: "checkbox",
                                                    checked: form.services.includes(service.id),
                                                    onChange: ()=>handleServiceChange(service.id),
                                                    className: "w-5 h-5 text-gray-600 border-gray-300 rounded focus:ring-gray-500"
                                                }, void 0, false, {
                                                    fileName: "[project]/app/offer/page.tsx",
                                                    lineNumber: 1853,
                                                    columnNumber: 23
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: "text-sm font-medium text-gray-700",
                                                    children: service.name
                                                }, void 0, false, {
                                                    fileName: "[project]/app/offer/page.tsx",
                                                    lineNumber: 1859,
                                                    columnNumber: 23
                                                }, this)
                                            ]
                                        }, service.id, true, {
                                            fileName: "[project]/app/offer/page.tsx",
                                            lineNumber: 1849,
                                            columnNumber: 21
                                        }, this))
                                }, void 0, false, {
                                    fileName: "[project]/app/offer/page.tsx",
                                    lineNumber: 1847,
                                    columnNumber: 17
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/app/offer/page.tsx",
                                lineNumber: 1846,
                                columnNumber: 15
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$offer$2f$FormSection$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                title: "Information supplémentaire",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "space-y-2",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                            className: "block text-sm font-semibold text-gray-700",
                                            children: "Description (Optional)"
                                        }, void 0, false, {
                                            fileName: "[project]/app/offer/page.tsx",
                                            lineNumber: 1870,
                                            columnNumber: 19
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("textarea", {
                                            name: "description",
                                            value: form.description,
                                            placeholder: "Mettre des informations additionnelles pour votre trajets, preferences et details.",
                                            rows: 4,
                                            className: "w-full p-4 border border-gray-300 rounded-xl focus:ring-2 focus:ring-gray-500 focus:border-transparent transition bg-white resize-none",
                                            onChange: handleChange
                                        }, void 0, false, {
                                            fileName: "[project]/app/offer/page.tsx",
                                            lineNumber: 1873,
                                            columnNumber: 19
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/app/offer/page.tsx",
                                    lineNumber: 1869,
                                    columnNumber: 17
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/app/offer/page.tsx",
                                lineNumber: 1868,
                                columnNumber: 15
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                type: "submit",
                                className: "w-full py-4 bg-black text-white rounded-xl font-semibold text-lg hover:bg-gray-800 transition transform hover:scale-105 shadow-lg",
                                disabled: ownedCars.length === 0,
                                children: "Publier votre trajet"
                            }, void 0, false, {
                                fileName: "[project]/app/offer/page.tsx",
                                lineNumber: 1884,
                                columnNumber: 15
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/offer/page.tsx",
                        lineNumber: 1642,
                        columnNumber: 13
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/offer/page.tsx",
                lineNumber: 1622,
                columnNumber: 9
            }, this)
        }, void 0, false, {
            fileName: "[project]/app/offer/page.tsx",
            lineNumber: 1621,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/app/offer/page.tsx",
        lineNumber: 1620,
        columnNumber: 5
    }, this);
}
_s(OfferRidePage, "CkEnkT1lVdbDYUXl5nSYPY0Ntvk=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$redux$2f$dist$2f$react$2d$redux$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSelector"]
    ];
});
_c2 = OfferRidePage;
var _c, _c1, _c2;
__turbopack_context__.k.register(_c, "RouteMapLeaflet");
__turbopack_context__.k.register(_c1, "SingleLocationMap");
__turbopack_context__.k.register(_c2, "OfferRidePage");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
}]);

//# sourceMappingURL=_52e3652e._.js.map