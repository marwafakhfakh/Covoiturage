(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([typeof document === "object" ? document.currentScript : undefined, {

"[project]/app/offer/SingleLocationMapProps.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
// // // app/offer/SingleLocationMap.tsx
// // "use client";
// // import { useEffect, useMemo } from "react";
// // import { MapContainer, TileLayer, Marker, Popup, useMap } from "react-leaflet";
// // import type { LatLngExpression } from "leaflet";
// // import type { Delegation } from "./DelegationMapLeaflet";
// // // Composant pour recentrer la carte
// // function MapRecenter({ center, zoom }: { center: LatLngExpression; zoom: number }) {
// //   const map = useMap();
// //   useEffect(() => {
// //     map.setView(center, zoom);
// //   }, [center, zoom, map]);
// //   return null;
// // }
// // interface SingleLocationMapProps {
// //   delegations: Delegation[];
// //   selectedLocation: string;
// //   label: string;
// //   markerColor?: "departure" | "arrival";
// // }
// // export default function SingleLocationMap({
// //   delegations,
// //   selectedLocation,
// //   label,
// //   markerColor = "departure"
// // }: SingleLocationMapProps) {
// //   // Trouver la délégation sélectionnée
// //   const delegation = delegations.find((d) => d.name === selectedLocation);
// //   const lat = delegation ? parseFloat(delegation.latitude) : null;
// //   const lng = delegation ? parseFloat(delegation.longitude) : null;
// //   const hasValidCoords = 
// //     lat !== null &&
// //     lng !== null &&
// //     !Number.isNaN(lat) &&
// //     !Number.isNaN(lng);
// //   // Centre de la carte
// //   const center: LatLngExpression = useMemo(() => {
// //     if (hasValidCoords && lat !== null && lng !== null) {
// //       return [lat, lng];
// //     }
// //     return [35.7, 10.0]; // Centre Tunisie par défaut
// //   }, [hasValidCoords, lat, lng]);
// //   // Niveau de zoom
// //   const zoom = hasValidCoords ? 13 : 7;
// //   return (
// //     <div className="space-y-2">
// //       <label className="block text-sm font-semibold text-gray-700">
// //         {label}
// //       </label>
// //       <div className="rounded-lg border border-gray-200 overflow-hidden relative">
// //         {!hasValidCoords && selectedLocation && (
// //           <div className="absolute top-2 right-2 z-[1000] bg-yellow-50 px-3 py-1 rounded-full shadow-md text-xs text-yellow-700 border border-yellow-200">
// //             ⚠️ Coordonnées invalides
// //           </div>
// //         )}
// //         <MapContainer
// //           center={center}
// //           zoom={zoom}
// //           style={{ height: 200, width: "100%" }}
// //           scrollWheelZoom={false}
// //           zoomControl={true}
// //         >
// //           <TileLayer
// //             attribution='&copy; OpenStreetMap contributors'
// //             url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
// //           />
// //           {/* Recentrer la carte quand la sélection change */}
// //           <MapRecenter center={center} zoom={zoom} />
// //           {/* Afficher le marqueur si les coordonnées sont valides */}
// //           {hasValidCoords && lat !== null && lng !== null && (
// //             <Marker position={[lat, lng]}>
// //               <Popup>
// //                 <div className="text-sm">
// //                   <div className="font-semibold text-gray-900">
// //                     {markerColor === "departure" ? "📍 Départ" : "🎯 Arrivée"}
// //                   </div>
// //                   <div className="text-gray-700 mt-1">{delegation?.name}</div>
// //                 </div>
// //               </Popup>
// //             </Marker>
// //           )}
// //         </MapContainer>
// //       </div>
// //       {/* Afficher le nom de la délégation sélectionnée */}
// //       {hasValidCoords && delegation && (
// //         <div className={`text-xs px-3 py-2 rounded-lg ${
// //           markerColor === "departure" 
// //             ? "bg-blue-50 text-blue-700 border border-blue-200" 
// //             : "bg-green-50 text-green-700 border border-green-200"
// //         }`}>
// //           <span className="font-semibold">
// //             {markerColor === "departure" ? "📍" : "🎯"} Sélectionné:
// //           </span>{" "}
// //           {delegation.name}
// //         </div>
// //       )}
// //       {/* Message si aucune sélection */}
// //       {!selectedLocation && (
// //         <div className="text-xs text-gray-500 px-3 py-2 bg-gray-50 rounded-lg border border-gray-200">
// //           ℹ️ Sélectionnez un lieu pour voir sa position sur la carte
// //         </div>
// //       )}
// //     </div>
// //   );
// // }
// // app/offer/SingleLocationMapProps.tsx
// "use client";
// import { useEffect, useMemo, useState } from "react";
// import { MapContainer, TileLayer, Marker, Popup, useMap, useMapEvents } from "react-leaflet";
// import type { LatLngExpression } from "leaflet";
// import type { Delegation } from "./DelegationMapLeaflet";
// import L from "leaflet";
// // Composant pour recentrer la carte
// function MapRecenter({ center, zoom }: { center: LatLngExpression; zoom: number }) {
//   const map = useMap();
//   useEffect(() => {
//     map.setView(center, zoom);
//   }, [center, zoom, map]);
//   return null;
// }
// // Composant pour gérer les clics sur la carte
// function MapClickHandler({ 
//   onLocationSelect 
// }: { 
//   onLocationSelect: (lat: number, lng: number) => void 
// }) {
//   useMapEvents({
//     click: (e) => {
//       onLocationSelect(e.latlng.lat, e.latlng.lng);
//     },
//   });
//   return null;
// }
// interface SingleLocationMapProps {
//   delegations: Delegation[];
//   selectedLocation: string;
//   label: string;
//   markerColor?: "departure" | "arrival";
//   onPreciseLocationSelect?: (lat: number, lng: number) => void;
// }
// export default function SingleLocationMap({
//   delegations,
//   selectedLocation,
//   label,
//   markerColor = "departure",
//   onPreciseLocationSelect
// }: SingleLocationMapProps) {
//   // Trouver la délégation sélectionnée
//   const delegation = delegations.find((d) => d.name === selectedLocation);
//   const delegationLat = delegation ? parseFloat(delegation.latitude) : null;
//   const delegationLng = delegation ? parseFloat(delegation.longitude) : null;
//   // État pour la position précise (cliquée par l'utilisateur)
//   const [preciseLocation, setPreciseLocation] = useState<{lat: number, lng: number} | null>(null);
//   // Réinitialiser la position précise quand la délégation change
//   useEffect(() => {
//     setPreciseLocation(null);
//   }, [selectedLocation]);
//   const hasValidCoords = 
//     delegationLat !== null &&
//     delegationLng !== null &&
//     !Number.isNaN(delegationLat) &&
//     !Number.isNaN(delegationLng);
//   // Position du marqueur : utiliser la position précise si elle existe, sinon la position de la délégation
//   const markerLat = preciseLocation?.lat ?? delegationLat;
//   const markerLng = preciseLocation?.lng ?? delegationLng;
//   // Centre de la carte
//   const center: LatLngExpression = useMemo(() => {
//     if (hasValidCoords && delegationLat !== null && delegationLng !== null) {
//       return [delegationLat, delegationLng];
//     }
//     return [35.7, 10.0]; // Centre Tunisie par défaut
//   }, [hasValidCoords, delegationLat, delegationLng]);
//   // Niveau de zoom : plus proche pour permettre de voir les détails
//   const zoom = hasValidCoords ? 14 : 7;
//   // Gérer le clic sur la carte
//   const handleLocationSelect = (lat: number, lng: number) => {
//     setPreciseLocation({ lat, lng });
//     if (onPreciseLocationSelect) {
//       onPreciseLocationSelect(lat, lng);
//     }
//   };
//   // Réinitialiser la position précise
//   const handleReset = () => {
//     setPreciseLocation(null);
//     if (onPreciseLocationSelect && delegationLat !== null && delegationLng !== null) {
//       onPreciseLocationSelect(delegationLat, delegationLng);
//     }
//   };
//   return (
//     <div className="space-y-2">
//       <label className="block text-sm font-semibold text-gray-700">
//         {label}
//       </label>
//       <div className="rounded-lg border border-gray-200 overflow-hidden relative">
//         {!hasValidCoords && selectedLocation && (
//           <div className="absolute top-2 right-2 z-[1000] bg-yellow-50 px-3 py-1 rounded-full shadow-md text-xs text-yellow-700 border border-yellow-200">
//             ⚠️ Coordonnées invalides
//           </div>
//         )}
//         {hasValidCoords && (
//           <div className="absolute top-2 left-2 z-[1000] bg-white px-3 py-1 rounded-lg shadow-md text-xs text-gray-700 border border-gray-200">
//             📍 Cliquez sur la carte pour affiner la position
//           </div>
//         )}
//         <MapContainer
//           center={center}
//           zoom={zoom}
//           style={{ height: 260, width: "100%" }}
//           scrollWheelZoom={true}
//           zoomControl={true}
//         >
//           <TileLayer
//             attribution='&copy; OpenStreetMap contributors'
//             url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
//           />
//           {/* Recentrer la carte quand la sélection change */}
//           <MapRecenter center={center} zoom={zoom} />
//           {/* Gérer les clics sur la carte */}
//           {hasValidCoords && (
//             <MapClickHandler onLocationSelect={handleLocationSelect} />
//           )}
//           {/* Afficher le marqueur si les coordonnées sont valides */}
//           {hasValidCoords && markerLat !== null && markerLng !== null && (
//             <Marker position={[markerLat, markerLng]}>
//               <Popup>
//                 <div className="text-sm">
//                   <div className="font-semibold text-gray-900">
//                     {markerColor === "departure" ? "🏁 Départ" : "🎯 Arrivée"}
//                   </div>
//                   <div className="text-gray-700 mt-1">{delegation?.name}</div>
//                   {preciseLocation && (
//                     <div className="text-xs text-blue-600 mt-1">
//                       📍 Position affinée
//                     </div>
//                   )}
//                 </div>
//               </Popup>
//             </Marker>
//           )}
//         </MapContainer>
//       </div>
//       {/* Afficher le nom de la délégation sélectionnée */}
//       {hasValidCoords && delegation && (
//         <div className="space-y-2">
//           <div className={`text-xs px-3 py-2 rounded-lg ${
//             markerColor === "departure" 
//               ? "bg-blue-50 text-blue-700 border border-blue-200" 
//               : "bg-green-50 text-green-700 border border-green-200"
//           }`}>
//             <span className="font-semibold">
//               {markerColor === "departure" ? "🏁" : "🎯"} Sélectionné:
//             </span>{" "}
//             {delegation.name}
//             {preciseLocation && (
//               <span className="ml-2 text-xs">
//                 • Position affinée
//               </span>
//             )}
//           </div>
//           {preciseLocation && (
//             <button
//               type="button"
//               onClick={handleReset}
//               className="w-full text-xs px-3 py-2 bg-gray-100 hover:bg-gray-200 text-gray-700 rounded-lg border border-gray-300 transition"
//             >
//               🔄 Réinitialiser au centre de {delegation.name}
//             </button>
//           )}
//         </div>
//       )}
//       {/* Message si aucune sélection */}
//       {!selectedLocation && (
//         <div className="text-xs text-gray-500 px-3 py-2 bg-gray-50 rounded-lg border border-gray-200">
//           ℹ️ Sélectionnez un lieu pour voir sa position sur la carte
//         </div>
//       )}
//     </div>
//   );
// }
// app/offer/SingleLocationMapProps.tsx
__turbopack_context__.s({
    "default": ()=>SingleLocationMap
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$leaflet$2f$lib$2f$MapContainer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-leaflet/lib/MapContainer.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$leaflet$2f$lib$2f$TileLayer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-leaflet/lib/TileLayer.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$leaflet$2f$lib$2f$Marker$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-leaflet/lib/Marker.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$leaflet$2f$lib$2f$Popup$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-leaflet/lib/Popup.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$leaflet$2f$lib$2f$hooks$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-leaflet/lib/hooks.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature(), _s2 = __turbopack_context__.k.signature();
"use client";
;
;
// Composant pour recentrer la carte
function MapRecenter(param) {
    let { center, zoom } = param;
    _s();
    const map = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$leaflet$2f$lib$2f$hooks$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMap"])();
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "MapRecenter.useEffect": ()=>{
            map.setView(center, zoom);
        }
    }["MapRecenter.useEffect"], [
        center,
        zoom,
        map
    ]);
    return null;
}
_s(MapRecenter, "IoceErwr5KVGS9kN4RQ1bOkYMAg=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$leaflet$2f$lib$2f$hooks$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMap"]
    ];
});
_c = MapRecenter;
// Composant pour gérer les clics sur la carte
function MapClickHandler(param) {
    let { onLocationSelect } = param;
    _s1();
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$leaflet$2f$lib$2f$hooks$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMapEvents"])({
        click: {
            "MapClickHandler.useMapEvents": (e)=>{
                onLocationSelect(e.latlng.lat, e.latlng.lng);
            }
        }["MapClickHandler.useMapEvents"]
    });
    return null;
}
_s1(MapClickHandler, "Ld/tk8Iz8AdZhC1l7acENaOEoCo=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$leaflet$2f$lib$2f$hooks$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMapEvents"]
    ];
});
_c1 = MapClickHandler;
function SingleLocationMap(param) {
    let { delegations, selectedLocation, label, markerColor = "departure", onPreciseLocationSelect } = param;
    _s2();
    // Trouver la délégation sélectionnée
    const delegation = delegations.find((d)=>d.name === selectedLocation);
    const delegationLat = delegation ? parseFloat(delegation.latitude) : null;
    const delegationLng = delegation ? parseFloat(delegation.longitude) : null;
    // État pour la position précise (cliquée par l'utilisateur)
    const [preciseLocation, setPreciseLocation] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    // Réinitialiser la position précise quand la délégation change
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "SingleLocationMap.useEffect": ()=>{
            setPreciseLocation(null);
        }
    }["SingleLocationMap.useEffect"], [
        selectedLocation
    ]);
    const hasValidCoords = delegationLat !== null && delegationLng !== null && !Number.isNaN(delegationLat) && !Number.isNaN(delegationLng);
    var _preciseLocation_lat;
    // Position du marqueur : utiliser la position précise si elle existe, sinon la position de la délégation
    const markerLat = (_preciseLocation_lat = preciseLocation === null || preciseLocation === void 0 ? void 0 : preciseLocation.lat) !== null && _preciseLocation_lat !== void 0 ? _preciseLocation_lat : delegationLat;
    var _preciseLocation_lng;
    const markerLng = (_preciseLocation_lng = preciseLocation === null || preciseLocation === void 0 ? void 0 : preciseLocation.lng) !== null && _preciseLocation_lng !== void 0 ? _preciseLocation_lng : delegationLng;
    // Centre de la carte
    const center = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "SingleLocationMap.useMemo[center]": ()=>{
            if (hasValidCoords && delegationLat !== null && delegationLng !== null) {
                return [
                    delegationLat,
                    delegationLng
                ];
            }
            return [
                35.7,
                10.0
            ]; // Centre Tunisie par défaut
        }
    }["SingleLocationMap.useMemo[center]"], [
        hasValidCoords,
        delegationLat,
        delegationLng
    ]);
    // Niveau de zoom : plus proche pour permettre de voir les détails
    const zoom = hasValidCoords ? 14 : 7;
    // Gérer le clic sur la carte
    const handleLocationSelect = (lat, lng)=>{
        setPreciseLocation({
            lat,
            lng
        });
        if (onPreciseLocationSelect) {
            onPreciseLocationSelect(lat, lng);
        }
    };
    // Réinitialiser la position précise
    const handleReset = ()=>{
        setPreciseLocation(null);
        if (onPreciseLocationSelect && delegationLat !== null && delegationLng !== null) {
            onPreciseLocationSelect(delegationLat, delegationLng);
        }
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "space-y-2",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                className: "block text-sm font-semibold text-gray-700",
                children: label
            }, void 0, false, {
                fileName: "[project]/app/offer/SingleLocationMapProps.tsx",
                lineNumber: 424,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "rounded-lg border border-gray-200 overflow-hidden relative",
                children: [
                    !hasValidCoords && selectedLocation && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "absolute top-2 right-2 z-[1000] bg-yellow-50 px-3 py-1 rounded-full shadow-md text-xs text-yellow-700 border border-yellow-200",
                        children: "⚠️ Coordonnées invalides"
                    }, void 0, false, {
                        fileName: "[project]/app/offer/SingleLocationMapProps.tsx",
                        lineNumber: 430,
                        columnNumber: 11
                    }, this),
                    hasValidCoords && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "absolute top-2 left-2 z-[1000] bg-white px-3 py-1 rounded-lg shadow-md text-xs text-gray-700 border border-gray-200",
                        children: "📍 Cliquez sur la carte pour affiner la position"
                    }, void 0, false, {
                        fileName: "[project]/app/offer/SingleLocationMapProps.tsx",
                        lineNumber: 436,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$leaflet$2f$lib$2f$MapContainer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MapContainer"], {
                        center: center,
                        zoom: zoom,
                        style: {
                            height: 260,
                            width: "100%"
                        },
                        scrollWheelZoom: true,
                        zoomControl: true,
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$leaflet$2f$lib$2f$TileLayer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TileLayer"], {
                                attribution: "© OpenStreetMap contributors",
                                url: "https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
                            }, void 0, false, {
                                fileName: "[project]/app/offer/SingleLocationMapProps.tsx",
                                lineNumber: 448,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(MapRecenter, {
                                center: center,
                                zoom: zoom
                            }, void 0, false, {
                                fileName: "[project]/app/offer/SingleLocationMapProps.tsx",
                                lineNumber: 454,
                                columnNumber: 11
                            }, this),
                            hasValidCoords && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(MapClickHandler, {
                                onLocationSelect: handleLocationSelect
                            }, void 0, false, {
                                fileName: "[project]/app/offer/SingleLocationMapProps.tsx",
                                lineNumber: 458,
                                columnNumber: 13
                            }, this),
                            hasValidCoords && markerLat !== null && markerLng !== null && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$leaflet$2f$lib$2f$Marker$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Marker"], {
                                position: [
                                    markerLat,
                                    markerLng
                                ],
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$leaflet$2f$lib$2f$Popup$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Popup"], {
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "text-sm",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "font-semibold text-gray-900",
                                                children: markerColor === "departure" ? "🚗 Départ" : "🎯 Arrivée"
                                            }, void 0, false, {
                                                fileName: "[project]/app/offer/SingleLocationMapProps.tsx",
                                                lineNumber: 466,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "text-gray-700 mt-1",
                                                children: delegation === null || delegation === void 0 ? void 0 : delegation.name
                                            }, void 0, false, {
                                                fileName: "[project]/app/offer/SingleLocationMapProps.tsx",
                                                lineNumber: 469,
                                                columnNumber: 19
                                            }, this),
                                            preciseLocation && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "text-xs text-blue-600 mt-1",
                                                children: "📍 Position affinée"
                                            }, void 0, false, {
                                                fileName: "[project]/app/offer/SingleLocationMapProps.tsx",
                                                lineNumber: 471,
                                                columnNumber: 21
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/app/offer/SingleLocationMapProps.tsx",
                                        lineNumber: 465,
                                        columnNumber: 17
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/app/offer/SingleLocationMapProps.tsx",
                                    lineNumber: 464,
                                    columnNumber: 15
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/app/offer/SingleLocationMapProps.tsx",
                                lineNumber: 463,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/offer/SingleLocationMapProps.tsx",
                        lineNumber: 441,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/offer/SingleLocationMapProps.tsx",
                lineNumber: 428,
                columnNumber: 7
            }, this),
            hasValidCoords && delegation && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "space-y-2",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "text-xs px-3 py-2 rounded-lg ".concat(markerColor === "departure" ? "bg-blue-50 text-blue-700 border border-blue-200" : "bg-green-50 text-green-700 border border-green-200"),
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "font-semibold",
                                children: [
                                    markerColor === "departure" ? "🚗" : "🎯",
                                    " Sélectionné:"
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/offer/SingleLocationMapProps.tsx",
                                lineNumber: 490,
                                columnNumber: 13
                            }, this),
                            " ",
                            delegation.name,
                            preciseLocation && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "ml-2 text-xs",
                                children: "• Position affinée"
                            }, void 0, false, {
                                fileName: "[project]/app/offer/SingleLocationMapProps.tsx",
                                lineNumber: 495,
                                columnNumber: 15
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/offer/SingleLocationMapProps.tsx",
                        lineNumber: 485,
                        columnNumber: 11
                    }, this),
                    preciseLocation && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        type: "button",
                        onClick: handleReset,
                        className: "w-full text-xs px-3 py-2 bg-gray-100 hover:bg-gray-200 text-gray-700 rounded-lg border border-gray-300 transition",
                        children: [
                            "🔄 Réinitialiser au centre de ",
                            delegation.name
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/offer/SingleLocationMapProps.tsx",
                        lineNumber: 502,
                        columnNumber: 13
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/offer/SingleLocationMapProps.tsx",
                lineNumber: 484,
                columnNumber: 9
            }, this),
            !selectedLocation && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "text-xs text-gray-500 px-3 py-2 bg-gray-50 rounded-lg border border-gray-200",
                children: "ℹ️ Sélectionnez un lieu pour voir sa position sur la carte"
            }, void 0, false, {
                fileName: "[project]/app/offer/SingleLocationMapProps.tsx",
                lineNumber: 515,
                columnNumber: 9
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/offer/SingleLocationMapProps.tsx",
        lineNumber: 423,
        columnNumber: 5
    }, this);
}
_s2(SingleLocationMap, "WtTPEQnIkRP7oxTrKqqb9Q+cEgI=");
_c2 = SingleLocationMap;
var _c, _c1, _c2;
__turbopack_context__.k.register(_c, "MapRecenter");
__turbopack_context__.k.register(_c1, "MapClickHandler");
__turbopack_context__.k.register(_c2, "SingleLocationMap");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/app/offer/SingleLocationMapProps.tsx [app-client] (ecmascript, next/dynamic entry)": ((__turbopack_context__) => {

__turbopack_context__.n(__turbopack_context__.i("[project]/app/offer/SingleLocationMapProps.tsx [app-client] (ecmascript)"));
}),
}]);

//# sourceMappingURL=app_offer_SingleLocationMapProps_tsx_ce3e361f._.js.map