(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([typeof document === "object" ? document.currentScript : undefined, {

"[project]/app/offer/RouteMapLeaflet.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
// // // // app/offer/RouteMapLeaflet.tsx
// // // "use client";
// // // import { MapContainer, TileLayer, Marker, Popup, Polyline } from "react-leaflet";
// // // import type { LatLngExpression } from "leaflet";
// // // import { useEffect, useMemo, useState } from "react";
// // // import type { Delegation } from "./DelegationMapLeaflet";
// // // import { useMap } from "react-leaflet";
// // // import L from "leaflet";
// // // function FitBounds({ fromLat, fromLng, toLat, toLng }: { fromLat: number; fromLng: number; toLat: number; toLng: number }) {
// // //   const map = useMap();
// // //   useEffect(() => {
// // //     const bounds = L.latLngBounds(
// // //       [fromLat, fromLng],
// // //       [toLat, toLng]
// // //     );
// // //     map.fitBounds(bounds, { padding: [40, 40] });
// // //   }, [fromLat, fromLng, toLat, toLng, map]);
// // //   return null;
// // // }
// // // // distance haversine en km
// // // function toRad(deg: number) {
// // //   return (deg * Math.PI) / 180;
// // // }
// // // function haversineKm(a: { lat: number; lng: number }, b: { lat: number; lng: number }) {
// // //   const R = 6371;
// // //   const dLat = toRad(b.lat - a.lat);
// // //   const dLng = toRad(b.lng - a.lng);
// // //   const lat1 = toRad(a.lat);
// // //   const lat2 = toRad(b.lat);
// // //   const sinDLat = Math.sin(dLat / 2);
// // //   const sinDLng = Math.sin(dLng / 2);
// // //   const h =
// // //     sinDLat * sinDLat +
// // //     Math.cos(lat1) * Math.cos(lat2) * sinDLng * sinDLng;
// // //   const c = 2 * Math.atan2(Math.sqrt(h), Math.sqrt(1 - h));
// // //   return R * c;
// // // }
// // // interface Props {
// // //   delegations: Delegation[];
// // //   departureName: string;
// // //   arrivalName: string;
// // // }
// // // export default function RouteMapLeaflet({
// // //   delegations,
// // //   departureName,
// // //   arrivalName,
// // // }: Props) {
// // //   const from = delegations.find((d) => d.name === departureName);
// // //   const to = delegations.find((d) => d.name === arrivalName);
// // //   const fromLat = from ? parseFloat(from.latitude) : null;
// // //   const fromLng = from ? parseFloat(from.longitude) : null;
// // //   const toLat = to ? parseFloat(to.latitude) : null;
// // //   const toLng = to ? parseFloat(to.longitude) : null;
// // //   const [routeCoordinates, setRouteCoordinates] = useState<[number, number][]>([]);
// // //   const [routeDistance, setRouteDistance] = useState<number>(0);
// // //   const [loadingRoute, setLoadingRoute] = useState(false);
// // //   const hasBoth =
// // //     fromLat !== null &&
// // //     fromLng !== null &&
// // //     !Number.isNaN(fromLat) &&
// // //     !Number.isNaN(fromLng) &&
// // //     toLat !== null &&
// // //     toLng !== null &&
// // //     !Number.isNaN(toLat) &&
// // //     !Number.isNaN(toLng);
// // //   const center: LatLngExpression = useMemo(() => {
// // //     if (hasBoth && fromLat !== null && fromLng !== null && toLat !== null && toLng !== null) {
// // //       return [(fromLat + toLat) / 2, (fromLng + toLng) / 2];
// // //     }
// // //     return [35.7, 10.0]; // centre Tunisie
// // //   }, [hasBoth, fromLat, fromLng, toLat, toLng]);
// // //   // Récupérer le trajet réel depuis OSRM
// // //   useEffect(() => {
// // //     if (!hasBoth || fromLat === null || fromLng === null || toLat === null || toLng === null) {
// // //       setRouteCoordinates([]);
// // //       setRouteDistance(0);
// // //       return;
// // //     }
// // //     const fetchRoute = async () => {
// // //       setLoadingRoute(true);
// // //       try {
// // //         // API OSRM pour obtenir le trajet routier
// // //         const response = await fetch(
// // //           `https://router.project-osrm.org/route/v1/driving/${fromLng},${fromLat};${toLng},${toLat}?overview=full&geometries=geojson`
// // //         );
// // //         const data = await response.json();
// // //         if (data.code === "Ok" && data.routes && data.routes.length > 0) {
// // //           const route = data.routes[0];
// // //           const coords: [number, number][] = route.geometry.coordinates.map(
// // //             (coord: number[]) => [coord[1], coord[0]] as [number, number]
// // //           );
// // //           setRouteCoordinates(coords);
// // //           setRouteDistance(route.distance / 1000); // convertir en km
// // //         }
// // //       } catch (error) {
// // //         console.error("Erreur lors de la récupération du trajet:", error);
// // //         // En cas d'erreur, utiliser la ligne droite
// // //         setRouteCoordinates([[fromLat, fromLng], [toLat, toLng]]);
// // //         setRouteDistance(haversineKm({ lat: fromLat, lng: fromLng }, { lat: toLat, lng: toLng }));
// // //       } finally {
// // //         setLoadingRoute(false);
// // //       }
// // //     };
// // //     fetchRoute();
// // //   }, [hasBoth, fromLat, fromLng, toLat, toLng]);
// // //   let distanceKm = routeDistance || 0;
// // //   if (distanceKm === 0 && hasBoth && fromLat !== null && fromLng !== null && toLat !== null && toLng !== null) {
// // //     distanceKm = haversineKm(
// // //       { lat: fromLat, lng: fromLng },
// // //       { lat: toLat, lng: toLng }
// // //     );
// // //   }
// // //   return (
// // //     <div className="space-y-2">
// // //       <div className="rounded-lg border border-gray-200 overflow-hidden relative">
// // //         {loadingRoute && (
// // //           <div className="absolute top-2 right-2 z-[1000] bg-white px-3 py-1 rounded-full shadow-md text-xs text-gray-600">
// // //             Chargement du trajet...
// // //           </div>
// // //         )}
// // //         <MapContainer
// // //           center={center}
// // //           zoom={hasBoth ? 8 : 7}
// // //           style={{ height: 260, width: "100%" }}
// // //           scrollWheelZoom={false}
// // //         >
// // //           <TileLayer
// // //             attribution='&copy; OpenStreetMap contributors'
// // //             url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
// // //           />
// // //           {fromLat !== null && fromLng !== null && !Number.isNaN(fromLat) && !Number.isNaN(fromLng) && (
// // //             <Marker position={[fromLat, fromLng]}>
// // //               <Popup>
// // //                 <strong>Départ</strong>
// // //                 <br />
// // //                 {from?.name}
// // //               </Popup>
// // //             </Marker>
// // //           )}
// // //           {toLat !== null && toLng !== null && !Number.isNaN(toLat) && !Number.isNaN(toLng) && (
// // //             <Marker position={[toLat, toLng]}>
// // //               <Popup>
// // //                 <strong>Arrivée</strong>
// // //                 <br />
// // //                 {to?.name}
// // //               </Popup>
// // //             </Marker>
// // //           )}
// // //           {/* Afficher le trajet routier réel */}
// // //           {routeCoordinates.length > 0 && (
// // //             <Polyline
// // //               positions={routeCoordinates}
// // //               color="#10b981"
// // //               weight={5}
// // //               opacity={0.8}
// // //             />
// // //           )}
// // //           {hasBoth && (
// // //             <FitBounds
// // //               fromLat={fromLat as number}
// // //               fromLng={fromLng as number}
// // //               toLat={toLat as number}
// // //               toLng={toLng as number}
// // //             />
// // //           )}
// // //         </MapContainer>
// // //       </div>
// // //       {hasBoth && (
// // //         <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-2 mt-2">
// // //           <div className="text-sm text-emerald-800 bg-emerald-50 border border-emerald-200 rounded-lg px-3 py-2">
// // //             Distance {routeDistance > 0 ? "routière" : "estimée"} : {distanceKm.toFixed(1)} km
// // //           </div>
// // //           <div className="text-xs md:text-sm text-gray-600">
// // //             <b>Prix recommandé: </b>[Entre 0.2 - 0.3] TND/Km dans la même ville | Au Forfait [entre 10 - 25] TND entre les villes.
// // //           </div>
// // //         </div>
// // //       )}
// // //     </div>
// // //   );
// // // }
// // // app/offer/RouteMapLeaflet.tsx
// // "use client";
// // import { MapContainer, TileLayer, Marker, Popup, Polyline } from "react-leaflet";
// // import type { LatLngExpression } from "leaflet";
// // import { useEffect, useMemo, useState } from "react";
// // import type { Delegation } from "./DelegationMapLeaflet";
// // import { useMap } from "react-leaflet";
// // import L from "leaflet";
// // function FitBounds({ fromLat, fromLng, toLat, toLng }: { fromLat: number; fromLng: number; toLat: number; toLng: number }) {
// //   const map = useMap();
// //   useEffect(() => {
// //     const bounds = L.latLngBounds(
// //       [fromLat, fromLng],
// //       [toLat, toLng]
// //     );
// //     map.fitBounds(bounds, { padding: [50, 50] });
// //   }, [fromLat, fromLng, toLat, toLng, map]);
// //   return null;
// // }
// // // distance haversine en km
// // function toRad(deg: number) {
// //   return (deg * Math.PI) / 180;
// // }
// // function haversineKm(a: { lat: number; lng: number }, b: { lat: number; lng: number }) {
// //   const R = 6371;
// //   const dLat = toRad(b.lat - a.lat);
// //   const dLng = toRad(b.lng - a.lng);
// //   const lat1 = toRad(a.lat);
// //   const lat2 = toRad(b.lat);
// //   const sinDLat = Math.sin(dLat / 2);
// //   const sinDLng = Math.sin(dLng / 2);
// //   const h =
// //     sinDLat * sinDLat +
// //     Math.cos(lat1) * Math.cos(lat2) * sinDLng * sinDLng;
// //   const c = 2 * Math.atan2(Math.sqrt(h), Math.sqrt(1 - h));
// //   return R * c;
// // }
// // interface Props {
// //   delegations: Delegation[];
// //   departureName: string;
// //   arrivalName: string;
// // }
// // export default function RouteMapLeaflet({
// //   delegations,
// //   departureName,
// //   arrivalName,
// // }: Props) {
// //   const from = delegations.find((d) => d.name === departureName);
// //   const to = delegations.find((d) => d.name === arrivalName);
// //   const fromLat = from ? parseFloat(from.latitude) : null;
// //   const fromLng = from ? parseFloat(from.longitude) : null;
// //   const toLat = to ? parseFloat(to.latitude) : null;
// //   const toLng = to ? parseFloat(to.longitude) : null;
// //   const [routeCoordinates, setRouteCoordinates] = useState<[number, number][]>([]);
// //   const [routeDistance, setRouteDistance] = useState<number>(0);
// //   const [loadingRoute, setLoadingRoute] = useState(false);
// //   const hasBoth =
// //     fromLat !== null &&
// //     fromLng !== null &&
// //     !Number.isNaN(fromLat) &&
// //     !Number.isNaN(fromLng) &&
// //     toLat !== null &&
// //     toLng !== null &&
// //     !Number.isNaN(toLat) &&
// //     !Number.isNaN(toLng);
// //   const center: LatLngExpression = useMemo(() => {
// //     if (hasBoth && fromLat !== null && fromLng !== null && toLat !== null && toLng !== null) {
// //       return [(fromLat + toLat) / 2, (fromLng + toLng) / 2];
// //     }
// //     return [35.7, 10.0]; // centre Tunisie
// //   }, [hasBoth, fromLat, fromLng, toLat, toLng]);
// //   // Récupérer le trajet réel depuis OSRM
// //   useEffect(() => {
// //     if (!hasBoth || fromLat === null || fromLng === null || toLat === null || toLng === null) {
// //       setRouteCoordinates([]);
// //       setRouteDistance(0);
// //       return;
// //     }
// //     const fetchRoute = async () => {
// //       setLoadingRoute(true);
// //       try {
// //         // API OSRM pour obtenir le trajet routier
// //         const response = await fetch(
// //           `https://router.project-osrm.org/route/v1/driving/${fromLng},${fromLat};${toLng},${toLat}?overview=full&geometries=geojson`
// //         );
// //         const data = await response.json();
// //         if (data.code === "Ok" && data.routes && data.routes.length > 0) {
// //           const route = data.routes[0];
// //           const coords: [number, number][] = route.geometry.coordinates.map(
// //             (coord: number[]) => [coord[1], coord[0]] as [number, number]
// //           );
// //           setRouteCoordinates(coords);
// //           setRouteDistance(route.distance / 1000); // convertir en km
// //         }
// //       } catch (error) {
// //         console.error("Erreur lors de la récupération du trajet:", error);
// //         // En cas d'erreur, utiliser la ligne droite
// //         setRouteCoordinates([[fromLat, fromLng], [toLat, toLng]]);
// //         setRouteDistance(haversineKm({ lat: fromLat, lng: fromLng }, { lat: toLat, lng: toLng }));
// //       } finally {
// //         setLoadingRoute(false);
// //       }
// //     };
// //     fetchRoute();
// //   }, [hasBoth, fromLat, fromLng, toLat, toLng]);
// //   let distanceKm = routeDistance || 0;
// //   if (distanceKm === 0 && hasBoth && fromLat !== null && fromLng !== null && toLat !== null && toLng !== null) {
// //     distanceKm = haversineKm(
// //       { lat: fromLat, lng: fromLng },
// //       { lat: toLat, lng: toLng }
// //     );
// //   }
// //   return (
// //     <div className="space-y-2">
// //       <div className="rounded-lg border border-gray-200 overflow-hidden relative">
// //         {loadingRoute && (
// //           <div className="absolute top-2 right-2 z-[1000] bg-white px-3 py-1 rounded-full shadow-md text-xs text-gray-600">
// //             Chargement du trajet...
// //           </div>
// //         )}
// //         <MapContainer
// //           center={center}
// //           zoom={hasBoth ? 8 : 7}
// //           style={{ height: 260, width: "100%" }}
// //           scrollWheelZoom={true}
// //         >
// //           <TileLayer
// //             attribution='&copy; OpenStreetMap contributors'
// //             url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
// //           />
// //           {fromLat !== null && fromLng !== null && !Number.isNaN(fromLat) && !Number.isNaN(fromLng) && (
// //             <Marker position={[fromLat, fromLng]}>
// //               <Popup>
// //                 <strong>Départ</strong>
// //                 <br />
// //                 {from?.name}
// //               </Popup>
// //             </Marker>
// //           )}
// //           {toLat !== null && toLng !== null && !Number.isNaN(toLat) && !Number.isNaN(toLng) && (
// //             <Marker position={[toLat, toLng]}>
// //               <Popup>
// //                 <strong>Arrivée</strong>
// //                 <br />
// //                 {to?.name}
// //               </Popup>
// //             </Marker>
// //           )}
// //           {/* Afficher le trajet routier réel */}
// //           {routeCoordinates.length > 0 && (
// //             <Polyline
// //               positions={routeCoordinates}
// //               color="#10b981"
// //               weight={5}
// //               opacity={0.8}
// //             />
// //           )}
// //           {hasBoth && fromLat !== null && fromLng !== null && toLat !== null && toLng !== null && (
// //             <FitBounds
// //               fromLat={fromLat}
// //               fromLng={fromLng}
// //               toLat={toLat}
// //               toLng={toLng}
// //             />
// //           )}
// //         </MapContainer>
// //       </div>
// //       {hasBoth && (
// //         <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-2 mt-2">
// //           <div className="text-sm text-emerald-800 bg-emerald-50 border border-emerald-200 rounded-lg px-3 py-2">
// //             Distance {routeDistance > 0 ? "routière" : "estimée"} : {distanceKm.toFixed(1)} km
// //           </div>
// //           <div className="text-xs md:text-sm text-gray-600">
// //             <b>Prix recommandé: </b>[Entre 0.2 - 0.3] TND/Km dans la même ville | Au Forfait [entre 10 - 25] TND entre les villes.
// //           </div>
// //         </div>
// //       )}
// //     </div>
// //   );
// // }
// // app/offer/RouteMapLeaflet.tsx
// "use client";
// import { MapContainer, TileLayer, Marker, Popup, Polyline } from "react-leaflet";
// import type { LatLngExpression } from "leaflet";
// import { useEffect, useMemo, useState } from "react";
// import type { Delegation } from "./DelegationMapLeaflet";
// import { useMap } from "react-leaflet";
// import L from "leaflet";
// function FitBounds({ fromLat, fromLng, toLat, toLng }: { fromLat: number; fromLng: number; toLat: number; toLng: number }) {
//   const map = useMap();
//   useEffect(() => {
//     const bounds = L.latLngBounds(
//       [fromLat, fromLng],
//       [toLat, toLng]
//     );
//     map.fitBounds(bounds, { padding: [50, 50] });
//   }, [fromLat, fromLng, toLat, toLng, map]);
//   return null;
// }
// function toRad(deg: number) {
//   return (deg * Math.PI) / 180;
// }
// function haversineKm(a: { lat: number; lng: number }, b: { lat: number; lng: number }) {
//   const R = 6371;
//   const dLat = toRad(b.lat - a.lat);
//   const dLng = toRad(b.lng - a.lng);
//   const lat1 = toRad(a.lat);
//   const lat2 = toRad(b.lat);
//   const sinDLat = Math.sin(dLat / 2);
//   const sinDLng = Math.sin(dLng / 2);
//   const h =
//     sinDLat * sinDLat +
//     Math.cos(lat1) * Math.cos(lat2) * sinDLng * sinDLng;
//   const c = 2 * Math.atan2(Math.sqrt(h), Math.sqrt(1 - h));
//   return R * c;
// }
// // Fonction pour calculer le prix basé sur la distance
// function calculatePrice(distanceKm: number): number {
//   if (distanceKm === 0) return 0;
//   // Calculer le nombre de tranches de 4 km
//   const tranches = Math.ceil(distanceKm / 4);
//   // Prix = 0.5 TND par tranche de 4 km, avec minimum de 1 TND
//   const price = tranches * 0.5;
//   return Math.max(1, price);
// }
// interface Props {
//   delegations: Delegation[];
//   departureName: string;
//   arrivalName: string;
//   onDistanceCalculated?: (distance: number, suggestedPrice: number) => void;
// }
// export default function RouteMapLeaflet({
//   delegations,
//   departureName,
//   arrivalName,
//   onDistanceCalculated,
// }: Props) {
//   const from = delegations.find((d) => d.name === departureName);
//   const to = delegations.find((d) => d.name === arrivalName);
//   const fromLat = from ? parseFloat(from.latitude) : null;
//   const fromLng = from ? parseFloat(from.longitude) : null;
//   const toLat = to ? parseFloat(to.latitude) : null;
//   const toLng = to ? parseFloat(to.longitude) : null;
//   const [routeCoordinates, setRouteCoordinates] = useState<[number, number][]>([]);
//   const [routeDistance, setRouteDistance] = useState<number>(0);
//   const [loadingRoute, setLoadingRoute] = useState(false);
//   const hasBoth =
//     fromLat !== null &&
//     fromLng !== null &&
//     !Number.isNaN(fromLat) &&
//     !Number.isNaN(fromLng) &&
//     toLat !== null &&
//     toLng !== null &&
//     !Number.isNaN(toLat) &&
//     !Number.isNaN(toLng);
//   const center: LatLngExpression = useMemo(() => {
//     if (hasBoth && fromLat !== null && fromLng !== null && toLat !== null && toLng !== null) {
//       return [(fromLat + toLat) / 2, (fromLng + toLng) / 2];
//     }
//     return [35.7, 10.0];
//   }, [hasBoth, fromLat, fromLng, toLat, toLng]);
//   useEffect(() => {
//     if (!hasBoth || fromLat === null || fromLng === null || toLat === null || toLng === null) {
//       setRouteCoordinates([]);
//       setRouteDistance(0);
//       return;
//     }
//     const fetchRoute = async () => {
//       setLoadingRoute(true);
//       try {
//         const response = await fetch(
//           `https://router.project-osrm.org/route/v1/driving/${fromLng},${fromLat};${toLng},${toLat}?overview=full&geometries=geojson`
//         );
//         const data = await response.json();
//         if (data.code === "Ok" && data.routes && data.routes.length > 0) {
//           const route = data.routes[0];
//           const coords: [number, number][] = route.geometry.coordinates.map(
//             (coord: number[]) => [coord[1], coord[0]] as [number, number]
//           );
//           setRouteCoordinates(coords);
//           setRouteDistance(route.distance / 1000);
//         }
//       } catch (error) {
//         console.error("Erreur lors de la récupération du trajet:", error);
//         setRouteCoordinates([[fromLat, fromLng], [toLat, toLng]]);
//         setRouteDistance(haversineKm({ lat: fromLat, lng: fromLng }, { lat: toLat, lng: toLng }));
//       } finally {
//         setLoadingRoute(false);
//       }
//     };
//     fetchRoute();
//   }, [hasBoth, fromLat, fromLng, toLat, toLng]);
//   let distanceKm = routeDistance || 0;
//   if (distanceKm === 0 && hasBoth && fromLat !== null && fromLng !== null && toLat !== null && toLng !== null) {
//     distanceKm = haversineKm(
//       { lat: fromLat, lng: fromLng },
//       { lat: toLat, lng: toLng }
//     );
//   }
//   // Calculer le prix suggéré
//   const suggestedPrice = calculatePrice(distanceKm);
//   // Notifier le parent du changement de distance et prix
//   useEffect(() => {
//     if (distanceKm > 0 && onDistanceCalculated) {
//       onDistanceCalculated(distanceKm, suggestedPrice);
//     }
//   }, [distanceKm, suggestedPrice, onDistanceCalculated]);
//   return (
//     <div className="space-y-2">
//       <div className="rounded-lg border border-gray-200 overflow-hidden relative">
//         {loadingRoute && (
//           <div className="absolute top-2 right-2 z-[1000] bg-white px-3 py-1 rounded-full shadow-md text-xs text-gray-600">
//             Chargement du trajet...
//           </div>
//         )}
//         <MapContainer
//           center={center}
//           zoom={hasBoth ? 8 : 7}
//           style={{ height: 260, width: "100%" }}
//           scrollWheelZoom={true}
//         >
//           <TileLayer
//             attribution='&copy; OpenStreetMap contributors'
//             url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
//           />
//           {fromLat !== null && fromLng !== null && !Number.isNaN(fromLat) && !Number.isNaN(fromLng) && (
//             <Marker position={[fromLat, fromLng]}>
//               <Popup>
//                 <strong>Départ</strong>
//                 <br />
//                 {from?.name}
//               </Popup>
//             </Marker>
//           )}
//           {toLat !== null && toLng !== null && !Number.isNaN(toLat) && !Number.isNaN(toLng) && (
//             <Marker position={[toLat, toLng]}>
//               <Popup>
//                 <strong>Arrivée</strong>
//                 <br />
//                 {to?.name}
//               </Popup>
//             </Marker>
//           )}
//           {routeCoordinates.length > 0 && (
//             <Polyline
//               positions={routeCoordinates}
//               color="#10b981"
//               weight={5}
//               opacity={0.8}
//             />
//           )}
//           {hasBoth && fromLat !== null && fromLng !== null && toLat !== null && toLng !== null && (
//             <FitBounds
//               fromLat={fromLat}
//               fromLng={fromLng}
//               toLat={toLat}
//               toLng={toLng}
//             />
//           )}
//         </MapContainer>
//       </div>
//       {hasBoth && (
//         <div className="flex flex-col gap-2 mt-2">
//           <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-2">
//             <div className="text-sm text-emerald-800 bg-emerald-50 border border-emerald-200 rounded-lg px-3 py-2">
//               Distance {routeDistance > 0 ? "routière" : "estimée"} : <strong>{distanceKm.toFixed(1)} km</strong>
//             </div>
//             <div className="text-sm text-blue-800 bg-blue-50 border border-blue-200 rounded-lg px-3 py-2">
//               Prix suggéré : <strong>{suggestedPrice.toFixed(1)} TND</strong>
//             </div>
//           </div>
//         </div>
//       )}
//     </div>
//   );
// }
// app/offer/RouteMapLeaflet.tsx
__turbopack_context__.s({
    "default": ()=>RouteMapLeaflet
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$leaflet$2f$lib$2f$MapContainer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-leaflet/lib/MapContainer.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$leaflet$2f$lib$2f$TileLayer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-leaflet/lib/TileLayer.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$leaflet$2f$lib$2f$Marker$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-leaflet/lib/Marker.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$leaflet$2f$lib$2f$Popup$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-leaflet/lib/Popup.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$leaflet$2f$lib$2f$Polyline$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-leaflet/lib/Polyline.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$leaflet$2f$lib$2f$hooks$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-leaflet/lib/hooks.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$leaflet$2f$dist$2f$leaflet$2d$src$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/leaflet/dist/leaflet-src.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature();
"use client";
;
;
;
;
function FitBounds(param) {
    let { fromLat, fromLng, toLat, toLng } = param;
    _s();
    const map = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$leaflet$2f$lib$2f$hooks$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMap"])();
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "FitBounds.useEffect": ()=>{
            const bounds = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$leaflet$2f$dist$2f$leaflet$2d$src$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].latLngBounds([
                fromLat,
                fromLng
            ], [
                toLat,
                toLng
            ]);
            map.fitBounds(bounds, {
                padding: [
                    50,
                    50
                ]
            });
        }
    }["FitBounds.useEffect"], [
        fromLat,
        fromLng,
        toLat,
        toLng,
        map
    ]);
    return null;
}
_s(FitBounds, "IoceErwr5KVGS9kN4RQ1bOkYMAg=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$leaflet$2f$lib$2f$hooks$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMap"]
    ];
});
_c = FitBounds;
function toRad(deg) {
    return deg * Math.PI / 180;
}
function haversineKm(a, b) {
    const R = 6371;
    const dLat = toRad(b.lat - a.lat);
    const dLng = toRad(b.lng - a.lng);
    const lat1 = toRad(a.lat);
    const lat2 = toRad(b.lat);
    const sinDLat = Math.sin(dLat / 2);
    const sinDLng = Math.sin(dLng / 2);
    const h = sinDLat * sinDLat + Math.cos(lat1) * Math.cos(lat2) * sinDLng * sinDLng;
    const c = 2 * Math.atan2(Math.sqrt(h), Math.sqrt(1 - h));
    return R * c;
}
function calculatePrice(distanceKm) {
    if (distanceKm === 0) return 0;
    const tranches = Math.ceil(distanceKm / 4);
    const price = tranches * 0.5;
    return Math.max(1, price);
}
function RouteMapLeaflet(param) {
    let { delegations, departureName, arrivalName, onDistanceCalculated, preciseDepartureCoords, preciseArrivalCoords } = param;
    _s1();
    const from = delegations.find((d)=>d.name === departureName);
    const to = delegations.find((d)=>d.name === arrivalName);
    var _preciseDepartureCoords_lat;
    // ✅ Utiliser les coordonnées précises si disponibles, sinon celles de la délégation
    const fromLat = (_preciseDepartureCoords_lat = preciseDepartureCoords === null || preciseDepartureCoords === void 0 ? void 0 : preciseDepartureCoords.lat) !== null && _preciseDepartureCoords_lat !== void 0 ? _preciseDepartureCoords_lat : from ? parseFloat(from.latitude) : null;
    var _preciseDepartureCoords_lng;
    const fromLng = (_preciseDepartureCoords_lng = preciseDepartureCoords === null || preciseDepartureCoords === void 0 ? void 0 : preciseDepartureCoords.lng) !== null && _preciseDepartureCoords_lng !== void 0 ? _preciseDepartureCoords_lng : from ? parseFloat(from.longitude) : null;
    var _preciseArrivalCoords_lat;
    const toLat = (_preciseArrivalCoords_lat = preciseArrivalCoords === null || preciseArrivalCoords === void 0 ? void 0 : preciseArrivalCoords.lat) !== null && _preciseArrivalCoords_lat !== void 0 ? _preciseArrivalCoords_lat : to ? parseFloat(to.latitude) : null;
    var _preciseArrivalCoords_lng;
    const toLng = (_preciseArrivalCoords_lng = preciseArrivalCoords === null || preciseArrivalCoords === void 0 ? void 0 : preciseArrivalCoords.lng) !== null && _preciseArrivalCoords_lng !== void 0 ? _preciseArrivalCoords_lng : to ? parseFloat(to.longitude) : null;
    const [routeCoordinates, setRouteCoordinates] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [routeDistance, setRouteDistance] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(0);
    const [loadingRoute, setLoadingRoute] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const hasBoth = fromLat !== null && fromLng !== null && !Number.isNaN(fromLat) && !Number.isNaN(fromLng) && toLat !== null && toLng !== null && !Number.isNaN(toLat) && !Number.isNaN(toLng);
    const center = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "RouteMapLeaflet.useMemo[center]": ()=>{
            if (hasBoth && fromLat !== null && fromLng !== null && toLat !== null && toLng !== null) {
                return [
                    (fromLat + toLat) / 2,
                    (fromLng + toLng) / 2
                ];
            }
            return [
                35.7,
                10.0
            ];
        }
    }["RouteMapLeaflet.useMemo[center]"], [
        hasBoth,
        fromLat,
        fromLng,
        toLat,
        toLng
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "RouteMapLeaflet.useEffect": ()=>{
            if (!hasBoth || fromLat === null || fromLng === null || toLat === null || toLng === null) {
                setRouteCoordinates([]);
                setRouteDistance(0);
                return;
            }
            const fetchRoute = {
                "RouteMapLeaflet.useEffect.fetchRoute": async ()=>{
                    setLoadingRoute(true);
                    try {
                        const response = await fetch("https://router.project-osrm.org/route/v1/driving/".concat(fromLng, ",").concat(fromLat, ";").concat(toLng, ",").concat(toLat, "?overview=full&geometries=geojson"));
                        const data = await response.json();
                        if (data.code === "Ok" && data.routes && data.routes.length > 0) {
                            const route = data.routes[0];
                            const coords = route.geometry.coordinates.map({
                                "RouteMapLeaflet.useEffect.fetchRoute.coords": (coord)=>[
                                        coord[1],
                                        coord[0]
                                    ]
                            }["RouteMapLeaflet.useEffect.fetchRoute.coords"]);
                            setRouteCoordinates(coords);
                            setRouteDistance(route.distance / 1000);
                        }
                    } catch (error) {
                        console.error("Erreur lors de la récupération du trajet:", error);
                        setRouteCoordinates([
                            [
                                fromLat,
                                fromLng
                            ],
                            [
                                toLat,
                                toLng
                            ]
                        ]);
                        setRouteDistance(haversineKm({
                            lat: fromLat,
                            lng: fromLng
                        }, {
                            lat: toLat,
                            lng: toLng
                        }));
                    } finally{
                        setLoadingRoute(false);
                    }
                }
            }["RouteMapLeaflet.useEffect.fetchRoute"];
            fetchRoute();
        }
    }["RouteMapLeaflet.useEffect"], [
        hasBoth,
        fromLat,
        fromLng,
        toLat,
        toLng
    ]);
    let distanceKm = routeDistance || 0;
    if (distanceKm === 0 && hasBoth && fromLat !== null && fromLng !== null && toLat !== null && toLng !== null) {
        distanceKm = haversineKm({
            lat: fromLat,
            lng: fromLng
        }, {
            lat: toLat,
            lng: toLng
        });
    }
    const suggestedPrice = calculatePrice(distanceKm);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "RouteMapLeaflet.useEffect": ()=>{
            if (distanceKm > 0 && onDistanceCalculated) {
                onDistanceCalculated(distanceKm, suggestedPrice);
            }
        }
    }["RouteMapLeaflet.useEffect"], [
        distanceKm,
        suggestedPrice,
        onDistanceCalculated
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "space-y-2",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "rounded-lg border border-gray-200 overflow-hidden relative",
                children: [
                    loadingRoute && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "absolute top-2 right-2 z-[1000] bg-white px-3 py-1 rounded-full shadow-md text-xs text-gray-600",
                        children: "Chargement du trajet..."
                    }, void 0, false, {
                        fileName: "[project]/app/offer/RouteMapLeaflet.tsx",
                        lineNumber: 797,
                        columnNumber: 11
                    }, this),
                    (preciseDepartureCoords || preciseArrivalCoords) && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "absolute top-2 left-2 z-[1000] bg-blue-500 text-white px-3 py-1 rounded-full shadow-md text-xs font-medium",
                        children: "📍 Position affinée"
                    }, void 0, false, {
                        fileName: "[project]/app/offer/RouteMapLeaflet.tsx",
                        lineNumber: 804,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$leaflet$2f$lib$2f$MapContainer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MapContainer"], {
                        center: center,
                        zoom: hasBoth ? 8 : 7,
                        style: {
                            height: 260,
                            width: "100%"
                        },
                        scrollWheelZoom: true,
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$leaflet$2f$lib$2f$TileLayer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TileLayer"], {
                                attribution: "© OpenStreetMap contributors",
                                url: "https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
                            }, void 0, false, {
                                fileName: "[project]/app/offer/RouteMapLeaflet.tsx",
                                lineNumber: 815,
                                columnNumber: 11
                            }, this),
                            fromLat !== null && fromLng !== null && !Number.isNaN(fromLat) && !Number.isNaN(fromLng) && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$leaflet$2f$lib$2f$Marker$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Marker"], {
                                position: [
                                    fromLat,
                                    fromLng
                                ],
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$leaflet$2f$lib$2f$Popup$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Popup"], {
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "text-sm",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("strong", {
                                                children: "🚗 Départ"
                                            }, void 0, false, {
                                                fileName: "[project]/app/offer/RouteMapLeaflet.tsx",
                                                lineNumber: 824,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("br", {}, void 0, false, {
                                                fileName: "[project]/app/offer/RouteMapLeaflet.tsx",
                                                lineNumber: 825,
                                                columnNumber: 19
                                            }, this),
                                            from === null || from === void 0 ? void 0 : from.name,
                                            preciseDepartureCoords && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "text-blue-600 text-xs mt-1",
                                                children: "📍 Position affinée"
                                            }, void 0, false, {
                                                fileName: "[project]/app/offer/RouteMapLeaflet.tsx",
                                                lineNumber: 828,
                                                columnNumber: 21
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/app/offer/RouteMapLeaflet.tsx",
                                        lineNumber: 823,
                                        columnNumber: 17
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/app/offer/RouteMapLeaflet.tsx",
                                    lineNumber: 822,
                                    columnNumber: 15
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/app/offer/RouteMapLeaflet.tsx",
                                lineNumber: 821,
                                columnNumber: 13
                            }, this),
                            toLat !== null && toLng !== null && !Number.isNaN(toLat) && !Number.isNaN(toLng) && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$leaflet$2f$lib$2f$Marker$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Marker"], {
                                position: [
                                    toLat,
                                    toLng
                                ],
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$leaflet$2f$lib$2f$Popup$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Popup"], {
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "text-sm",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("strong", {
                                                children: "🎯 Arrivée"
                                            }, void 0, false, {
                                                fileName: "[project]/app/offer/RouteMapLeaflet.tsx",
                                                lineNumber: 841,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("br", {}, void 0, false, {
                                                fileName: "[project]/app/offer/RouteMapLeaflet.tsx",
                                                lineNumber: 842,
                                                columnNumber: 19
                                            }, this),
                                            to === null || to === void 0 ? void 0 : to.name,
                                            preciseArrivalCoords && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "text-green-600 text-xs mt-1",
                                                children: "📍 Position affinée"
                                            }, void 0, false, {
                                                fileName: "[project]/app/offer/RouteMapLeaflet.tsx",
                                                lineNumber: 845,
                                                columnNumber: 21
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/app/offer/RouteMapLeaflet.tsx",
                                        lineNumber: 840,
                                        columnNumber: 17
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/app/offer/RouteMapLeaflet.tsx",
                                    lineNumber: 839,
                                    columnNumber: 15
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/app/offer/RouteMapLeaflet.tsx",
                                lineNumber: 838,
                                columnNumber: 13
                            }, this),
                            routeCoordinates.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$leaflet$2f$lib$2f$Polyline$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Polyline"], {
                                positions: routeCoordinates,
                                color: "#10b981",
                                weight: 5,
                                opacity: 0.8
                            }, void 0, false, {
                                fileName: "[project]/app/offer/RouteMapLeaflet.tsx",
                                lineNumber: 855,
                                columnNumber: 13
                            }, this),
                            hasBoth && fromLat !== null && fromLng !== null && toLat !== null && toLng !== null && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(FitBounds, {
                                fromLat: fromLat,
                                fromLng: fromLng,
                                toLat: toLat,
                                toLng: toLng
                            }, void 0, false, {
                                fileName: "[project]/app/offer/RouteMapLeaflet.tsx",
                                lineNumber: 864,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/offer/RouteMapLeaflet.tsx",
                        lineNumber: 809,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/offer/RouteMapLeaflet.tsx",
                lineNumber: 795,
                columnNumber: 7
            }, this),
            hasBoth && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex flex-col gap-2 mt-2",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex flex-col md:flex-row md:items-center md:justify-between gap-2",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "text-sm text-emerald-800 bg-emerald-50 border border-emerald-200 rounded-lg px-3 py-2",
                            children: [
                                "Distance ",
                                routeDistance > 0 ? "routière" : "estimée",
                                " : ",
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("strong", {
                                    children: [
                                        distanceKm.toFixed(1),
                                        " km"
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/app/offer/RouteMapLeaflet.tsx",
                                    lineNumber: 878,
                                    columnNumber: 71
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/offer/RouteMapLeaflet.tsx",
                            lineNumber: 877,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "text-sm text-blue-800 bg-blue-50 border border-blue-200 rounded-lg px-3 py-2",
                            children: [
                                "Prix suggéré : ",
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("strong", {
                                    children: [
                                        suggestedPrice.toFixed(1),
                                        " TND"
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/app/offer/RouteMapLeaflet.tsx",
                                    lineNumber: 881,
                                    columnNumber: 30
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/offer/RouteMapLeaflet.tsx",
                            lineNumber: 880,
                            columnNumber: 13
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/offer/RouteMapLeaflet.tsx",
                    lineNumber: 876,
                    columnNumber: 11
                }, this)
            }, void 0, false, {
                fileName: "[project]/app/offer/RouteMapLeaflet.tsx",
                lineNumber: 875,
                columnNumber: 9
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/offer/RouteMapLeaflet.tsx",
        lineNumber: 794,
        columnNumber: 5
    }, this);
}
_s1(RouteMapLeaflet, "glZEg7F6q73OxKQqWtrIBCzFM1Q=");
_c1 = RouteMapLeaflet;
var _c, _c1;
__turbopack_context__.k.register(_c, "FitBounds");
__turbopack_context__.k.register(_c1, "RouteMapLeaflet");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/app/offer/RouteMapLeaflet.tsx [app-client] (ecmascript, next/dynamic entry)": ((__turbopack_context__) => {

__turbopack_context__.n(__turbopack_context__.i("[project]/app/offer/RouteMapLeaflet.tsx [app-client] (ecmascript)"));
}),
}]);

//# sourceMappingURL=app_offer_RouteMapLeaflet_tsx_a2b0b6ac._.js.map