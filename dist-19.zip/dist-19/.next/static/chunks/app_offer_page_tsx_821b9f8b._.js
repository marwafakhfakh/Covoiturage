(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/app_offer_9e8d4d87._.js",
  "static/chunks/_acbfa20e._.js"
],
    source: "dynamic"
});
