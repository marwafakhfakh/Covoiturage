(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/_579b7e16._.js",
  "static/chunks/node_modules_lucide-react_dist_esm_2e0029f3._.js"
],
    source: "dynamic"
});
