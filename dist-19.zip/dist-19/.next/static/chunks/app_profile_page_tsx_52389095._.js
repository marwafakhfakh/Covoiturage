(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/_948f3c0b._.js",
  "static/chunks/node_modules_lucide-react_dist_esm_d5f2c68b._.js"
],
    source: "dynamic"
});
