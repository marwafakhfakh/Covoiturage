(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([typeof document === "object" ? document.currentScript : undefined, {

"[project]/components/offer/FormSection.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": ()=>FormSection
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
;
function FormSection(param) {
    let { title, children, className = "" } = param;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "space-y-6 ".concat(className),
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                className: "text-2xl font-semibold text-gray-900 border-b pb-2",
                children: title
            }, void 0, false, {
                fileName: "[project]/components/offer/FormSection.tsx",
                lineNumber: 16,
                columnNumber: 7
            }, this),
            children
        ]
    }, void 0, true, {
        fileName: "[project]/components/offer/FormSection.tsx",
        lineNumber: 15,
        columnNumber: 5
    }, this);
}
_c = FormSection;
var _c;
__turbopack_context__.k.register(_c, "FormSection");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/components/common/SuccessMessage.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": ()=>SuccessMessage
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
;
function SuccessMessage(param) {
    let { icon = "✅", title = "Success!", description = "Your action has been completed successfully.", actionText = "Continue", onAction, className = "" } = param;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "text-center py-12 ".concat(className),
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "w-20 h-20 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-6",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                    className: "text-3xl",
                    children: icon
                }, void 0, false, {
                    fileName: "[project]/components/common/SuccessMessage.tsx",
                    lineNumber: 21,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/components/common/SuccessMessage.tsx",
                lineNumber: 20,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                className: "text-2xl font-bold text-gray-900 mb-4",
                children: title
            }, void 0, false, {
                fileName: "[project]/components/common/SuccessMessage.tsx",
                lineNumber: 23,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "text-gray-600 mb-6",
                children: description
            }, void 0, false, {
                fileName: "[project]/components/common/SuccessMessage.tsx",
                lineNumber: 24,
                columnNumber: 7
            }, this),
            onAction && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                onClick: onAction,
                className: "px-6 py-3 bg-black text-white rounded-lg hover:bg-gray-800 transition font-semibold",
                children: actionText
            }, void 0, false, {
                fileName: "[project]/components/common/SuccessMessage.tsx",
                lineNumber: 26,
                columnNumber: 9
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/components/common/SuccessMessage.tsx",
        lineNumber: 19,
        columnNumber: 5
    }, this);
}
_c = SuccessMessage;
var _c;
__turbopack_context__.k.register(_c, "SuccessMessage");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/app/offer/page.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
// "use client";
// import { useState, useEffect } from "react";
// import { useSelector } from "react-redux";
// import FormSection from "../../components/offer/FormSection";
// import SuccessMessage from "../../components/common/SuccessMessage";
// import api from "../../api/api";
// import type { RootState } from "../../store";
// import dynamic from "next/dynamic";
// const RouteMapLeaflet = dynamic(() => import("./RouteMapLeaflet"), {
//   ssr: false,
// });
// const SingleLocationMap = dynamic(() => import("./SingleLocationMapProps"), {
//   ssr: false,
// });
// import type { Delegation } from "./DelegationMapLeaflet";
// type Car = {
//   id: number;
//   model_details?: {
//     id: number;
//     name: string;
//     brand: {
//       id: number;
//       name: string;
//     };
//   } | null;
//   type: string;
//   color: string;
//   color_details?: { id: number; name: string; code: string } | null;
//   serial_number: string;
//   nb_place: number;
//   engine_type: string;
//   grey_card: string;
//   year: number | null;
//   image: string | null;
//   owner: number;
// };
// type Service = {
//   id: number;
//   name: string;
//   description: string;
//   active: boolean;
//   logo: string | null;
// };
// type OfferForm = {
//   departure_place: string;
//   arrival_place: string;
//   departure_date: string;
//   price: string;
//   nb_places_disponible: string;
//   selected_car_id: string;
//   services: number[];
//   description: string;
// };
// export default function OfferRidePage() {
//   const user = useSelector((state: RootState) => state.user.user);
//   const getDefaultDateTime = () => {
//     const now = new Date();
//     now.setHours(now.getHours() + 2);
//     return now.toISOString().slice(0, 16);
//   };
//   const [form, setForm] = useState<OfferForm>({
//     departure_place: "",
//     arrival_place: "",
//     departure_date: getDefaultDateTime(),
//     price: "",
//     nb_places_disponible: "",
//     selected_car_id: "",
//     services: [],
//     description: "",
//   });
//   const [success, setSuccess] = useState(false);
//   const [error, setError] = useState<string | null>(null);
//   const [ownedCars, setOwnedCars] = useState<Car[]>([]);
//   const [services, setServices] = useState<Service[]>([]);
//   const [delegations, setDelegations] = useState<Delegation[]>([]);
//   const [loading, setLoading] = useState(true);
//   const [priceManuallyEdited, setPriceManuallyEdited] = useState(false);
//   const [lastSuggestedPrice, setLastSuggestedPrice] = useState<string | null>(null);
//   // États pour les coordonnées précises
//   const [preciseDepartureCoords, setPreciseDepartureCoords] = useState<{lat: number, lng: number} | null>(null);
//   const [preciseArrivalCoords, setPreciseArrivalCoords] = useState<{lat: number, lng: number} | null>(null);
//   // Réinitialiser les coordonnées précises quand l'utilisateur change de ville
//   useEffect(() => {
//     setPreciseDepartureCoords(null);
//   }, [form.departure_place]);
//   useEffect(() => {
//     setPreciseArrivalCoords(null);
//   }, [form.arrival_place]);
//   useEffect(() => {
//     async function fetchData() {
//       setLoading(true);
//       try {
//         const [carsRes, servicesRes, delegationsRes] = await Promise.all([
//           api.get("/api/cars/"),
//           api.get("/api/services/"),
//           api.get("/api/delegations/"),
//         ]);
//         const cars = Array.isArray(carsRes.data)
//           ? carsRes.data
//           : carsRes.data.results || [];
//         const delegs = Array.isArray(delegationsRes.data)
//           ? delegationsRes.data
//           : delegationsRes.data.results || [];
//         setOwnedCars(cars);
//         setServices(servicesRes.data.results || servicesRes.data || []);
//         setDelegations(delegs);
//       } catch (error) {
//         console.error("Error fetching data for offer page:", error);
//         setError("Unable to load data. Please try again later.");
//       } finally {
//         setLoading(false);
//       }
//     }
//     if (user) {
//       fetchData();
//     }
//   }, [user]);
//   const handleChange = (
//     e: React.ChangeEvent<
//       HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement
//     >
//   ) => {
//     const { name, value } = e.target;
//     if (name === "price") {
//       setPriceManuallyEdited(true);
//     }
//     setForm((prev) => ({ ...prev, [name]: value }));
//   };
//   const handleServiceChange = (serviceId: number) => {
//     setForm((prev) => ({
//       ...prev,
//       services: prev.services.includes(serviceId)
//         ? prev.services.filter((s) => s !== serviceId)
//         : [...prev.services, serviceId],
//     }));
//   };
//   const handleDistanceCalculated = (distance: number, suggestedPrice: number) => {
//     if (priceManuallyEdited) return;
//     const newPrice = suggestedPrice.toFixed(1);
//     if (lastSuggestedPrice === newPrice) return;
//     setLastSuggestedPrice(newPrice);
//     setForm(prev => ({ ...prev, price: newPrice }));
//   };
//   useEffect(() => {
//     setPriceManuallyEdited(false);
//   }, [form.departure_place, form.arrival_place]);
//   const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
//     e.preventDefault();
//     setError(null);
//     const selectedCar = ownedCars.find(
//       (car) => car.id === parseInt(form.selected_car_id)
//     );
//     try {
//       const postData = {
//         departure_place: form.departure_place,
//         arrival_place: form.arrival_place,
//         departure_date: form.departure_date,
//         price: form.price,
//         nb_places_disponible: form.nb_places_disponible,
//         description: form.description,
//         user: user?.id,
//         car: selectedCar?.id,
//         status: "open",
//         services_ids: form.services,
//         // Ajouter les coordonnées précises si elles existent
//         departure_coords: preciseDepartureCoords,
//         arrival_coords: preciseArrivalCoords,
//       };
//       console.log('📤 Données envoyées:', postData);
//       await api.post("/api/posts/", postData);
//       setSuccess(true);
//       // Réinitialiser le formulaire après succès
//       setForm({
//         departure_place: "",
//         arrival_place: "",
//         departure_date: getDefaultDateTime(),
//         price: "",
//         nb_places_disponible: "",
//         selected_car_id: "",
//         services: [],
//         description: "",
//       });
//       setPreciseDepartureCoords(null);
//       setPreciseArrivalCoords(null);
//     } catch (err) {
//       console.error('❌ Error publishing ride:', err);
//       if (err && typeof err === 'object' && 'response' in err) {
//         const error = err as { response?: { data?: { detail?: string; [key: string]: unknown } } };
//         const detail = error.response?.data?.detail;
//         const allErrors = error.response?.data 
//           ? Object.values(error.response.data).flat().join(" ")
//           : "";
//         setError(detail || allErrors || "An error occurred while publishing your ride.");
//       } else {
//         setError("An error occurred while publishing your ride.");
//       }
//     }
//   };
//   const selectedCar = ownedCars.find(
//     (car) => car.id === parseInt(form.selected_car_id)
//   );
//   return (
//     <main className="min-h-screen bg-gray-50 py-8">
//       <div className="max-w-4xl mx-auto px-4">
//         <div className="bg-white rounded-2xl shadow-xl p-8">
//           <h1 className="text-4xl font-bold mb-8 text-center text-gray-900">
//             Partager votre trajet
//           </h1>
//           {error && (
//             <div className="mb-4 p-4 bg-red-100 text-red-700 rounded-lg border border-red-200">
//               {error}
//             </div>
//           )}
//           {success ? (
//             <SuccessMessage
//               title="Ride Offered Successfully!"
//               description="Your ride has been posted and is now available for bookings."
//               actionText="Offer Another Ride"
//               onAction={() => setSuccess(false)}
//             />
//           ) : loading ? (
//             <div className="text-center text-gray-500 py-12">Loading...</div>
//           ) : (
//             <form onSubmit={handleSubmit} className="space-y-8">
//               {/* Route Section */}
//               <FormSection title="Route Information">
//                 {/* Carte avec le trajet complet */}
//                 <RouteMapLeaflet
//                   delegations={delegations}
//                   departureName={form.departure_place}
//                   arrivalName={form.arrival_place}
//                   onDistanceCalculated={handleDistanceCalculated}
//                 />
//                 {/* Sélecteurs de lieu */}
//                 <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-6">
//                   <div className="space-y-2">
//                     <label className="block text-sm font-semibold text-gray-700">
//                       Departure Location
//                     </label>
//                     <select
//                       name="departure_place"
//                       value={form.departure_place}
//                       className="w-full p-4 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent transition bg-white"
//                       onChange={handleChange}
//                       required
//                     >
//                       <option value="">Sélectionner le départ</option>
//                       {delegations.map((d) => (
//                         <option key={d.id} value={d.name}>
//                           {d.name}
//                         </option>
//                       ))}
//                     </select>
//                   </div>
//                   <div className="space-y-2">
//                     <label className="block text-sm font-semibold text-gray-700">
//                       Arrival Location
//                     </label>
//                     <select
//                       name="arrival_place"
//                       value={form.arrival_place}
//                       className="w-full p-4 border border-gray-300 rounded-xl focus:ring-2 focus:ring-green-500 focus:border-transparent transition bg-white"
//                       onChange={handleChange}
//                       required
//                     >
//                       <option value="">Sélectionner l arrivee</option>
//                       {delegations.map((d) => (
//                         <option key={d.id} value={d.name}>
//                           {d.name}
//                         </option>
//                       ))}
//                     </select>
//                   </div>
//                 </div>
//                 {/* Cartes individuelles pour chaque lieu */}
//                 <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-6">
//                   <SingleLocationMap
//                     delegations={delegations}
//                     selectedLocation={form.departure_place}
//                     label="🏁 Zoom sur le lieu de départ"
//                     markerColor="departure"
//                     onPreciseLocationSelect={(lat, lng) => {
//                       setPreciseDepartureCoords({ lat, lng });
//                       console.log('Position précise départ:', { lat, lng });
//                     }}
//                   />
//                   <SingleLocationMap
//                     delegations={delegations}
//                     selectedLocation={form.arrival_place}
//                     label="🎯 Zoom sur le lieu d'arrivée"
//                     markerColor="arrival"
//                     onPreciseLocationSelect={(lat, lng) => {
//                       setPreciseArrivalCoords({ lat, lng });
//                       console.log('Position précise arrivée:', { lat, lng });
//                     }}
//                   />
//                 </div>
//               </FormSection>
//               {/* Trip Details Section */}
//               <FormSection title="Planning et Disponibilité">
//                 <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
//                   <div className="space-y-2">
//                     <label className="block text-sm font-semibold text-gray-700">
//                       Date & Time
//                     </label>
//                     <input
//                       name="departure_date"
//                       type="datetime-local"
//                       value={form.departure_date}
//                       className="w-full p-4 border border-gray-300 rounded-xl focus:ring-2 focus:ring-gray-500 focus:border-transparent transition bg-white"
//                       onChange={handleChange}
//                       required
//                     />
//                   </div>
//                   <div className="space-y-2">
//                     <label className="block text-sm font-semibold text-gray-700">
//                       Prix du siège (TND)
//                       {!priceManuallyEdited && form.price && (
//                         <span className="ml-2 text-xs text-blue-600">✨ Auto-calculé</span>
//                       )}
//                     </label>
//                     <input
//                       name="price"
//                       placeholder="Prix calculé automatiquement"
//                       type="number"
//                       min="1"
//                       step="0.5"
//                       value={form.price}
//                       className="w-full p-4 border border-gray-300 rounded-xl focus:ring-2 focus:ring-gray-500 focus:border-transparent transition bg-white"
//                       onChange={handleChange}
//                       required
//                     />
//                     {priceManuallyEdited && (
//                       <p className="text-xs text-gray-500 mt-1">
//                         Prix modifié manuellement
//                       </p>
//                     )}
//                   </div>
//                   <div className="space-y-2">
//                     <label className="block text-sm font-semibold text-gray-700">
//                       Sièges disponibles
//                     </label>
//                     <select
//                       name="nb_places_disponible"
//                       value={form.nb_places_disponible}
//                       className="w-full p-4 border border-gray-300 rounded-xl focus:ring-2 focus:ring-gray-500 focus:border-transparent transition bg-white"
//                       onChange={handleChange}
//                       required
//                     >
//                       <option value="">Choisir les sièges</option>
//                       {selectedCar &&
//                         Array.from(
//                           { length: selectedCar.nb_place - 1 },
//                           (_, i) => i + 1
//                         ).map((num) => (
//                           <option key={num} value={num.toString()}>
//                             {num} seat{num > 1 ? "s" : ""}
//                           </option>
//                         ))}
//                       {!selectedCar && (
//                         <>
//                           <option value="1">1 Place</option>
//                           <option value="2">2 Places</option>
//                           <option value="3">3 Places</option>
//                           <option value="4">4 Places</option>
//                         </>
//                       )}
//                     </select>
//                   </div>
//                 </div>
//               </FormSection>
//               {/* Car Selection Section */}
//               <FormSection title="Vehicle Information">
//                 <div className="space-y-4">
//                   <div className="space-y-2">
//                     <label className="block text-sm font-semibold text-gray-700">
//                       Choisir votre voiture
//                     </label>
//                     <select
//                       name="selected_car_id"
//                       value={form.selected_car_id}
//                       className="w-full p-4 border border-gray-300 rounded-xl focus:ring-2 focus:ring-gray-500 focus:border-transparent transition bg-white"
//                       onChange={handleChange}
//                       required
//                     >
//                       <option value="">
//                         Choisir une voiture depuis votre collection
//                       </option>
//                       {ownedCars.map((car) => (
//                         <option key={car.id} value={car.id.toString()}>
//                           {car.model_details?.brand.name || "Voiture"} {car.model_details?.name} ({car.year || "-"}){" - "}
//                           {car.color_details?.name} - {car.serial_number}
//                         </option>
//                       ))}
//                     </select>
//                   </div>
//                   {ownedCars.length === 0 && (
//                     <div className="bg-gray-50 rounded-xl p-6 border border-gray-200 text-center">
//                       <div className="text-gray-400 text-4xl mb-3">🚗</div>
//                       <h3 className="font-semibold text-gray-900 mb-2">
//                         Aucune voiture disponible
//                       </h3>
//                       <p className="text-gray-600 mb-4">
//                         Vous devez ajouter un véhicule à votre compte avant de proposer des trajets.
//                       </p>
//                       <button
//                         type="button"
//                         className="px-4 py-2 bg-black text-white rounded-lg hover:bg-gray-800 transition font-medium"
//                         onClick={() => (window.location.href = "/profile")}
//                       >
//                         Ajouter un véhicule
//                       </button>
//                     </div>
//                   )}
//                 </div>
//               </FormSection>
//               {/* Services Section */}
//               <FormSection title="Services & accessoires">
//                 <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
//                   {services.map((service) => (
//                     <label
//                       key={service.id}
//                       className="flex items-center space-x-3 cursor-pointer"
//                     >
//                       <input
//                         type="checkbox"
//                         checked={form.services.includes(service.id)}
//                         onChange={() => handleServiceChange(service.id)}
//                         className="w-5 h-5 text-gray-600 border-gray-300 rounded focus:ring-gray-500"
//                       />
//                       <span className="text-sm font-medium text-gray-700">
//                         {service.name}
//                       </span>
//                     </label>
//                   ))}
//                 </div>
//               </FormSection>
//               {/* Description Section */}
//               <FormSection title="Information supplémentaire">
//                 <div className="space-y-2">
//                   <label className="block text-sm font-semibold text-gray-700">
//                     Description (Optional)
//                   </label>
//                   <textarea
//                     name="description"
//                     value={form.description}
//                     placeholder="Mettre des informations additionnelles pour votre trajets, preferences et details."
//                     rows={4}
//                     className="w-full p-4 border border-gray-300 rounded-xl focus:ring-2 focus:ring-gray-500 focus:border-transparent transition bg-white resize-none"
//                     onChange={handleChange}
//                   />
//                 </div>
//               </FormSection>
//               <button
//                 type="submit"
//                 className="w-full py-4 bg-black text-white rounded-xl font-semibold text-lg hover:bg-gray-800 transition transform hover:scale-105 shadow-lg"
//                 disabled={ownedCars.length === 0}
//               >
//                 Publier votre trajet
//               </button>
//             </form>
//           )}
//         </div>
//       </div>
//     </main>
//   );
// }
__turbopack_context__.s({
    "default": ()=>OfferRidePage
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$redux$2f$dist$2f$react$2d$redux$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-redux/dist/react-redux.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$offer$2f$FormSection$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/offer/FormSection.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$common$2f$SuccessMessage$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/common/SuccessMessage.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$api$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/api/api.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$shared$2f$lib$2f$app$2d$dynamic$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/shared/lib/app-dynamic.js [app-client] (ecmascript)");
;
;
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
const RouteMapLeaflet = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$shared$2f$lib$2f$app$2d$dynamic$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(()=>__turbopack_context__.r("[project]/app/offer/RouteMapLeaflet.tsx [app-client] (ecmascript, next/dynamic entry, async loader)")(__turbopack_context__.i), {
    loadableGenerated: {
        modules: [
            "[project]/app/offer/RouteMapLeaflet.tsx [app-client] (ecmascript, next/dynamic entry)"
        ]
    },
    ssr: false
});
_c = RouteMapLeaflet;
const SingleLocationMap = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$shared$2f$lib$2f$app$2d$dynamic$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(()=>__turbopack_context__.r("[project]/app/offer/SingleLocationMapProps.tsx [app-client] (ecmascript, next/dynamic entry, async loader)")(__turbopack_context__.i), {
    loadableGenerated: {
        modules: [
            "[project]/app/offer/SingleLocationMapProps.tsx [app-client] (ecmascript, next/dynamic entry)"
        ]
    },
    ssr: false
});
_c1 = SingleLocationMap;
function OfferRidePage() {
    _s();
    const user = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$redux$2f$dist$2f$react$2d$redux$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSelector"])({
        "OfferRidePage.useSelector[user]": (state)=>state.user.user
    }["OfferRidePage.useSelector[user]"]);
    const getDefaultDateTime = ()=>{
        const now = new Date();
        now.setHours(now.getHours() + 2);
        return now.toISOString().slice(0, 16);
    };
    const [form, setForm] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({
        departure_place: "",
        arrival_place: "",
        departure_date: getDefaultDateTime(),
        price: "",
        nb_places_disponible: "",
        selected_car_id: "",
        services: [],
        description: ""
    });
    const [success, setSuccess] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [error, setError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [ownedCars, setOwnedCars] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [services, setServices] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [delegations, setDelegations] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [loading, setLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(true);
    const [priceManuallyEdited, setPriceManuallyEdited] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [lastSuggestedPrice, setLastSuggestedPrice] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    // États pour les coordonnées précises
    const [preciseDepartureCoords, setPreciseDepartureCoords] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [preciseArrivalCoords, setPreciseArrivalCoords] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    // Réinitialiser les coordonnées précises quand l'utilisateur change de ville
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "OfferRidePage.useEffect": ()=>{
            setPreciseDepartureCoords(null);
        }
    }["OfferRidePage.useEffect"], [
        form.departure_place
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "OfferRidePage.useEffect": ()=>{
            setPreciseArrivalCoords(null);
        }
    }["OfferRidePage.useEffect"], [
        form.arrival_place
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "OfferRidePage.useEffect": ()=>{
            async function fetchData() {
                setLoading(true);
                try {
                    const [carsRes, servicesRes, delegationsRes] = await Promise.all([
                        __TURBOPACK__imported__module__$5b$project$5d2f$api$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].get("/api/cars/"),
                        __TURBOPACK__imported__module__$5b$project$5d2f$api$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].get("/api/services/"),
                        __TURBOPACK__imported__module__$5b$project$5d2f$api$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].get("/api/delegations/")
                    ]);
                    const cars = Array.isArray(carsRes.data) ? carsRes.data : carsRes.data.results || [];
                    const delegs = Array.isArray(delegationsRes.data) ? delegationsRes.data : delegationsRes.data.results || [];
                    setOwnedCars(cars);
                    setServices(servicesRes.data.results || servicesRes.data || []);
                    setDelegations(delegs);
                } catch (error) {
                    console.error("Error fetching data for offer page:", error);
                    setError("Unable to load data. Please try again later.");
                } finally{
                    setLoading(false);
                }
            }
            if (user) {
                fetchData();
            }
        }
    }["OfferRidePage.useEffect"], [
        user
    ]);
    const handleChange = (e)=>{
        const { name, value } = e.target;
        if (name === "price") {
            setPriceManuallyEdited(true);
        }
        setForm((prev)=>({
                ...prev,
                [name]: value
            }));
    };
    const handleServiceChange = (serviceId)=>{
        setForm((prev)=>({
                ...prev,
                services: prev.services.includes(serviceId) ? prev.services.filter((s)=>s !== serviceId) : [
                    ...prev.services,
                    serviceId
                ]
            }));
    };
    const handleDistanceCalculated = (distance, suggestedPrice)=>{
        if (priceManuallyEdited) return;
        const newPrice = suggestedPrice.toFixed(1);
        if (lastSuggestedPrice === newPrice) return;
        setLastSuggestedPrice(newPrice);
        setForm((prev)=>({
                ...prev,
                price: newPrice
            }));
    };
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "OfferRidePage.useEffect": ()=>{
            setPriceManuallyEdited(false);
        }
    }["OfferRidePage.useEffect"], [
        form.departure_place,
        form.arrival_place
    ]);
    // const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    //   e.preventDefault();
    //   setError(null);
    //   const selectedCar = ownedCars.find(
    //     (car) => car.id === parseInt(form.selected_car_id)
    //   );
    //   try {
    //     const postData = {
    //       departure_place: form.departure_place,
    //       arrival_place: form.arrival_place,
    //       departure_date: form.departure_date,
    //       price: form.price,
    //       nb_places_disponible: form.nb_places_disponible,
    //       description: form.description,
    //       user: user?.id,
    //       car: selectedCar?.id,
    //       status: "open",
    //       services_ids: form.services,
    //       // Ajouter les coordonnées précises si elles existent
    //       departure_coords: preciseDepartureCoords,
    //       arrival_coords: preciseArrivalCoords,
    //     };
    //     console.log('📤 Données envoyées:', postData);
    //     await api.post("/api/posts/", postData);
    //     setSuccess(true);
    //     // Réinitialiser le formulaire après succès
    //     setForm({
    //       departure_place: "",
    //       arrival_place: "",
    //       departure_date: getDefaultDateTime(),
    //       price: "",
    //       nb_places_disponible: "",
    //       selected_car_id: "",
    //       services: [],
    //       description: "",
    //     });
    //     setPreciseDepartureCoords(null);
    //     setPreciseArrivalCoords(null);
    //   } catch (err) {
    //     console.error('❌ Error publishing ride:', err);
    //     if (err && typeof err === 'object' && 'response' in err) {
    //       const error = err as { response?: { data?: { detail?: string; [key: string]: unknown } } };
    //       const detail = error.response?.data?.detail;
    //       const allErrors = error.response?.data 
    //         ? Object.values(error.response.data).flat().join(" ")
    //         : "";
    //       setError(detail || allErrors || "An error occurred while publishing your ride.");
    //     } else {
    //       setError("An error occurred while publishing your ride.");
    //     }
    //   }
    // };
    const handleSubmit = async (e)=>{
        e.preventDefault();
        setError(null);
        const selectedCar = ownedCars.find((car)=>car.id === parseInt(form.selected_car_id));
        try {
            var _preciseDepartureCoords_lat, _preciseDepartureCoords_lng, _preciseArrivalCoords_lat, _preciseArrivalCoords_lng;
            const postData = {
                departure_place: form.departure_place,
                arrival_place: form.arrival_place,
                departure_date: form.departure_date,
                price: form.price,
                nb_places_disponible: form.nb_places_disponible,
                description: form.description,
                user: user === null || user === void 0 ? void 0 : user.id,
                car: selectedCar === null || selectedCar === void 0 ? void 0 : selectedCar.id,
                status: "open",
                services_ids: form.services,
                // ✅ Envoi des coordonnées séparées (lat et lng)
                departure_latitude: (_preciseDepartureCoords_lat = preciseDepartureCoords === null || preciseDepartureCoords === void 0 ? void 0 : preciseDepartureCoords.lat) !== null && _preciseDepartureCoords_lat !== void 0 ? _preciseDepartureCoords_lat : null,
                departure_longitude: (_preciseDepartureCoords_lng = preciseDepartureCoords === null || preciseDepartureCoords === void 0 ? void 0 : preciseDepartureCoords.lng) !== null && _preciseDepartureCoords_lng !== void 0 ? _preciseDepartureCoords_lng : null,
                arrival_latitude: (_preciseArrivalCoords_lat = preciseArrivalCoords === null || preciseArrivalCoords === void 0 ? void 0 : preciseArrivalCoords.lat) !== null && _preciseArrivalCoords_lat !== void 0 ? _preciseArrivalCoords_lat : null,
                arrival_longitude: (_preciseArrivalCoords_lng = preciseArrivalCoords === null || preciseArrivalCoords === void 0 ? void 0 : preciseArrivalCoords.lng) !== null && _preciseArrivalCoords_lng !== void 0 ? _preciseArrivalCoords_lng : null
            };
            console.log('📤 Données envoyées:', postData);
            console.log('📍 Départ:', {
                lat: postData.departure_latitude,
                lng: postData.departure_longitude
            });
            console.log('📍 Arrivée:', {
                lat: postData.arrival_latitude,
                lng: postData.arrival_longitude
            });
            // lat_dep: preciseDepartureCoords?.lat ?? null,
            //   lng_dep: preciseDepartureCoords?.lng ?? null,
            //   lat_arr: preciseArrivalCoords?.lat ?? null,
            //   lng_arr: preciseArrivalCoords?.lng ?? null,
            // };
            // console.log('📤 Données envoyées:', postData);
            // console.log('📍 Départ:', { 
            //   lat: postData.lat_dep, 
            //   lng: postData.lng_dep 
            // });
            // console.log('📍 Arrivée:', { 
            //   lat: postData.lat_arr, 
            //   lng: postData.lng_arr 
            // });
            await __TURBOPACK__imported__module__$5b$project$5d2f$api$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].post("/api/posts/", postData);
            setSuccess(true);
            // Réinitialiser le formulaire après succès
            setForm({
                departure_place: "",
                arrival_place: "",
                departure_date: getDefaultDateTime(),
                price: "",
                nb_places_disponible: "",
                selected_car_id: "",
                services: [],
                description: ""
            });
            setPreciseDepartureCoords(null);
            setPreciseArrivalCoords(null);
        } catch (err) {
            console.error('❌ Error publishing ride:', err);
            if (err && typeof err === 'object' && 'response' in err) {
                var _error_response_data, _error_response, _error_response1;
                const error = err;
                const detail = (_error_response = error.response) === null || _error_response === void 0 ? void 0 : (_error_response_data = _error_response.data) === null || _error_response_data === void 0 ? void 0 : _error_response_data.detail;
                const allErrors = ((_error_response1 = error.response) === null || _error_response1 === void 0 ? void 0 : _error_response1.data) ? Object.values(error.response.data).flat().join(" ") : "";
                setError(detail || allErrors || "An error occurred while publishing your ride.");
            } else {
                setError("An error occurred while publishing your ride.");
            }
        }
    };
    const selectedCar = ownedCars.find((car)=>car.id === parseInt(form.selected_car_id));
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("main", {
        className: "min-h-screen bg-gray-50 py-8",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "max-w-4xl mx-auto px-4",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "bg-white rounded-2xl shadow-xl p-8",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                        className: "text-4xl font-bold mb-8 text-center text-gray-900",
                        children: "Partager votre trajet"
                    }, void 0, false, {
                        fileName: "[project]/app/offer/page.tsx",
                        lineNumber: 842,
                        columnNumber: 11
                    }, this),
                    error && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "mb-4 p-4 bg-red-100 text-red-700 rounded-lg border border-red-200",
                        children: error
                    }, void 0, false, {
                        fileName: "[project]/app/offer/page.tsx",
                        lineNumber: 847,
                        columnNumber: 13
                    }, this),
                    success ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$common$2f$SuccessMessage$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        title: "Ride Offered Successfully!",
                        description: "Your ride has been posted and is now available for bookings.",
                        actionText: "Offer Another Ride",
                        onAction: ()=>setSuccess(false)
                    }, void 0, false, {
                        fileName: "[project]/app/offer/page.tsx",
                        lineNumber: 852,
                        columnNumber: 13
                    }, this) : loading ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "text-center text-gray-500 py-12",
                        children: "Loading..."
                    }, void 0, false, {
                        fileName: "[project]/app/offer/page.tsx",
                        lineNumber: 859,
                        columnNumber: 13
                    }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("form", {
                        onSubmit: handleSubmit,
                        className: "space-y-8",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$offer$2f$FormSection$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                title: "Route Information",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "grid grid-cols-1 md:grid-cols-2 gap-6 mt-6",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "space-y-2",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                        className: "block text-sm font-semibold text-gray-700",
                                                        children: "Departure Location"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/offer/page.tsx",
                                                        lineNumber: 869,
                                                        columnNumber: 21
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                                                        name: "departure_place",
                                                        value: form.departure_place,
                                                        className: "w-full p-4 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent transition bg-white",
                                                        onChange: handleChange,
                                                        required: true,
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                                value: "",
                                                                children: "Sélectionner le départ"
                                                            }, void 0, false, {
                                                                fileName: "[project]/app/offer/page.tsx",
                                                                lineNumber: 879,
                                                                columnNumber: 23
                                                            }, this),
                                                            delegations.map((d)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                                    value: d.name,
                                                                    children: d.name
                                                                }, d.id, false, {
                                                                    fileName: "[project]/app/offer/page.tsx",
                                                                    lineNumber: 881,
                                                                    columnNumber: 25
                                                                }, this))
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/app/offer/page.tsx",
                                                        lineNumber: 872,
                                                        columnNumber: 21
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/app/offer/page.tsx",
                                                lineNumber: 868,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "space-y-2",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                        className: "block text-sm font-semibold text-gray-700",
                                                        children: "Arrival Location"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/offer/page.tsx",
                                                        lineNumber: 889,
                                                        columnNumber: 21
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                                                        name: "arrival_place",
                                                        value: form.arrival_place,
                                                        className: "w-full p-4 border border-gray-300 rounded-xl focus:ring-2 focus:ring-green-500 focus:border-transparent transition bg-white",
                                                        onChange: handleChange,
                                                        required: true,
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                                value: "",
                                                                children: "Sélectionner l arrivee"
                                                            }, void 0, false, {
                                                                fileName: "[project]/app/offer/page.tsx",
                                                                lineNumber: 899,
                                                                columnNumber: 23
                                                            }, this),
                                                            delegations.map((d)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                                    value: d.name,
                                                                    children: d.name
                                                                }, d.id, false, {
                                                                    fileName: "[project]/app/offer/page.tsx",
                                                                    lineNumber: 901,
                                                                    columnNumber: 25
                                                                }, this))
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/app/offer/page.tsx",
                                                        lineNumber: 892,
                                                        columnNumber: 21
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/app/offer/page.tsx",
                                                lineNumber: 888,
                                                columnNumber: 19
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/app/offer/page.tsx",
                                        lineNumber: 867,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "grid grid-cols-1 md:grid-cols-2 gap-6 mt-6",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(SingleLocationMap, {
                                                delegations: delegations,
                                                selectedLocation: form.departure_place,
                                                label: "🚗 Zoom sur le lieu de départ",
                                                markerColor: "departure",
                                                onPreciseLocationSelect: (lat, lng)=>{
                                                    setPreciseDepartureCoords({
                                                        lat,
                                                        lng
                                                    });
                                                    console.log('Position précise départ:', {
                                                        lat,
                                                        lng
                                                    });
                                                }
                                            }, void 0, false, {
                                                fileName: "[project]/app/offer/page.tsx",
                                                lineNumber: 911,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(SingleLocationMap, {
                                                delegations: delegations,
                                                selectedLocation: form.arrival_place,
                                                label: "🎯 Zoom sur le lieu d'arrivée",
                                                markerColor: "arrival",
                                                onPreciseLocationSelect: (lat, lng)=>{
                                                    setPreciseArrivalCoords({
                                                        lat,
                                                        lng
                                                    });
                                                    console.log('Position précise arrivée:', {
                                                        lat,
                                                        lng
                                                    });
                                                }
                                            }, void 0, false, {
                                                fileName: "[project]/app/offer/page.tsx",
                                                lineNumber: 922,
                                                columnNumber: 19
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/app/offer/page.tsx",
                                        lineNumber: 910,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(RouteMapLeaflet, {
                                        delegations: delegations,
                                        departureName: form.departure_place,
                                        arrivalName: form.arrival_place,
                                        onDistanceCalculated: handleDistanceCalculated,
                                        preciseDepartureCoords: preciseDepartureCoords,
                                        preciseArrivalCoords: preciseArrivalCoords
                                    }, void 0, false, {
                                        fileName: "[project]/app/offer/page.tsx",
                                        lineNumber: 933,
                                        columnNumber: 17
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/offer/page.tsx",
                                lineNumber: 863,
                                columnNumber: 15
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$offer$2f$FormSection$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                title: "Planning et Disponibilité",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "grid grid-cols-1 md:grid-cols-3 gap-6",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "space-y-2",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                    className: "block text-sm font-semibold text-gray-700",
                                                    children: "Date & Time"
                                                }, void 0, false, {
                                                    fileName: "[project]/app/offer/page.tsx",
                                                    lineNumber: 946,
                                                    columnNumber: 21
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                    name: "departure_date",
                                                    type: "datetime-local",
                                                    value: form.departure_date,
                                                    className: "w-full p-4 border border-gray-300 rounded-xl focus:ring-2 focus:ring-gray-500 focus:border-transparent transition bg-white",
                                                    onChange: handleChange,
                                                    required: true
                                                }, void 0, false, {
                                                    fileName: "[project]/app/offer/page.tsx",
                                                    lineNumber: 949,
                                                    columnNumber: 21
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/app/offer/page.tsx",
                                            lineNumber: 945,
                                            columnNumber: 19
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "space-y-2",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                    className: "block text-sm font-semibold text-gray-700",
                                                    children: [
                                                        "Prix du siège (TND)",
                                                        !priceManuallyEdited && form.price && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                            className: "ml-2 text-xs text-blue-600",
                                                            children: "✨ Auto-calculé"
                                                        }, void 0, false, {
                                                            fileName: "[project]/app/offer/page.tsx",
                                                            lineNumber: 963,
                                                            columnNumber: 25
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/app/offer/page.tsx",
                                                    lineNumber: 960,
                                                    columnNumber: 21
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                    name: "price",
                                                    placeholder: "Prix calculé automatiquement",
                                                    type: "number",
                                                    min: "1",
                                                    step: "0.5",
                                                    value: form.price,
                                                    className: "w-full p-4 border border-gray-300 rounded-xl focus:ring-2 focus:ring-gray-500 focus:border-transparent transition bg-white",
                                                    onChange: handleChange,
                                                    required: true
                                                }, void 0, false, {
                                                    fileName: "[project]/app/offer/page.tsx",
                                                    lineNumber: 966,
                                                    columnNumber: 21
                                                }, this),
                                                priceManuallyEdited && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                    className: "text-xs text-gray-500 mt-1",
                                                    children: "Prix modifié manuellement"
                                                }, void 0, false, {
                                                    fileName: "[project]/app/offer/page.tsx",
                                                    lineNumber: 978,
                                                    columnNumber: 23
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/app/offer/page.tsx",
                                            lineNumber: 959,
                                            columnNumber: 19
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "space-y-2",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                    className: "block text-sm font-semibold text-gray-700",
                                                    children: "Sièges disponibles"
                                                }, void 0, false, {
                                                    fileName: "[project]/app/offer/page.tsx",
                                                    lineNumber: 985,
                                                    columnNumber: 21
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                                                    name: "nb_places_disponible",
                                                    value: form.nb_places_disponible,
                                                    className: "w-full p-4 border border-gray-300 rounded-xl focus:ring-2 focus:ring-gray-500 focus:border-transparent transition bg-white",
                                                    onChange: handleChange,
                                                    required: true,
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                            value: "",
                                                            children: "Choisir les sièges"
                                                        }, void 0, false, {
                                                            fileName: "[project]/app/offer/page.tsx",
                                                            lineNumber: 995,
                                                            columnNumber: 23
                                                        }, this),
                                                        selectedCar && Array.from({
                                                            length: selectedCar.nb_place - 1
                                                        }, (_, i)=>i + 1).map((num)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                                value: num.toString(),
                                                                children: [
                                                                    num,
                                                                    " seat",
                                                                    num > 1 ? "s" : ""
                                                                ]
                                                            }, num, true, {
                                                                fileName: "[project]/app/offer/page.tsx",
                                                                lineNumber: 1001,
                                                                columnNumber: 27
                                                            }, this)),
                                                        !selectedCar && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                                    value: "1",
                                                                    children: "1 Place"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/app/offer/page.tsx",
                                                                    lineNumber: 1007,
                                                                    columnNumber: 27
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                                    value: "2",
                                                                    children: "2 Places"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/app/offer/page.tsx",
                                                                    lineNumber: 1008,
                                                                    columnNumber: 27
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                                    value: "3",
                                                                    children: "3 Places"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/app/offer/page.tsx",
                                                                    lineNumber: 1009,
                                                                    columnNumber: 27
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                                    value: "4",
                                                                    children: "4 Places"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/app/offer/page.tsx",
                                                                    lineNumber: 1010,
                                                                    columnNumber: 27
                                                                }, this)
                                                            ]
                                                        }, void 0, true)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/app/offer/page.tsx",
                                                    lineNumber: 988,
                                                    columnNumber: 21
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/app/offer/page.tsx",
                                            lineNumber: 984,
                                            columnNumber: 19
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/app/offer/page.tsx",
                                    lineNumber: 944,
                                    columnNumber: 17
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/app/offer/page.tsx",
                                lineNumber: 943,
                                columnNumber: 15
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$offer$2f$FormSection$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                title: "Vehicle Information",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "space-y-4",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "space-y-2",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                    className: "block text-sm font-semibold text-gray-700",
                                                    children: "Choisir votre voiture"
                                                }, void 0, false, {
                                                    fileName: "[project]/app/offer/page.tsx",
                                                    lineNumber: 1022,
                                                    columnNumber: 21
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                                                    name: "selected_car_id",
                                                    value: form.selected_car_id,
                                                    className: "w-full p-4 border border-gray-300 rounded-xl focus:ring-2 focus:ring-gray-500 focus:border-transparent transition bg-white",
                                                    onChange: handleChange,
                                                    required: true,
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                            value: "",
                                                            children: "Choisir une voiture depuis votre collection"
                                                        }, void 0, false, {
                                                            fileName: "[project]/app/offer/page.tsx",
                                                            lineNumber: 1032,
                                                            columnNumber: 23
                                                        }, this),
                                                        ownedCars.map((car)=>{
                                                            var _car_model_details, _car_model_details1, _car_color_details;
                                                            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                                value: car.id.toString(),
                                                                children: [
                                                                    ((_car_model_details = car.model_details) === null || _car_model_details === void 0 ? void 0 : _car_model_details.brand.name) || "Voiture",
                                                                    " ",
                                                                    (_car_model_details1 = car.model_details) === null || _car_model_details1 === void 0 ? void 0 : _car_model_details1.name,
                                                                    " (",
                                                                    car.year || "-",
                                                                    ")",
                                                                    " - ",
                                                                    (_car_color_details = car.color_details) === null || _car_color_details === void 0 ? void 0 : _car_color_details.name,
                                                                    " - ",
                                                                    car.serial_number
                                                                ]
                                                            }, car.id, true, {
                                                                fileName: "[project]/app/offer/page.tsx",
                                                                lineNumber: 1036,
                                                                columnNumber: 25
                                                            }, this);
                                                        })
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/app/offer/page.tsx",
                                                    lineNumber: 1025,
                                                    columnNumber: 21
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/app/offer/page.tsx",
                                            lineNumber: 1021,
                                            columnNumber: 19
                                        }, this),
                                        ownedCars.length === 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "bg-gray-50 rounded-xl p-6 border border-gray-200 text-center",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "text-gray-400 text-4xl mb-3",
                                                    children: "🚗"
                                                }, void 0, false, {
                                                    fileName: "[project]/app/offer/page.tsx",
                                                    lineNumber: 1046,
                                                    columnNumber: 23
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                                    className: "font-semibold text-gray-900 mb-2",
                                                    children: "Aucune voiture disponible"
                                                }, void 0, false, {
                                                    fileName: "[project]/app/offer/page.tsx",
                                                    lineNumber: 1047,
                                                    columnNumber: 23
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                    className: "text-gray-600 mb-4",
                                                    children: "Vous devez ajouter un véhicule à votre compte avant de proposer des trajets."
                                                }, void 0, false, {
                                                    fileName: "[project]/app/offer/page.tsx",
                                                    lineNumber: 1050,
                                                    columnNumber: 23
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                    type: "button",
                                                    className: "px-4 py-2 bg-black text-white rounded-lg hover:bg-gray-800 transition font-medium",
                                                    onClick: ()=>window.location.href = "/profile",
                                                    children: "Ajouter un véhicule"
                                                }, void 0, false, {
                                                    fileName: "[project]/app/offer/page.tsx",
                                                    lineNumber: 1053,
                                                    columnNumber: 23
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/app/offer/page.tsx",
                                            lineNumber: 1045,
                                            columnNumber: 21
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/app/offer/page.tsx",
                                    lineNumber: 1020,
                                    columnNumber: 17
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/app/offer/page.tsx",
                                lineNumber: 1019,
                                columnNumber: 15
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$offer$2f$FormSection$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                title: "Services & accessoires",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "grid grid-cols-2 md:grid-cols-3 gap-4",
                                    children: services.map((service)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                            className: "flex items-center space-x-3 cursor-pointer",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                    type: "checkbox",
                                                    checked: form.services.includes(service.id),
                                                    onChange: ()=>handleServiceChange(service.id),
                                                    className: "w-5 h-5 text-gray-600 border-gray-300 rounded focus:ring-gray-500"
                                                }, void 0, false, {
                                                    fileName: "[project]/app/offer/page.tsx",
                                                    lineNumber: 1073,
                                                    columnNumber: 23
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: "text-sm font-medium text-gray-700",
                                                    children: service.name
                                                }, void 0, false, {
                                                    fileName: "[project]/app/offer/page.tsx",
                                                    lineNumber: 1079,
                                                    columnNumber: 23
                                                }, this)
                                            ]
                                        }, service.id, true, {
                                            fileName: "[project]/app/offer/page.tsx",
                                            lineNumber: 1069,
                                            columnNumber: 21
                                        }, this))
                                }, void 0, false, {
                                    fileName: "[project]/app/offer/page.tsx",
                                    lineNumber: 1067,
                                    columnNumber: 17
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/app/offer/page.tsx",
                                lineNumber: 1066,
                                columnNumber: 15
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$offer$2f$FormSection$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                title: "Information supplémentaire",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "space-y-2",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                            className: "block text-sm font-semibold text-gray-700",
                                            children: "Description (Optional)"
                                        }, void 0, false, {
                                            fileName: "[project]/app/offer/page.tsx",
                                            lineNumber: 1090,
                                            columnNumber: 19
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("textarea", {
                                            name: "description",
                                            value: form.description,
                                            placeholder: "Mettre des informations additionnelles pour votre trajets, preferences et details.",
                                            rows: 4,
                                            className: "w-full p-4 border border-gray-300 rounded-xl focus:ring-2 focus:ring-gray-500 focus:border-transparent transition bg-white resize-none",
                                            onChange: handleChange
                                        }, void 0, false, {
                                            fileName: "[project]/app/offer/page.tsx",
                                            lineNumber: 1093,
                                            columnNumber: 19
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/app/offer/page.tsx",
                                    lineNumber: 1089,
                                    columnNumber: 17
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/app/offer/page.tsx",
                                lineNumber: 1088,
                                columnNumber: 15
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                type: "submit",
                                className: "w-full py-4 bg-black text-white rounded-xl font-semibold text-lg hover:bg-gray-800 transition transform hover:scale-105 shadow-lg",
                                disabled: ownedCars.length === 0,
                                children: "Publier votre trajet"
                            }, void 0, false, {
                                fileName: "[project]/app/offer/page.tsx",
                                lineNumber: 1104,
                                columnNumber: 15
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/offer/page.tsx",
                        lineNumber: 861,
                        columnNumber: 13
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/offer/page.tsx",
                lineNumber: 841,
                columnNumber: 9
            }, this)
        }, void 0, false, {
            fileName: "[project]/app/offer/page.tsx",
            lineNumber: 840,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/app/offer/page.tsx",
        lineNumber: 839,
        columnNumber: 5
    }, this);
}
_s(OfferRidePage, "CkEnkT1lVdbDYUXl5nSYPY0Ntvk=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$redux$2f$dist$2f$react$2d$redux$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSelector"]
    ];
});
_c2 = OfferRidePage;
var _c, _c1, _c2;
__turbopack_context__.k.register(_c, "RouteMapLeaflet");
__turbopack_context__.k.register(_c1, "SingleLocationMap");
__turbopack_context__.k.register(_c2, "OfferRidePage");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/node_modules/next/dist/shared/lib/lazy-dynamic/dynamic-bailout-to-csr.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { m: module, e: exports } = __turbopack_context__;
{
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "BailoutToCSR", {
    enumerable: true,
    get: function() {
        return BailoutToCSR;
    }
});
const _bailouttocsr = __turbopack_context__.r("[project]/node_modules/next/dist/shared/lib/lazy-dynamic/bailout-to-csr.js [app-client] (ecmascript)");
function BailoutToCSR(param) {
    let { reason, children } = param;
    if (typeof window === 'undefined') {
        throw Object.defineProperty(new _bailouttocsr.BailoutToCSRError(reason), "__NEXT_ERROR_CODE", {
            value: "E394",
            enumerable: false,
            configurable: true
        });
    }
    return children;
} //# sourceMappingURL=dynamic-bailout-to-csr.js.map
}}),
"[project]/node_modules/next/dist/shared/lib/encode-uri-path.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { m: module, e: exports } = __turbopack_context__;
{
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "encodeURIPath", {
    enumerable: true,
    get: function() {
        return encodeURIPath;
    }
});
function encodeURIPath(file) {
    return file.split('/').map((p)=>encodeURIComponent(p)).join('/');
} //# sourceMappingURL=encode-uri-path.js.map
}}),
"[project]/node_modules/next/dist/shared/lib/lazy-dynamic/preload-chunks.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { m: module, e: exports } = __turbopack_context__;
{
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
'use client';
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "PreloadChunks", {
    enumerable: true,
    get: function() {
        return PreloadChunks;
    }
});
const _jsxruntime = __turbopack_context__.r("[project]/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
const _reactdom = __turbopack_context__.r("[project]/node_modules/next/dist/compiled/react-dom/index.js [app-client] (ecmascript)");
const _workasyncstorageexternal = __turbopack_context__.r("[project]/node_modules/next/dist/server/app-render/work-async-storage.external.js [app-client] (ecmascript)");
const _encodeuripath = __turbopack_context__.r("[project]/node_modules/next/dist/shared/lib/encode-uri-path.js [app-client] (ecmascript)");
function PreloadChunks(param) {
    let { moduleIds } = param;
    // Early return in client compilation and only load requestStore on server side
    if (typeof window !== 'undefined') {
        return null;
    }
    const workStore = _workasyncstorageexternal.workAsyncStorage.getStore();
    if (workStore === undefined) {
        return null;
    }
    const allFiles = [];
    // Search the current dynamic call unique key id in react loadable manifest,
    // and find the corresponding CSS files to preload
    if (workStore.reactLoadableManifest && moduleIds) {
        const manifest = workStore.reactLoadableManifest;
        for (const key of moduleIds){
            if (!manifest[key]) continue;
            const chunks = manifest[key].files;
            allFiles.push(...chunks);
        }
    }
    if (allFiles.length === 0) {
        return null;
    }
    const dplId = ("TURBOPACK compile-time falsy", 0) ? "TURBOPACK unreachable" : '';
    return /*#__PURE__*/ (0, _jsxruntime.jsx)(_jsxruntime.Fragment, {
        children: allFiles.map((chunk)=>{
            const href = workStore.assetPrefix + "/_next/" + (0, _encodeuripath.encodeURIPath)(chunk) + dplId;
            const isCss = chunk.endsWith('.css');
            // If it's stylesheet we use `precedence` o help hoist with React Float.
            // For stylesheets we actually need to render the CSS because nothing else is going to do it so it needs to be part of the component tree.
            // The `preload` for stylesheet is not optional.
            if (isCss) {
                return /*#__PURE__*/ (0, _jsxruntime.jsx)("link", {
                    // @ts-ignore
                    precedence: "dynamic",
                    href: href,
                    rel: "stylesheet",
                    as: "style"
                }, chunk);
            } else {
                // If it's script we use ReactDOM.preload to preload the resources
                (0, _reactdom.preload)(href, {
                    as: 'script',
                    fetchPriority: 'low'
                });
                return null;
            }
        })
    });
} //# sourceMappingURL=preload-chunks.js.map
}}),
"[project]/node_modules/next/dist/shared/lib/lazy-dynamic/loadable.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { m: module, e: exports } = __turbopack_context__;
{
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function() {
        return _default;
    }
});
const _jsxruntime = __turbopack_context__.r("[project]/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
const _react = __turbopack_context__.r("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
const _dynamicbailouttocsr = __turbopack_context__.r("[project]/node_modules/next/dist/shared/lib/lazy-dynamic/dynamic-bailout-to-csr.js [app-client] (ecmascript)");
const _preloadchunks = __turbopack_context__.r("[project]/node_modules/next/dist/shared/lib/lazy-dynamic/preload-chunks.js [app-client] (ecmascript)");
// Normalize loader to return the module as form { default: Component } for `React.lazy`.
// Also for backward compatible since next/dynamic allows to resolve a component directly with loader
// Client component reference proxy need to be converted to a module.
function convertModule(mod) {
    // Check "default" prop before accessing it, as it could be client reference proxy that could break it reference.
    // Cases:
    // mod: { default: Component }
    // mod: Component
    // mod: { default: proxy(Component) }
    // mod: proxy(Component)
    const hasDefault = mod && 'default' in mod;
    return {
        default: hasDefault ? mod.default : mod
    };
}
const defaultOptions = {
    loader: ()=>Promise.resolve(convertModule(()=>null)),
    loading: null,
    ssr: true
};
function Loadable(options) {
    const opts = {
        ...defaultOptions,
        ...options
    };
    const Lazy = /*#__PURE__*/ (0, _react.lazy)(()=>opts.loader().then(convertModule));
    const Loading = opts.loading;
    function LoadableComponent(props) {
        const fallbackElement = Loading ? /*#__PURE__*/ (0, _jsxruntime.jsx)(Loading, {
            isLoading: true,
            pastDelay: true,
            error: null
        }) : null;
        // If it's non-SSR or provided a loading component, wrap it in a suspense boundary
        const hasSuspenseBoundary = !opts.ssr || !!opts.loading;
        const Wrap = hasSuspenseBoundary ? _react.Suspense : _react.Fragment;
        const wrapProps = hasSuspenseBoundary ? {
            fallback: fallbackElement
        } : {};
        const children = opts.ssr ? /*#__PURE__*/ (0, _jsxruntime.jsxs)(_jsxruntime.Fragment, {
            children: [
                typeof window === 'undefined' ? /*#__PURE__*/ (0, _jsxruntime.jsx)(_preloadchunks.PreloadChunks, {
                    moduleIds: opts.modules
                }) : null,
                /*#__PURE__*/ (0, _jsxruntime.jsx)(Lazy, {
                    ...props
                })
            ]
        }) : /*#__PURE__*/ (0, _jsxruntime.jsx)(_dynamicbailouttocsr.BailoutToCSR, {
            reason: "next/dynamic",
            children: /*#__PURE__*/ (0, _jsxruntime.jsx)(Lazy, {
                ...props
            })
        });
        return /*#__PURE__*/ (0, _jsxruntime.jsx)(Wrap, {
            ...wrapProps,
            children: children
        });
    }
    LoadableComponent.displayName = 'LoadableComponent';
    return LoadableComponent;
}
const _default = Loadable; //# sourceMappingURL=loadable.js.map
}}),
"[project]/node_modules/next/dist/shared/lib/app-dynamic.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { m: module, e: exports } = __turbopack_context__;
{
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function() {
        return dynamic;
    }
});
const _interop_require_default = __turbopack_context__.r("[project]/node_modules/@swc/helpers/cjs/_interop_require_default.cjs [app-client] (ecmascript)");
const _loadable = /*#__PURE__*/ _interop_require_default._(__turbopack_context__.r("[project]/node_modules/next/dist/shared/lib/lazy-dynamic/loadable.js [app-client] (ecmascript)"));
function dynamic(dynamicOptions, options) {
    var _mergedOptions_loadableGenerated;
    const loadableOptions = {};
    if (typeof dynamicOptions === 'function') {
        loadableOptions.loader = dynamicOptions;
    }
    const mergedOptions = {
        ...loadableOptions,
        ...options
    };
    return (0, _loadable.default)({
        ...mergedOptions,
        modules: (_mergedOptions_loadableGenerated = mergedOptions.loadableGenerated) == null ? void 0 : _mergedOptions_loadableGenerated.modules
    });
}
if ((typeof exports.default === 'function' || typeof exports.default === 'object' && exports.default !== null) && typeof exports.default.__esModule === 'undefined') {
    Object.defineProperty(exports.default, '__esModule', {
        value: true
    });
    Object.assign(exports.default, exports);
    module.exports = exports.default;
} //# sourceMappingURL=app-dynamic.js.map
}}),
}]);

//# sourceMappingURL=_acbfa20e._.js.map