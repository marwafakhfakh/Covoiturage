(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[root-of-the-server]__a75f3211._.css",
  "static/chunks/node_modules_a2d2afd1._.js",
  "static/chunks/_566d742a._.js"
],
    source: "dynamic"
});
