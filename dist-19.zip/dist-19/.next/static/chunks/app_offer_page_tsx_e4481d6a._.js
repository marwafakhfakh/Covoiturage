(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/app_offer_733dd79a._.js",
  "static/chunks/_acbfa20e._.js"
],
    source: "dynamic"
});
