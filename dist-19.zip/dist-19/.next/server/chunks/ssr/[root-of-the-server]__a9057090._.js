module.exports = {

"[externals]/next/dist/compiled/next-server/app-page-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-page-turbo.runtime.dev.js, cjs)": ((__turbopack_context__) => {

var { m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js"));

module.exports = mod;
}}),
"[project]/components/rides/RideCard.tsx [app-ssr] (ecmascript)": ((__turbopack_context__) => {

var { m: module, e: exports } = __turbopack_context__;
{
// import Link from "next/link";
// import Image from "next/image";
// export interface RideData {
//   id: number;
//   user: {
//     id: number;
//     first_name: string;
//     last_name: string;
//     username: string;
//     email?: string;
//     review_score?: number;
//     review_numbers?: number;
//     professional?: boolean;
//     current_package_plan?: { package: string };
//     subscription_status?: string;
//     joining_date?: string;
//     date_joined?: string;
//     avatar?: string;
//     profile_picture?: string;
//     phone_number?: string;
//     bio?: string;
//     active?: boolean;
//   };
//   car: {
//     id: number;
//   model_details?: {
//     id: number;
//     name: string;
//     brand: {
//       id: number;
//       name: string;
//     };
//   },    type: string;
//     color: string;
//       color_details?: { id: number; name: string; code: string } | null;
//     serial_number: string;
//     nb_place: number;
//     engine_type: string;
//     grey_card: string;
//     year?: number;
//     image?: string | null;
//     owner: number;
//   };
//   services: {
//     id: number;
//     name: string;
//     description: string;
//     active: boolean;
//     logo: string | null;
//   }[];
//   departure_date: string;
//   departure_place: string;
//   departure_city?: string; // Nom de la ville de départ
//   arrival_place: string;
//   arrival_city?: string; // Nom de la ville d'arrivée
//   status: string;
//   nb_places_disponible: number;
//   price: string;
//   equivalent_price?: string | null;
//   round_trip: boolean;
// }
// interface RideCardProps {
//   ride: RideData;
//   className?: string;
// }
// function renderStars(rating: number) {
//   const stars = [];
//   const fullStars = Math.floor(rating);
//   const hasHalfStar = rating % 1 >= 0.5;
//   for (let i = 0; i < fullStars; i++) {
//     stars.push(
//       <span key={i} className="text-yellow-400">
//         ★
//       </span>
//     );
//   }
//   if (hasHalfStar) {
//     stars.push(
//       <span key="half" className="text-yellow-400">
//         ☆
//       </span>
//     );
//   }
//   for (let i = stars.length; i < 5; i++) {
//     stars.push(
//       <span key={i} className="text-gray-300">
//         ☆
//       </span>
//     );
//   }
//   return stars;
// }
// export default function RideCard({ ride, className = "" }: RideCardProps) {
//   //  const departure = new Date(ride.departure_date);
//   // const now = new Date();
//   //   const FOUR_HOURS_MS = 4 * 60 * 60 * 1000;
//   // if (now.getTime() - departure.getTime() > FOUR_HOURS_MS) {
//   //   return null;
//   // }
//   // Driver info
//   const user = ride.user;
//   const name =
//     `${user.first_name || ""} ${user.last_name || ""}`.trim() || user.username;
//   const avatar =
//     user.avatar ||
//     user.profile_picture ||
//     "https://static.vecteezy.com/system/resources/thumbnails/020/765/399/small_2x/default-profile-account-unknown-icon-black-silhouette-free-vector.jpg";
//   const rating = user.review_score || 0;
//   const reviewNumbers = user.review_numbers || 0;
//   const isProfessional = user.professional;
//   // Car info
//   const car = ride.car;
//   const carName = car.model_details?.brand.name
//     ? `${car.model_details.name} (${car.type}, ${car.color_details?.name})`
//     : `${car.type}, ${car.color_details?.name}`;
//   // Services
//   const services = ride.services.map((s) => s.name);
//   return (
//     <Link
//       href={`/rides/${ride.id}`}
//       className={`block bg-white border border-gray-200 rounded-2xl shadow-lg hover:shadow-xl transition-all duration-300 p-6 group ${className}`}
//     >
//       <div className="flex items-center justify-between">
//         {/* Left Side - Driver & Route */}
//         <div className="flex items-center gap-6 flex-1">
//           {/* Driver Info */}
//           <div className="flex items-center gap-4">
//             <Image
//               src={avatar}
//               alt={name}
//               width={64}
//               height={64}
//               className="rounded-full border-2 border-gray-200 shadow-md"
//             />
//             <div>
//               <div className="font-semibold text-lg text-gray-900 group-hover:text-gray-700 transition flex items-center gap-2">
//                 {name}
//                 {isProfessional && (
//                   <span className="ml-2 px-2 py-1 bg-blue-100 text-blue-700 text-xs rounded-full font-semibold">
//                     Pro
//                   </span>
//                 )}
//               </div>
//               <div className="text-sm text-gray-500">{carName}</div>
//               <div className="flex items-center gap-1 mt-1">
//                 {renderStars(rating)}
//                 <span className="text-sm text-gray-500 ml-1">
//                   ({rating.toFixed(1)})
//                 </span>
//                 <span className="text-gray-400 text-xs ml-2">
//                   {reviewNumbers} reviews
//                 </span>
//               </div>
//             </div>
//           </div>
//           {/* Route */}
//           <div className="flex-1 min-w-0">
//             <div className="flex items-center gap-3 mb-2">
//               {/* Départ */}
//               <div className="flex flex-col">
//                 <div className="text-xl font-bold text-gray-900">
//                   {ride.departure_place}
//                 </div>
//                 {ride.departure_city && (
//                   <div className="text-xs text-gray-500 mt-0.5">
//                     {ride.departure_city}
//                   </div>
//                 )}
//               </div>
//               <div className="text-gray-400 text-2xl">→</div>
//               {/* Arrivée */}
//               <div className="flex flex-col">
//                 <div className="text-xl font-bold text-gray-900">
//                   {ride.arrival_place}
//                 </div>
//                 {ride.arrival_city && (
//                   <div className="text-xs text-gray-500 mt-0.5">
//                     {ride.arrival_city}
//                   </div>
//                 )}
//               </div>
//             </div>
//             {/* Date & Time */}
//             <div className="text-sm text-gray-600">
//               {new Date(ride.departure_date).toLocaleDateString("en-US", {
//                 weekday: "short",
//                 month: "short",
//                 day: "numeric",
//                 year: "numeric",
//                   timeZone: "UTC",          // empêche l’ajout de +1h
//   })}{" "}
//   at{" "}
//               {new Date(ride.departure_date).toLocaleTimeString("en-US", {
//                 hour: "2-digit",
//                 minute: "2-digit",
//                     timeZone: "UTC",          // affiche l’heure telle que stockée
//               })}
//             </div>
//             {/* Services */}
//             <div className="flex flex-wrap gap-1 mt-2">
//               {services.slice(0, 4).map((service, index) => (
//                 <span
//                   key={index}
//                   className="px-2 py-1 bg-gray-100 text-gray-600 text-xs rounded-full"
//                 >
//                   {service}
//                 </span>
//               ))}
//               {services.length > 4 && (
//                 <span className="px-2 py-1 bg-gray-200 text-gray-500 text-xs rounded-full">
//                   +{services.length - 4} more
//                 </span>
//               )}
//             </div>
//           </div>
//         </div>
//         {/* Right Side - Price & Seats */}
//         <div className="text-right flex-shrink-0 ml-6 min-w-[120px]">
//           <div className="text-3xl font-bold text-gray-900 mb-2">
//             {ride.price} TND
//           </div>
//           <div className="flex items-center gap-1 text-sm text-gray-500 justify-end">
//             <span>👥</span>
//             <span>
//               {ride.nb_places_disponible} seat
//               {ride.nb_places_disponible !== 1 ? "s" : ""} left
//             </span>
//           </div>
//           {ride.round_trip && (
//             <div className="mt-1 text-xs text-blue-600 font-semibold">
//               Round Trip
//             </div>
//           )}
//         </div>
//       </div>
//     </Link>
//   );
// }
}}),
"[project]/components/rides/RidesFilterSidebar.tsx [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s({
    "default": ()=>RidesFilterSidebar
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
;
const departureTimeRanges = [
    {
        value: "",
        label: "Any Time"
    },
    {
        value: "0-6",
        label: "00:00 - 06:00"
    },
    {
        value: "6-12",
        label: "06:00 - 12:00"
    },
    {
        value: "12-18",
        label: "12:00 - 18:00"
    },
    {
        value: "18-24",
        label: "18:00 - 24:00"
    }
];
const defaultSortOptions = [
    {
        value: "departure_time",
        label: "Departure Time"
    },
    {
        value: "price_low",
        label: "Price: Low to High"
    },
    {
        value: "price_high",
        label: "Price: High to Low"
    },
    {
        value: "seats",
        label: "Available Seats"
    }
];
const defaultServices = [
    "Air Conditioning",
    "Music System",
    "WiFi",
    "Phone Charger",
    "Snacks",
    "Water",
    "Pet Friendly",
    "Non-Smoking",
    "Luggage Space"
];
function RidesFilterSidebar({ filters, onSortChange, onServiceFilter, onClearFilters, onDepartureTimeRangeChange, availableServices = defaultServices, className = "" }) {
    const hasActiveFilters = filters.services.length > 0 || filters.sortBy !== "departure_time";
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: `w-80 flex-shrink-0 ${className}`,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "bg-white rounded-2xl shadow-xl p-6 sticky top-8",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                    className: "text-xl font-bold text-gray-900 mb-6",
                    children: "Filters"
                }, void 0, false, {
                    fileName: "[project]/components/rides/RidesFilterSidebar.tsx",
                    lineNumber: 63,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "mb-6",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                            className: "text-sm font-semibold text-gray-700 mb-3",
                            children: "Order By"
                        }, void 0, false, {
                            fileName: "[project]/components/rides/RidesFilterSidebar.tsx",
                            lineNumber: 67,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "space-y-2",
                            children: defaultSortOptions.map((option)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                    className: "flex items-center cursor-pointer",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                            type: "radio",
                                            name: "sortBy",
                                            value: option.value,
                                            checked: filters.sortBy === option.value,
                                            onChange: (e)=>onSortChange(e.target.value),
                                            className: "w-4 h-4 text-gray-600 border-gray-300 focus:ring-gray-500"
                                        }, void 0, false, {
                                            fileName: "[project]/components/rides/RidesFilterSidebar.tsx",
                                            lineNumber: 74,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "ml-3 text-sm text-gray-700",
                                            children: option.label
                                        }, void 0, false, {
                                            fileName: "[project]/components/rides/RidesFilterSidebar.tsx",
                                            lineNumber: 82,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, option.value, true, {
                                    fileName: "[project]/components/rides/RidesFilterSidebar.tsx",
                                    lineNumber: 70,
                                    columnNumber: 15
                                }, this))
                        }, void 0, false, {
                            fileName: "[project]/components/rides/RidesFilterSidebar.tsx",
                            lineNumber: 68,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/components/rides/RidesFilterSidebar.tsx",
                    lineNumber: 66,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "mb-6",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                            className: "text-sm font-semibold text-gray-700 mb-3",
                            children: "Departure Time"
                        }, void 0, false, {
                            fileName: "[project]/components/rides/RidesFilterSidebar.tsx",
                            lineNumber: 92,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "space-y-2",
                            children: departureTimeRanges.map((range)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                    className: "flex items-center cursor-pointer",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                            type: "radio",
                                            name: "departureTimeRange",
                                            value: range.value,
                                            checked: filters.departureTimeRange === range.value,
                                            onChange: (e)=>onDepartureTimeRangeChange(e.target.value),
                                            className: "w-4 h-4 text-gray-600 border-gray-300 focus:ring-gray-500"
                                        }, void 0, false, {
                                            fileName: "[project]/components/rides/RidesFilterSidebar.tsx",
                                            lineNumber: 101,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "ml-3 text-sm text-gray-700",
                                            children: range.label
                                        }, void 0, false, {
                                            fileName: "[project]/components/rides/RidesFilterSidebar.tsx",
                                            lineNumber: 109,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, range.value, true, {
                                    fileName: "[project]/components/rides/RidesFilterSidebar.tsx",
                                    lineNumber: 97,
                                    columnNumber: 15
                                }, this))
                        }, void 0, false, {
                            fileName: "[project]/components/rides/RidesFilterSidebar.tsx",
                            lineNumber: 95,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/components/rides/RidesFilterSidebar.tsx",
                    lineNumber: 91,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                            className: "text-sm font-semibold text-gray-700 mb-3",
                            children: "Services"
                        }, void 0, false, {
                            fileName: "[project]/components/rides/RidesFilterSidebar.tsx",
                            lineNumber: 119,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "space-y-2 max-h-64 overflow-y-auto",
                            children: availableServices.map((service)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                    className: "flex items-center cursor-pointer",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                            type: "checkbox",
                                            checked: filters.services.includes(service),
                                            onChange: ()=>onServiceFilter(service),
                                            className: "w-4 h-4 text-gray-600 border-gray-300 rounded focus:ring-gray-500"
                                        }, void 0, false, {
                                            fileName: "[project]/components/rides/RidesFilterSidebar.tsx",
                                            lineNumber: 123,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "ml-3 text-sm text-gray-700",
                                            children: service
                                        }, void 0, false, {
                                            fileName: "[project]/components/rides/RidesFilterSidebar.tsx",
                                            lineNumber: 129,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, service, true, {
                                    fileName: "[project]/components/rides/RidesFilterSidebar.tsx",
                                    lineNumber: 122,
                                    columnNumber: 15
                                }, this))
                        }, void 0, false, {
                            fileName: "[project]/components/rides/RidesFilterSidebar.tsx",
                            lineNumber: 120,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/components/rides/RidesFilterSidebar.tsx",
                    lineNumber: 118,
                    columnNumber: 9
                }, this),
                hasActiveFilters && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                    onClick: onClearFilters,
                    className: "mt-6 w-full px-4 py-2 text-sm text-gray-600 border border-gray-300 rounded-lg hover:bg-gray-50 transition",
                    children: "Clear All Filters"
                }, void 0, false, {
                    fileName: "[project]/components/rides/RidesFilterSidebar.tsx",
                    lineNumber: 137,
                    columnNumber: 11
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/components/rides/RidesFilterSidebar.tsx",
            lineNumber: 62,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/components/rides/RidesFilterSidebar.tsx",
        lineNumber: 61,
        columnNumber: 5
    }, this);
}
}),
"[project]/app/layout.tsx [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

// import type { Metadata } from "next";
// import { Geist, Geist_Mono } from "next/font/google";
// import "./globals.css";
// import NavbarApp from "../components/NavbarApp";
// import ReduxProvider from "../store/ReduxProvider";
// import UserProfileLoader from "../components/UserProfileLoader";
// import Footer from "../components/Footer";
// import "leaflet/dist/leaflet.css";
// import InstallPWA from "@/components/InstallPWA";
// const geistSans = Geist({
//   variable: "--font-geist-sans",
//   subsets: ["latin"],
// });
// const geistMono = Geist_Mono({
//   variable: "--font-geist-mono",
//   subsets: ["latin"],
// });
// export const metadata: Metadata = {
//   title: "نملة  NAMLAA application de covoiturage légal et sécurisé",
//   description: "Application de partage de trajets entre citoyens écologique et durable",
//   manifest: "/manifest.json",
//   themeColor: "#f97316",
// };
// export default function RootLayout({
//   children,
// }: {
//   children: React.ReactNode;
// }) {
//   return (
//     <html lang="fr">
//       <body
//         className={`${geistSans.variable} ${geistMono.variable} antialiased bg-white text-black min-h-screen flex flex-col`}
//       >
//         <ReduxProvider>
//           <UserProfileLoader>
//             <NavbarApp />
//             <InstallPWA />
//             <main>{children}</main>
//             <Footer />
//           </UserProfileLoader>
//         </ReduxProvider>
//       </body>
//     </html>
//   );
// }
__turbopack_context__.s({
    "default": ()=>RidesPage
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$rides$2f$RideCard$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/rides/RideCard.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$rides$2f$RidesFilterSidebar$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/rides/RidesFilterSidebar.tsx [app-ssr] (ecmascript)");
"use client";
;
;
;
;
function RidesPage({ rides }) {
    const [filters, setFilters] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])({
        sortBy: "departure_time",
        services: [],
        departureTimeRange: ""
    });
    const handleSortChange = (sortBy)=>{
        setFilters((prev)=>({
                ...prev,
                sortBy
            }));
    };
    const handleServiceFilter = (service)=>{
        setFilters((prev)=>({
                ...prev,
                services: prev.services.includes(service) ? prev.services.filter((s)=>s !== service) : [
                    ...prev.services,
                    service
                ]
            }));
    };
    const handleClearFilters = ()=>{
        setFilters({
            sortBy: "departure_time",
            services: [],
            departureTimeRange: ""
        });
    };
    const handleDepartureTimeRangeChange = (range)=>{
        setFilters((prev)=>({
                ...prev,
                departureTimeRange: range
            }));
    };
    // Filtrer et trier les rides selon les filtres
    const filteredRides = rides; // Ajouter votre logique de filtrage ici
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "min-h-screen bg-gray-50",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "bg-white border-b border-gray-200 px-4 py-6 sm:px-6 lg:px-8",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "max-w-screen-2xl mx-auto",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                            className: "text-2xl sm:text-3xl font-bold text-gray-900 mb-2",
                            children: "Trajets disponibles"
                        }, void 0, false, {
                            fileName: "[project]/app/layout.tsx",
                            lineNumber: 110,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "text-sm sm:text-base text-gray-600",
                            children: "All Available Rides"
                        }, void 0, false, {
                            fileName: "[project]/app/layout.tsx",
                            lineNumber: 113,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "text-xs sm:text-sm text-gray-500 mt-1",
                            children: [
                                filteredRides.length,
                                " ride",
                                filteredRides.length !== 1 ? "s" : "",
                                " found"
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/layout.tsx",
                            lineNumber: 116,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/layout.tsx",
                    lineNumber: 109,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/app/layout.tsx",
                lineNumber: 108,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "max-w-screen-2xl mx-auto px-4 py-6 sm:px-6 lg:px-8",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex flex-col lg:flex-row gap-6",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$rides$2f$RidesFilterSidebar$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                            filters: filters,
                            onSortChange: handleSortChange,
                            onServiceFilter: handleServiceFilter,
                            onClearFilters: handleClearFilters,
                            onDepartureTimeRangeChange: handleDepartureTimeRangeChange
                        }, void 0, false, {
                            fileName: "[project]/app/layout.tsx",
                            lineNumber: 126,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex-1 min-w-0",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "space-y-4",
                                children: filteredRides.length === 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "bg-white rounded-2xl shadow-lg p-8 sm:p-12 text-center",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "text-gray-400 mb-4",
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                                className: "w-16 h-16 sm:w-20 sm:h-20 mx-auto",
                                                fill: "none",
                                                viewBox: "0 0 24 24",
                                                stroke: "currentColor",
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                                    strokeLinecap: "round",
                                                    strokeLinejoin: "round",
                                                    strokeWidth: 1.5,
                                                    d: "M9.172 16.172a4 4 0 015.656 0M9 10h.01M15 10h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"
                                                }, void 0, false, {
                                                    fileName: "[project]/app/layout.tsx",
                                                    lineNumber: 146,
                                                    columnNumber: 23
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/app/layout.tsx",
                                                lineNumber: 140,
                                                columnNumber: 21
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/app/layout.tsx",
                                            lineNumber: 139,
                                            columnNumber: 19
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                            className: "text-lg sm:text-xl font-semibold text-gray-700 mb-2",
                                            children: "No rides found"
                                        }, void 0, false, {
                                            fileName: "[project]/app/layout.tsx",
                                            lineNumber: 154,
                                            columnNumber: 19
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                            className: "text-sm sm:text-base text-gray-500",
                                            children: "Try adjusting your filters or search criteria"
                                        }, void 0, false, {
                                            fileName: "[project]/app/layout.tsx",
                                            lineNumber: 157,
                                            columnNumber: 19
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/app/layout.tsx",
                                    lineNumber: 138,
                                    columnNumber: 17
                                }, this) : filteredRides.map((ride)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$rides$2f$RideCard$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                        ride: ride
                                    }, ride.id, false, {
                                        fileName: "[project]/app/layout.tsx",
                                        lineNumber: 163,
                                        columnNumber: 19
                                    }, this))
                            }, void 0, false, {
                                fileName: "[project]/app/layout.tsx",
                                lineNumber: 136,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/app/layout.tsx",
                            lineNumber: 135,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/layout.tsx",
                    lineNumber: 124,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/app/layout.tsx",
                lineNumber: 123,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "lg:hidden h-20"
            }, void 0, false, {
                fileName: "[project]/app/layout.tsx",
                lineNumber: 172,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/layout.tsx",
        lineNumber: 106,
        columnNumber: 5
    }, this);
}
}),
"[project]/node_modules/next/dist/server/route-modules/app-page/module.compiled.js [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { m: module, e: exports } = __turbopack_context__;
{
if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
;
else {
    if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
    ;
    else {
        if ("TURBOPACK compile-time truthy", 1) {
            if ("TURBOPACK compile-time truthy", 1) {
                module.exports = __turbopack_context__.r("[externals]/next/dist/compiled/next-server/app-page-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-page-turbo.runtime.dev.js, cjs)");
            } else //TURBOPACK unreachable
            ;
        } else //TURBOPACK unreachable
        ;
    }
} //# sourceMappingURL=module.compiled.js.map
}}),
"[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { m: module, e: exports } = __turbopack_context__;
{
module.exports = __turbopack_context__.r("[project]/node_modules/next/dist/server/route-modules/app-page/module.compiled.js [app-ssr] (ecmascript)").vendored['react-ssr'].ReactJsxDevRuntime; //# sourceMappingURL=react-jsx-dev-runtime.js.map
}}),
"[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { m: module, e: exports } = __turbopack_context__;
{
module.exports = __turbopack_context__.r("[project]/node_modules/next/dist/server/route-modules/app-page/module.compiled.js [app-ssr] (ecmascript)").vendored['react-ssr'].React; //# sourceMappingURL=react.js.map
}}),

};

//# sourceMappingURL=%5Broot-of-the-server%5D__a9057090._.js.map