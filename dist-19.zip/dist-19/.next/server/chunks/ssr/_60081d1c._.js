module.exports = {

"[project]/components/profile/ProfileCard.tsx [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s({
    "default": ()=>ProfileCard
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/image.js [app-ssr] (ecmascript)");
;
;
function renderStars(rating) {
    const stars = [];
    const fullStars = Math.floor(rating);
    const hasHalfStar = rating % 1 >= 0.5;
    for(let i = 0; i < fullStars; i++){
        stars.push(/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
            className: "text-yellow-400 text-lg",
            children: "★"
        }, i, false, {
            fileName: "[project]/components/profile/ProfileCard.tsx",
            lineNumber: 16,
            columnNumber: 7
        }, this));
    }
    if (hasHalfStar) {
        stars.push(/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
            className: "text-yellow-400 text-lg",
            children: "☆"
        }, "half", false, {
            fileName: "[project]/components/profile/ProfileCard.tsx",
            lineNumber: 23,
            columnNumber: 7
        }, this));
    }
    for(let i = stars.length; i < 5; i++){
        stars.push(/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
            className: "text-gray-300 text-lg",
            children: "☆"
        }, i, false, {
            fileName: "[project]/components/profile/ProfileCard.tsx",
            lineNumber: 30,
            columnNumber: 7
        }, this));
    }
    return stars;
}
function VerificationBadge({ verified, label }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "flex items-center gap-2",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: `w-5 h-5 rounded-full ${verified ? "bg-black" : "bg-gray-300"}`,
                children: verified && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                    className: "block w-full h-full text-white text-xs leading-5 text-center",
                    children: "✓"
                }, void 0, false, {
                    fileName: "[project]/components/profile/ProfileCard.tsx",
                    lineNumber: 53,
                    columnNumber: 11
                }, this)
            }, void 0, false, {
                fileName: "[project]/components/profile/ProfileCard.tsx",
                lineNumber: 47,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: "text-sm text-gray-700",
                children: label
            }, void 0, false, {
                fileName: "[project]/components/profile/ProfileCard.tsx",
                lineNumber: 58,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/components/profile/ProfileCard.tsx",
        lineNumber: 46,
        columnNumber: 5
    }, this);
}
function ProfileCard({ user, className = "" }) {
    // Compose name
    const name = `${user.first_name} ${user.last_name}`.trim() || user.username;
    const avatar = user.avatar || user.profile_picture || "https://static.vecteezy.com/system/resources/thumbnails/020/765/399/small_2x/default-profile-account-unknown-icon-black-silhouette-free-vector.jpg";
    const email = user.email;
    const phone = user.phone_number || "";
    const bio = user.bio || "";
    const memberSince = user.subscription_end_date?.slice(0, 12) || user.subscription_end_date?.slice(0, 12) || "";
    // Show review score and numbers
    const rating = user.review_score || 0;
    const reviewNumbers = user.review_numbers || 0;
    // Show package plan if available
    const packagePlan = user.current_package_plan?.package || "-";
    // Show subscription status
    const subscriptionStatus = user.subscription_status;
    // Show professional badge
    const isProfessional = user.professional;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: `bg-white rounded-2xl shadow-xl p-8 mb-8 ${className}`,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex flex-col lg:flex-row items-start lg:items-center gap-8",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex items-center gap-6",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                src: avatar,
                                alt: name,
                                width: 96,
                                height: 96,
                                className: "rounded-full border-4 border-gray-200 shadow-lg"
                            }, void 0, false, {
                                fileName: "[project]/components/profile/ProfileCard.tsx",
                                lineNumber: 92,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                                        className: "font-bold text-3xl text-gray-900 mb-2 flex items-center gap-2",
                                        children: [
                                            name,
                                            isProfessional && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "ml-2 px-2 py-1 bg-blue-100 text-blue-700 text-xs rounded-full font-semibold",
                                                children: "Pro"
                                            }, void 0, false, {
                                                fileName: "[project]/components/profile/ProfileCard.tsx",
                                                lineNumber: 103,
                                                columnNumber: 17
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/components/profile/ProfileCard.tsx",
                                        lineNumber: 100,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "flex items-center gap-2 mb-2",
                                        children: [
                                            renderStars(rating),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "text-gray-600 ml-1",
                                                children: [
                                                    "(",
                                                    rating.toFixed(1),
                                                    ")"
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/components/profile/ProfileCard.tsx",
                                                lineNumber: 110,
                                                columnNumber: 15
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "text-gray-400 text-xs",
                                                children: [
                                                    reviewNumbers,
                                                    " reviews"
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/components/profile/ProfileCard.tsx",
                                                lineNumber: 111,
                                                columnNumber: 15
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/components/profile/ProfileCard.tsx",
                                        lineNumber: 108,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "text-gray-600 text-sm mb-1",
                                        children: email
                                    }, void 0, false, {
                                        fileName: "[project]/components/profile/ProfileCard.tsx",
                                        lineNumber: 115,
                                        columnNumber: 13
                                    }, this),
                                    phone && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "text-gray-600 text-sm",
                                        children: phone
                                    }, void 0, false, {
                                        fileName: "[project]/components/profile/ProfileCard.tsx",
                                        lineNumber: 116,
                                        columnNumber: 23
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/components/profile/ProfileCard.tsx",
                                lineNumber: 99,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/profile/ProfileCard.tsx",
                        lineNumber: 91,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex-1 lg:text-right",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "grid grid-cols-2 md:grid-cols-3 gap-6 text-center lg:text-right",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "text-2xl font-bold text-gray-900",
                                            children: "Forfait"
                                        }, void 0, false, {
                                            fileName: "[project]/components/profile/ProfileCard.tsx",
                                            lineNumber: 123,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "text-sm text-gray-600",
                                            children: packagePlan
                                        }, void 0, false, {
                                            fileName: "[project]/components/profile/ProfileCard.tsx",
                                            lineNumber: 126,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/components/profile/ProfileCard.tsx",
                                    lineNumber: 122,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "text-2xl font-bold text-gray-900",
                                            children: "Abonnement"
                                        }, void 0, false, {
                                            fileName: "[project]/components/profile/ProfileCard.tsx",
                                            lineNumber: 129,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "text-sm text-gray-600",
                                            children: subscriptionStatus
                                        }, void 0, false, {
                                            fileName: "[project]/components/profile/ProfileCard.tsx",
                                            lineNumber: 132,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/components/profile/ProfileCard.tsx",
                                    lineNumber: 128,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "text-2xl font-bold text-gray-900",
                                            children: "Valide jusqu’au"
                                        }, void 0, false, {
                                            fileName: "[project]/components/profile/ProfileCard.tsx",
                                            lineNumber: 135,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "text-sm text-gray-600",
                                            children: memberSince
                                        }, void 0, false, {
                                            fileName: "[project]/components/profile/ProfileCard.tsx",
                                            lineNumber: 139,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/components/profile/ProfileCard.tsx",
                                    lineNumber: 134,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/components/profile/ProfileCard.tsx",
                            lineNumber: 121,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/components/profile/ProfileCard.tsx",
                        lineNumber: 120,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/profile/ProfileCard.tsx",
                lineNumber: 90,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "mt-6 pt-6 border-t border-gray-200",
                children: [
                    bio && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "text-gray-700 italic mb-4",
                        children: bio
                    }, void 0, false, {
                        fileName: "[project]/components/profile/ProfileCard.tsx",
                        lineNumber: 146,
                        columnNumber: 17
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex flex-wrap gap-4",
                        children: [
                            user.cin && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "px-2 py-1 bg-gray-100 text-gray-700 text-xs rounded",
                                children: [
                                    "CIN: ",
                                    user.cin
                                ]
                            }, void 0, true, {
                                fileName: "[project]/components/profile/ProfileCard.tsx",
                                lineNumber: 150,
                                columnNumber: 13
                            }, this),
                            user.driving_licence && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "px-2 py-1 bg-gray-100 text-gray-700 text-xs rounded",
                                children: [
                                    "Permis de conduire : ",
                                    user.driving_licence
                                ]
                            }, void 0, true, {
                                fileName: "[project]/components/profile/ProfileCard.tsx",
                                lineNumber: 155,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "px-2 py-1 bg-gray-100 text-gray-700 text-xs rounded",
                                children: [
                                    "Renouvellement automatique: ",
                                    user.auto_renew ? "Yes" : "No"
                                ]
                            }, void 0, true, {
                                fileName: "[project]/components/profile/ProfileCard.tsx",
                                lineNumber: 160,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: `px-2 py-1 text-xs rounded ${user.is_active ? "bg-green-100 text-green-700" : "bg-red-100 text-red-700"}`,
                                children: user.is_active ? "Active" : "Inactive"
                            }, void 0, false, {
                                fileName: "[project]/components/profile/ProfileCard.tsx",
                                lineNumber: 164,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/profile/ProfileCard.tsx",
                        lineNumber: 147,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/profile/ProfileCard.tsx",
                lineNumber: 145,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/components/profile/ProfileCard.tsx",
        lineNumber: 89,
        columnNumber: 5
    }, this);
}
}),
"[project]/components/profile/TripsSection.tsx [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

// import Link from "next/link";
// interface TripItemProps {
//   trip: {
//     id: number;
//     from: string;
//     to: string;
//     date: string;
//     price: string;
//     status: string;
//     seats?: number;
//     driver?: string;
//     bookedSeats?: number;
//     seatsAvailable?: number;
//   };
//   type: "reservation" | "offered";
//   onCancel?: (tripId: number) => void;
//   onEdit?: (tripId: number) => void;
// }
// interface TripsSectionProps {
//   title: string;
//   trips: TripItemProps["trip"][];
//   type: "reservation" | "offered";
//   onCancel?: (tripId: number) => void;
//   onEdit?: (tripId: number) => void;
//   className?: string;
// }
// function TripItem({ trip, type, onCancel, onEdit }: TripItemProps) {
//   const getStatusColor = (status: string) => {
//     switch (status.toLowerCase()) {
//       case "confirmed":
//       case "active":
//         return "bg-black text-white";
//       case "pending":
//         return "bg-gray-300 text-gray-700";
//       case "completed":
//       case "full":
//         return "bg-gray-100 text-gray-700";
//       default:
//         return "bg-gray-300 text-gray-700";
//     }
//   };
//   // Deterministic UTC date formatting
//   const dateObj = new Date(trip.date);
//   const dateStr =
//     dateObj.getUTCFullYear() +
//     "-" +
//     String(dateObj.getUTCMonth() + 1).padStart(2, "0") +
//     "-" +
//     String(dateObj.getUTCDate()).padStart(2, "0");
//   const timeStr =
//     String(dateObj.getUTCHours()).padStart(2, "0") +
//     ":" +
//     String(dateObj.getUTCMinutes()).padStart(2, "0");
//   const content = (
//     <div className="border border-gray-200 rounded-xl p-4 hover:shadow-md transition cursor-pointer">
//       <div className="flex justify-between items-start mb-3">
//         <div>
//           <div className="font-semibold text-lg text-gray-900">
//             {trip.from} <span className="text-gray-400">→</span> {trip.to}
//           </div>
//           <div className="text-gray-600 text-sm">
//   {dateStr} à {timeStr}H
// </div>
//           {type === "reservation" && trip.driver && (
//             <div className="text-gray-600 text-sm">
//               with <span className="font-medium">{trip.driver}</span>
//             </div>
//           )}
//           {type === "offered" && (
//             <div className="text-gray-600 text-sm">
//               {trip.status?.toLowerCase() === "full"
//                 ? `Full${
//                     typeof trip.seatsAvailable === "number" &&
//                     trip.seatsAvailable > 0
//                       ? ` (${trip.seatsAvailable} available)`
//                       : ""
//                   }`
//                 : typeof trip.seatsAvailable === "number"
//                 ? `${trip.seatsAvailable} seats available`
//                 : "-"}
//             </div>
//           )}
//         </div>
//         <div className="text-right">
//           <div className="text-lg font-bold text-gray-900">{trip.price} TND</div>
//           {type === "reservation" && trip.seats && (
//             <div className="text-sm text-gray-600">
//               {trip.seats} seat{trip.seats !== 1 ? "s" : ""}
//             </div>
//           )}
//           {type === "offered" && (
//             <div className="text-sm text-gray-600">par place</div>
//           )}
//         </div>
//       </div>
//       <div className="flex justify-between items-center">
//         <span
//           className={`px-3 py-1 rounded-full text-xs font-semibold ${getStatusColor(
//             trip.status
//           )}`}
//         >
//           {trip.status}
//         </span>
//         <div className="flex gap-2">
//           {onCancel && trip.status?.toLowerCase() !== "canceled" && (
//             <button
//               onClick={() => onCancel(trip.id)}
//               className="text-sm text-red-600 hover:text-red-800 font-medium border border-red-200 rounded px-2 py-1"
//             >
//               Supprimer
//             </button>
//           )}
//         </div>
//       </div>
//     </div>
//   );
//   if (type === "offered") {
//     return (
//       <Link
//         href={`/rides/${trip.id}`}
//         style={{ textDecoration: "none", color: "inherit" }}
//       >
//         {content}
//       </Link>
//     );
//   }
//   return content;
// }
// export default function TripsSection({
//   title,
//   trips,
//   type,
//   onCancel,
//   onEdit,
//   className = "",
// }: TripsSectionProps) {
//   return (
//     <div className={`bg-white rounded-2xl shadow-xl p-8 ${className}`}>
//       <h2 className="text-2xl font-bold text-gray-900 mb-6">{title}</h2>
//       <div className="space-y-4 max-h-96 overflow-y-auto pr-2">
//         {trips.map((trip) => (
//           <TripItem
//             key={trip.id}
//             trip={trip}
//             type={type}
//             onCancel={onCancel}
//             onEdit={onEdit}
//           />
//         ))}
//       </div>
//     </div>
//   );
// }
__turbopack_context__.s({
    "default": ()=>TripsSection
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
;
;
// Composant Modal de Confirmation
function ConfirmDeleteModal({ isOpen, onClose, onConfirm, tripInfo }) {
    if (!isOpen) return null;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50",
        onClick: onClose,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "bg-white rounded-xl shadow-2xl p-6 max-w-md w-full mx-4",
            onClick: (e)=>e.stopPropagation(),
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex items-center gap-3 mb-4",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "w-12 h-12 bg-red-100 rounded-full flex items-center justify-center",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                className: "w-6 h-6 text-red-600",
                                fill: "none",
                                stroke: "currentColor",
                                viewBox: "0 0 24 24",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                    strokeLinecap: "round",
                                    strokeLinejoin: "round",
                                    strokeWidth: 2,
                                    d: "M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"
                                }, void 0, false, {
                                    fileName: "[project]/components/profile/TripsSection.tsx",
                                    lineNumber: 222,
                                    columnNumber: 15
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/components/profile/TripsSection.tsx",
                                lineNumber: 216,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/components/profile/TripsSection.tsx",
                            lineNumber: 215,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                className: "text-lg font-bold text-gray-900",
                                children: "Confirmer la suppression"
                            }, void 0, false, {
                                fileName: "[project]/components/profile/TripsSection.tsx",
                                lineNumber: 231,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/components/profile/TripsSection.tsx",
                            lineNumber: 230,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/components/profile/TripsSection.tsx",
                    lineNumber: 214,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "mb-6",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: "text-gray-600 mb-3",
                            children: "Êtes-vous sûr de vouloir supprimer ce trajet ?"
                        }, void 0, false, {
                            fileName: "[project]/components/profile/TripsSection.tsx",
                            lineNumber: 238,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "bg-gray-50 rounded-lg p-3 border border-gray-200",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "text-sm font-semibold text-gray-900",
                                    children: [
                                        tripInfo.from,
                                        " → ",
                                        tripInfo.to
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/components/profile/TripsSection.tsx",
                                    lineNumber: 242,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "text-sm text-gray-600",
                                    children: tripInfo.date
                                }, void 0, false, {
                                    fileName: "[project]/components/profile/TripsSection.tsx",
                                    lineNumber: 245,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/components/profile/TripsSection.tsx",
                            lineNumber: 241,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: "text-sm text-red-600 mt-3",
                            children: "Cette action est irréversible."
                        }, void 0, false, {
                            fileName: "[project]/components/profile/TripsSection.tsx",
                            lineNumber: 247,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/components/profile/TripsSection.tsx",
                    lineNumber: 237,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex gap-3",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            onClick: onClose,
                            className: "flex-1 px-4 py-2 border border-gray-300 rounded-lg text-gray-700 font-medium hover:bg-gray-50 transition",
                            children: "Annuler"
                        }, void 0, false, {
                            fileName: "[project]/components/profile/TripsSection.tsx",
                            lineNumber: 253,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            onClick: onConfirm,
                            className: "flex-1 px-4 py-2 bg-red-600 text-white rounded-lg font-medium hover:bg-red-700 transition",
                            children: "Supprimer"
                        }, void 0, false, {
                            fileName: "[project]/components/profile/TripsSection.tsx",
                            lineNumber: 259,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/components/profile/TripsSection.tsx",
                    lineNumber: 252,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/components/profile/TripsSection.tsx",
            lineNumber: 210,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/components/profile/TripsSection.tsx",
        lineNumber: 206,
        columnNumber: 5
    }, this);
}
function TripItem({ trip, type, onCancel, onEdit }) {
    const [showConfirmModal, setShowConfirmModal] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    const [isNavigating, setIsNavigating] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    const getStatusColor = (status)=>{
        switch(status.toLowerCase()){
            case "confirmed":
            case "active":
                return "bg-black text-white";
            case "pending":
                return "bg-gray-300 text-gray-700";
            case "completed":
            case "full":
                return "bg-gray-100 text-gray-700";
            default:
                return "bg-gray-300 text-gray-700";
        }
    };
    // Deterministic UTC date formatting
    const dateObj = new Date(trip.date);
    const dateStr = dateObj.getUTCFullYear() + "-" + String(dateObj.getUTCMonth() + 1).padStart(2, "0") + "-" + String(dateObj.getUTCDate()).padStart(2, "0");
    const timeStr = String(dateObj.getUTCHours()).padStart(2, "0") + ":" + String(dateObj.getUTCMinutes()).padStart(2, "0");
    const handleDeleteClick = (e)=>{
        e.preventDefault();
        e.stopPropagation();
        setShowConfirmModal(true);
    };
    const handleConfirmDelete = ()=>{
        setShowConfirmModal(false);
        if (onCancel) {
            onCancel(trip.id);
        }
    };
    const handleCardClick = (e)=>{
        // Empêcher la navigation si le modal est ouvert
        if (showConfirmModal || isNavigating) {
            e.preventDefault();
            return;
        }
        // Pour les trajets offerts, naviguer vers la page de détails
        if (type === "offered") {
            setIsNavigating(true);
            window.location.href = `/rides/${trip.id}`;
        }
    };
    const content = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "border border-gray-200 rounded-xl p-4 hover:shadow-md transition cursor-pointer",
        onClick: handleCardClick,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex justify-between items-start mb-3",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "font-semibold text-lg text-gray-900",
                                children: [
                                    trip.from,
                                    " ",
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "text-gray-400",
                                        children: "→"
                                    }, void 0, false, {
                                        fileName: "[project]/components/profile/TripsSection.tsx",
                                        lineNumber: 338,
                                        columnNumber: 25
                                    }, this),
                                    " ",
                                    trip.to
                                ]
                            }, void 0, true, {
                                fileName: "[project]/components/profile/TripsSection.tsx",
                                lineNumber: 337,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "text-gray-600 text-sm",
                                children: [
                                    dateStr,
                                    " à ",
                                    timeStr,
                                    "H"
                                ]
                            }, void 0, true, {
                                fileName: "[project]/components/profile/TripsSection.tsx",
                                lineNumber: 340,
                                columnNumber: 11
                            }, this),
                            type === "reservation" && trip.driver && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "text-gray-600 text-sm",
                                children: [
                                    "with ",
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "font-medium",
                                        children: trip.driver
                                    }, void 0, false, {
                                        fileName: "[project]/components/profile/TripsSection.tsx",
                                        lineNumber: 345,
                                        columnNumber: 20
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/components/profile/TripsSection.tsx",
                                lineNumber: 344,
                                columnNumber: 13
                            }, this),
                            type === "offered" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "text-gray-600 text-sm",
                                children: trip.status?.toLowerCase() === "full" ? `Full${typeof trip.seatsAvailable === "number" && trip.seatsAvailable > 0 ? ` (${trip.seatsAvailable} available)` : ""}` : typeof trip.seatsAvailable === "number" ? `${trip.seatsAvailable} seats available` : "-"
                            }, void 0, false, {
                                fileName: "[project]/components/profile/TripsSection.tsx",
                                lineNumber: 349,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/profile/TripsSection.tsx",
                        lineNumber: 336,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "text-right",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "text-lg font-bold text-gray-900",
                                children: [
                                    trip.price,
                                    " TND"
                                ]
                            }, void 0, true, {
                                fileName: "[project]/components/profile/TripsSection.tsx",
                                lineNumber: 364,
                                columnNumber: 11
                            }, this),
                            type === "reservation" && trip.seats && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "text-sm text-gray-600",
                                children: [
                                    trip.seats,
                                    " seat",
                                    trip.seats !== 1 ? "s" : ""
                                ]
                            }, void 0, true, {
                                fileName: "[project]/components/profile/TripsSection.tsx",
                                lineNumber: 366,
                                columnNumber: 13
                            }, this),
                            type === "offered" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "text-sm text-gray-600",
                                children: "par place"
                            }, void 0, false, {
                                fileName: "[project]/components/profile/TripsSection.tsx",
                                lineNumber: 371,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/profile/TripsSection.tsx",
                        lineNumber: 363,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/profile/TripsSection.tsx",
                lineNumber: 335,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex justify-between items-center",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: `px-3 py-1 rounded-full text-xs font-semibold ${getStatusColor(trip.status)}`,
                        children: trip.status
                    }, void 0, false, {
                        fileName: "[project]/components/profile/TripsSection.tsx",
                        lineNumber: 376,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex gap-2",
                        children: onCancel && trip.status?.toLowerCase() !== "canceled" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            onClick: handleDeleteClick,
                            className: "text-sm text-red-600 hover:text-red-800 font-medium border border-red-200 rounded px-3 py-1 hover:bg-red-50 transition",
                            children: "Supprimer"
                        }, void 0, false, {
                            fileName: "[project]/components/profile/TripsSection.tsx",
                            lineNumber: 385,
                            columnNumber: 13
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/components/profile/TripsSection.tsx",
                        lineNumber: 383,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/profile/TripsSection.tsx",
                lineNumber: 375,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(ConfirmDeleteModal, {
                isOpen: showConfirmModal,
                onClose: ()=>setShowConfirmModal(false),
                onConfirm: handleConfirmDelete,
                tripInfo: {
                    from: trip.from,
                    to: trip.to,
                    date: `${dateStr} à ${timeStr}H`
                }
            }, void 0, false, {
                fileName: "[project]/components/profile/TripsSection.tsx",
                lineNumber: 396,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/components/profile/TripsSection.tsx",
        lineNumber: 331,
        columnNumber: 5
    }, this);
    // Retourner directement le contenu sans Link
    return content;
}
function TripsSection({ title, trips, type, onCancel, onEdit, className = "" }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: `bg-white rounded-2xl shadow-xl p-8 ${className}`,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                className: "text-2xl font-bold text-gray-900 mb-6",
                children: title
            }, void 0, false, {
                fileName: "[project]/components/profile/TripsSection.tsx",
                lineNumber: 423,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "space-y-4 max-h-96 overflow-y-auto pr-2",
                children: trips.map((trip)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(TripItem, {
                        trip: trip,
                        type: type,
                        onCancel: onCancel,
                        onEdit: onEdit
                    }, trip.id, false, {
                        fileName: "[project]/components/profile/TripsSection.tsx",
                        lineNumber: 426,
                        columnNumber: 11
                    }, this))
            }, void 0, false, {
                fileName: "[project]/components/profile/TripsSection.tsx",
                lineNumber: 424,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/components/profile/TripsSection.tsx",
        lineNumber: 422,
        columnNumber: 5
    }, this);
}
}),
"[project]/components/profile/CarCard.tsx [app-ssr] (ecmascript)": ((__turbopack_context__) => {

var { m: module, e: exports } = __turbopack_context__;
{
// import Image from "next/image";
// export interface Car {
//   id: number;
//   brand: string;
//   model: string;
//   year: number | string; // ✅ Accepte number OU string
//   color: string;
//   seats: number;
//   fuelType: string;
//   licensePlate: string;
//   image: string;
// }
// interface CarCardProps {
//   car: Car;
//   onEdit?: (car: Car) => void;
//   onRemove?: (carId: number) => void;
//   className?: string;
// }
// export default function CarCard({
//   car,
//   onEdit,
//   onRemove,
//   className = "",
// }: CarCardProps) {
//   return (
//     <div
//       className={`border border-gray-200 rounded-xl p-6 hover:shadow-md transition ${className}`}
//     >
//       <div className="aspect-video rounded-lg overflow-hidden mb-4 bg-gray-100">
//         <Image
//           src={
//             car.image
//               ? car.image
//               : "https://t3.ftcdn.net/jpg/01/71/13/24/360_F_171132449_uK0OO5XHrjjaqx5JUbJOIoCC3GZP84Mt.jpg"
//           }
//           alt={`${car.brand} ${car.model}`}
//           width={400}
//           height={225}
//           className="w-full h-full object-cover"
//         /> */{"}"}
//       </div>
//       <div className="space-y-3">
//         <div>
//           <h3 className="font-bold text-lg text-gray-900">
//             {car.brand} {car.model}
//           </h3>
//           <p className="text-gray-600 text-sm">
//             {car.year} • {car.color}
//           </p>
//         </div>
//         <div className="flex items-center gap-4 text-sm text-gray-600">
//           <div className="flex items-center gap-1">
//             <span>👥</span>
//             <span>{car.seats} places</span>
//           </div>
//           <div className="flex items-center gap-1">
//             <span>⛽</span>
//             <span>{car.fuelType}</span>
//           </div>
//         </div>
//         <div className="text-sm text-gray-600">
//           <span className="font-medium">Immatriculation:</span> {car.licensePlate}
//         </div>
//         <div className="flex gap-2 pt-2">
//           <button
//             onClick={() => onEdit?.(car)}
//             className="flex-1 px-4 py-2 text-gray-700 border border-gray-300 rounded-lg hover:bg-gray-50 transition text-sm font-medium"
//           >
//             Modifier
//           </button>
//           <button
//             onClick={() => onRemove?.(car.id)}
//             className="flex-1 px-4 py-2 text-gray-700 border border-gray-300 rounded-lg hover:bg-gray-50 transition text-sm font-medium"
//           >
//             Supprimer
//           </button>
//         </div>
//       </div>
//     </div>
//   );
// }
}}),
"[project]/components/profile/CarsSection.tsx [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s({
    "default": ()=>CarsSection
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$profile$2f$CarCard$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/profile/CarCard.tsx [app-ssr] (ecmascript)");
;
;
function CarsSection({ cars, onAddCar, onEditCar, onRemoveCar, className = "" }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: `bg-white rounded-2xl shadow-xl p-8 mt-8 ${className}`,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex justify-between items-center mb-6",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                        className: "text-2xl font-bold text-gray-900",
                        children: "Mes voitures"
                    }, void 0, false, {
                        fileName: "[project]/components/profile/CarsSection.tsx",
                        lineNumber: 21,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        onClick: onAddCar,
                        className: "px-6 py-3 bg-black text-white rounded-xl hover:bg-gray-800 transition font-semibold flex items-center gap-2",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "text-lg",
                                children: "+"
                            }, void 0, false, {
                                fileName: "[project]/components/profile/CarsSection.tsx",
                                lineNumber: 26,
                                columnNumber: 11
                            }, this),
                            "Ajouter une nouvelle voiture"
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/profile/CarsSection.tsx",
                        lineNumber: 22,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/profile/CarsSection.tsx",
                lineNumber: 20,
                columnNumber: 7
            }, this),
            cars.length === 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "text-center py-12",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "text-gray-400 text-6xl mb-4",
                        children: "🚗"
                    }, void 0, false, {
                        fileName: "[project]/components/profile/CarsSection.tsx",
                        lineNumber: 33,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                        className: "text-xl font-semibold text-gray-900 mb-2",
                        children: "Aucune voiture ajoutée pour le moment"
                    }, void 0, false, {
                        fileName: "[project]/components/profile/CarsSection.tsx",
                        lineNumber: 34,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "text-gray-600 mb-6",
                        children: "Ajoutez votre première voiture pour commencer à proposer des trajets"
                    }, void 0, false, {
                        fileName: "[project]/components/profile/CarsSection.tsx",
                        lineNumber: 37,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        onClick: onAddCar,
                        className: "px-6 py-3 bg-black text-white rounded-xl hover:bg-gray-800 transition font-semibold",
                        children: "Ajouter votre première voiture"
                    }, void 0, false, {
                        fileName: "[project]/components/profile/CarsSection.tsx",
                        lineNumber: 40,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/profile/CarsSection.tsx",
                lineNumber: 32,
                columnNumber: 9
            }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6",
                children: cars.map((car)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$profile$2f$CarCard$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                        car: car,
                        onEdit: onEditCar,
                        onRemove: onRemoveCar
                    }, car.id, false, {
                        fileName: "[project]/components/profile/CarsSection.tsx",
                        lineNumber: 50,
                        columnNumber: 13
                    }, this))
            }, void 0, false, {
                fileName: "[project]/components/profile/CarsSection.tsx",
                lineNumber: 48,
                columnNumber: 9
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/components/profile/CarsSection.tsx",
        lineNumber: 19,
        columnNumber: 5
    }, this);
}
}),
"[project]/components/AddCarModal.tsx [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s({
    "default": ()=>AddCarModal
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/image.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$api$2f$api$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/api/api.ts [app-ssr] (ecmascript)"); // ✅ Importez l'API directement
"use client";
;
;
;
;
function AddCarModal({ isOpen, onClose, onSubmit }) {
    const [formData, setFormData] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])({
        model: "",
        vehicle_type: "",
        color: "",
        serial_number: "",
        nb_place: 5,
        engine_type: "",
        grey_card: "",
        year: new Date().getFullYear(),
        image: null
    });
    const [imagePreview, setImagePreview] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])("");
    const [loading, setLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    const [error, setError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])("");
    // Data from backend
    const [models, setModels] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])([]);
    const [brands, setBrands] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])([]);
    const [vehicleTypes, setVehicleTypes] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])([]);
    const [colors, setColors] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])([]);
    const [engineTypes, setEngineTypes] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])([]);
    const [loadingData, setLoadingData] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(true);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        if (isOpen) {
            console.log("✅ Modal opened, fetching data...");
            fetchAllData();
        }
    }, [
        isOpen
    ]);
    const fetchAllData = async ()=>{
        try {
            setLoadingData(true);
            setError(""); // Réinitialiser l'erreur
            console.log("🔄 Fetching data from API...");
            const [modelsRes, brandsRes, vehicleTypesRes, colorsRes, engineTypesRes] = await Promise.all([
                __TURBOPACK__imported__module__$5b$project$5d2f$api$2f$api$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].get("/api/models/"),
                __TURBOPACK__imported__module__$5b$project$5d2f$api$2f$api$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].get("/api/brands/"),
                __TURBOPACK__imported__module__$5b$project$5d2f$api$2f$api$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].get("/api/vehicle-types/"),
                __TURBOPACK__imported__module__$5b$project$5d2f$api$2f$api$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].get("/api/colors/"),
                __TURBOPACK__imported__module__$5b$project$5d2f$api$2f$api$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].get("/api/engine-types/")
            ]);
            const modelsList = modelsRes.data.results || modelsRes.data || [];
            const brandsList = brandsRes.data.results || brandsRes.data || [];
            const vehicleTypesList = vehicleTypesRes.data.results || vehicleTypesRes.data || [];
            const colorsList = colorsRes.data.results || colorsRes.data || [];
            const engineTypesList = engineTypesRes.data.results || engineTypesRes.data || [];
            console.log("✅ Models loaded:", modelsList);
            console.log("✅ Brands loaded:", brandsList);
            console.log("✅ Vehicle Types loaded:", vehicleTypesList);
            console.log("✅ Colors loaded:", colorsList);
            console.log("✅ Engine Types loaded:", engineTypesList);
            setModels(modelsList);
            setBrands(brandsList);
            setVehicleTypes(vehicleTypesList);
            setColors(colorsList);
            setEngineTypes(engineTypesList);
            // Set default values
            if (modelsList.length > 0) {
                setFormData((prev)=>({
                        ...prev,
                        model: String(modelsList[0].id)
                    }));
            }
            if (vehicleTypesList.length > 0) {
                setFormData((prev)=>({
                        ...prev,
                        vehicle_type: String(vehicleTypesList[0].id)
                    }));
            }
            if (colorsList.length > 0) {
                setFormData((prev)=>({
                        ...prev,
                        color: String(colorsList[0].id)
                    }));
            }
            if (engineTypesList.length > 0) {
                setFormData((prev)=>({
                        ...prev,
                        engine_type: String(engineTypesList[0].id)
                    }));
            }
        } catch (err) {
            console.error("❌ Error fetching data:", err);
            // ✅ Type casting pour accéder aux propriétés
            const error = err;
            console.error("❌ Error details:", error.response?.data);
            console.error("❌ Error status:", error.response?.status);
            const errorMessage = error.response?.data?.detail || error.response?.data?.message || error.message || "Failed to load data. Please check your connection and try again.";
            setError(errorMessage);
        } finally{
            setLoadingData(false);
        }
    };
    const handleSubmit = async (e)=>{
        e.preventDefault();
        setError("");
        setLoading(true);
        console.log("=== 🚗 SUBMITTING CAR ===");
        console.log("formData:", formData);
        // Validation stricte
        if (!formData.model || formData.model === "") {
            setError("Please select a car model");
            setLoading(false);
            return;
        }
        if (!formData.vehicle_type || formData.vehicle_type === "") {
            setError("Please select a vehicle type");
            setLoading(false);
            return;
        }
        if (!formData.color || formData.color === "") {
            setError("Please select a color");
            setLoading(false);
            return;
        }
        if (!formData.engine_type || formData.engine_type === "") {
            setError("Please select an engine type");
            setLoading(false);
            return;
        }
        if (!formData.serial_number || formData.serial_number.trim() === "") {
            setError("Please enter a serial number");
            setLoading(false);
            return;
        }
        if (!formData.grey_card || formData.grey_card.trim() === "") {
            setError("Please enter a grey card number");
            setLoading(false);
            return;
        }
        const data = new FormData();
        data.append("model", String(formData.model));
        data.append("vehicle_type", String(formData.vehicle_type));
        data.append("color", String(formData.color));
        data.append("engine_type", String(formData.engine_type));
        data.append("serial_number", formData.serial_number.trim());
        data.append("nb_place", String(formData.nb_place));
        data.append("grey_card", formData.grey_card.trim());
        data.append("year", String(formData.year));
        data.append("is_active", "true");
        if (formData.image) {
            data.append("image", formData.image);
        }
        // Log du FormData
        console.log("📤 FormData being sent:");
        for (const [key, value] of data.entries()){
            console.log(`  ${key}:`, value);
        }
        try {
            const res = await __TURBOPACK__imported__module__$5b$project$5d2f$api$2f$api$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].post("/api/cars/", data, {
                headers: {
                    'Content-Type': 'multipart/form-data'
                }
            });
            console.log("✅ Car created successfully:", res.data);
            onSubmit(res.data);
            handleClose();
        } catch (err) {
            console.error("❌ Error creating car:", err);
            // ✅ Type casting pour accéder aux propriétés
            const error = err;
            console.error("❌ Error response:", error.response?.data);
            if (error.response?.data) {
                const errors = error.response.data;
                if (typeof errors === 'object') {
                    const errorMessages = Object.entries(errors).map(([key, value])=>`${key}: ${Array.isArray(value) ? value.join(', ') : value}`).join('\n');
                    setError(errorMessages);
                } else {
                    setError(String(errors));
                }
            } else {
                setError("An error occurred. Please try again.");
            }
        } finally{
            setLoading(false);
        }
    };
    const handleClose = ()=>{
        setFormData({
            model: models.length > 0 ? String(models[0].id) : "",
            vehicle_type: vehicleTypes.length > 0 ? String(vehicleTypes[0].id) : "",
            color: colors.length > 0 ? String(colors[0].id) : "",
            serial_number: "",
            nb_place: 5,
            engine_type: engineTypes.length > 0 ? String(engineTypes[0].id) : "",
            grey_card: "",
            year: new Date().getFullYear(),
            image: null
        });
        setImagePreview("");
        setError("");
        onClose();
    };
    const handleImageChange = (e)=>{
        const file = e.target.files?.[0];
        if (file) {
            if (file.size > 5 * 1024 * 1024) {
                setError("Image size must be less than 5MB");
                return;
            }
            setFormData({
                ...formData,
                image: file
            });
            setImagePreview(URL.createObjectURL(file));
            setError("");
        }
    };
    const getBrandName = (brandId)=>{
        return brands.find((b)=>b.id === brandId)?.name || "";
    };
    if (!isOpen) return null;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "bg-white rounded-2xl shadow-2xl max-w-3xl w-full max-h-[90vh] overflow-y-auto",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "p-6 border-b border-gray-200",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex justify-between items-center",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                className: "text-2xl font-bold text-gray-900",
                                children: "Add New Car"
                            }, void 0, false, {
                                fileName: "[project]/components/AddCarModal.tsx",
                                lineNumber: 301,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                onClick: handleClose,
                                className: "text-gray-400 hover:text-gray-600 text-2xl",
                                type: "button",
                                children: "×"
                            }, void 0, false, {
                                fileName: "[project]/components/AddCarModal.tsx",
                                lineNumber: 302,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/AddCarModal.tsx",
                        lineNumber: 300,
                        columnNumber: 11
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/components/AddCarModal.tsx",
                    lineNumber: 299,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "p-6 space-y-6",
                    children: [
                        error && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "p-4 bg-red-50 border border-red-200 rounded-lg",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "text-sm text-red-600 whitespace-pre-line",
                                    children: error
                                }, void 0, false, {
                                    fileName: "[project]/components/AddCarModal.tsx",
                                    lineNumber: 315,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    onClick: fetchAllData,
                                    className: "mt-2 text-sm text-blue-600 hover:text-blue-800 underline",
                                    children: "Try again"
                                }, void 0, false, {
                                    fileName: "[project]/components/AddCarModal.tsx",
                                    lineNumber: 316,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/components/AddCarModal.tsx",
                            lineNumber: 314,
                            columnNumber: 13
                        }, this),
                        loadingData ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "text-center py-8",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "inline-block animate-spin rounded-full h-8 w-8 border-b-2 border-gray-900"
                                }, void 0, false, {
                                    fileName: "[project]/components/AddCarModal.tsx",
                                    lineNumber: 327,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "mt-2 text-gray-500",
                                    children: "Loading data..."
                                }, void 0, false, {
                                    fileName: "[project]/components/AddCarModal.tsx",
                                    lineNumber: 328,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/components/AddCarModal.tsx",
                            lineNumber: 326,
                            columnNumber: 13
                        }, this) : models.length === 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "p-4 bg-yellow-50 border border-yellow-200 rounded-lg",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "text-sm text-yellow-800",
                                    children: "⚠️ No car models available. Please add at least one brand and model in the admin panel at:"
                                }, void 0, false, {
                                    fileName: "[project]/components/AddCarModal.tsx",
                                    lineNumber: 332,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                    href: "http://localhost:8000/admin",
                                    target: "_blank",
                                    rel: "noopener noreferrer",
                                    className: "text-blue-600 hover:text-blue-800 underline text-sm mt-2 inline-block",
                                    children: "http://localhost:8000/admin"
                                }, void 0, false, {
                                    fileName: "[project]/components/AddCarModal.tsx",
                                    lineNumber: 335,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/components/AddCarModal.tsx",
                            lineNumber: 331,
                            columnNumber: 13
                        }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("form", {
                            onSubmit: handleSubmit,
                            className: "space-y-6",
                            children: [
                                imagePreview && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "flex justify-center",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "w-64 h-36 rounded-lg overflow-hidden bg-gray-100 relative",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                            src: imagePreview,
                                            alt: "Car preview",
                                            fill: true,
                                            className: "object-cover"
                                        }, void 0, false, {
                                            fileName: "[project]/components/AddCarModal.tsx",
                                            lineNumber: 349,
                                            columnNumber: 21
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/components/AddCarModal.tsx",
                                        lineNumber: 348,
                                        columnNumber: 19
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/components/AddCarModal.tsx",
                                    lineNumber: 347,
                                    columnNumber: 17
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "grid grid-cols-1 md:grid-cols-2 gap-4",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "md:col-span-2",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                    className: "block text-sm font-medium text-gray-700 mb-2",
                                                    children: [
                                                        "Car Model * ",
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                            className: "text-xs text-gray-500"
                                                        }, void 0, false, {
                                                            fileName: "[project]/components/AddCarModal.tsx",
                                                            lineNumber: 363,
                                                            columnNumber: 33
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/components/AddCarModal.tsx",
                                                    lineNumber: 362,
                                                    columnNumber: 19
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                                                    required: true,
                                                    value: formData.model,
                                                    onChange: (e)=>{
                                                        console.log("✅ Model selected:", e.target.value);
                                                        setFormData({
                                                            ...formData,
                                                            model: e.target.value
                                                        });
                                                    },
                                                    className: "w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-gray-500 focus:border-transparent",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                            value: "",
                                                            children: "-- Select a model --"
                                                        }, void 0, false, {
                                                            fileName: "[project]/components/AddCarModal.tsx",
                                                            lineNumber: 374,
                                                            columnNumber: 21
                                                        }, this),
                                                        models.map((model)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                                value: model.id,
                                                                children: [
                                                                    getBrandName(model.brand),
                                                                    " ",
                                                                    model.name
                                                                ]
                                                            }, model.id, true, {
                                                                fileName: "[project]/components/AddCarModal.tsx",
                                                                lineNumber: 376,
                                                                columnNumber: 23
                                                            }, this))
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/components/AddCarModal.tsx",
                                                    lineNumber: 365,
                                                    columnNumber: 19
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/components/AddCarModal.tsx",
                                            lineNumber: 361,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                    className: "block text-sm font-medium text-gray-700 mb-2",
                                                    children: [
                                                        "Vehicle Type * ",
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                            className: "text-xs text-gray-500"
                                                        }, void 0, false, {
                                                            fileName: "[project]/components/AddCarModal.tsx",
                                                            lineNumber: 386,
                                                            columnNumber: 36
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/components/AddCarModal.tsx",
                                                    lineNumber: 385,
                                                    columnNumber: 19
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                                                    required: true,
                                                    value: formData.vehicle_type,
                                                    onChange: (e)=>setFormData({
                                                            ...formData,
                                                            vehicle_type: e.target.value
                                                        }),
                                                    className: "w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-gray-500 focus:border-transparent",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                            value: "",
                                                            children: "-- Select a type --"
                                                        }, void 0, false, {
                                                            fileName: "[project]/components/AddCarModal.tsx",
                                                            lineNumber: 394,
                                                            columnNumber: 21
                                                        }, this),
                                                        vehicleTypes.map((type)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                                value: type.id,
                                                                children: type.name
                                                            }, type.id, false, {
                                                                fileName: "[project]/components/AddCarModal.tsx",
                                                                lineNumber: 396,
                                                                columnNumber: 23
                                                            }, this))
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/components/AddCarModal.tsx",
                                                    lineNumber: 388,
                                                    columnNumber: 19
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/components/AddCarModal.tsx",
                                            lineNumber: 384,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                    className: "block text-sm font-medium text-gray-700 mb-2",
                                                    children: [
                                                        "Color * ",
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                            className: "text-xs text-gray-500"
                                                        }, void 0, false, {
                                                            fileName: "[project]/components/AddCarModal.tsx",
                                                            lineNumber: 406,
                                                            columnNumber: 29
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/components/AddCarModal.tsx",
                                                    lineNumber: 405,
                                                    columnNumber: 19
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                                                    required: true,
                                                    value: formData.color,
                                                    onChange: (e)=>setFormData({
                                                            ...formData,
                                                            color: e.target.value
                                                        }),
                                                    className: "w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-gray-500 focus:border-transparent",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                            value: "",
                                                            children: "-- Select a color --"
                                                        }, void 0, false, {
                                                            fileName: "[project]/components/AddCarModal.tsx",
                                                            lineNumber: 414,
                                                            columnNumber: 21
                                                        }, this),
                                                        colors.map((color)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                                value: color.id,
                                                                children: color.name
                                                            }, color.id, false, {
                                                                fileName: "[project]/components/AddCarModal.tsx",
                                                                lineNumber: 416,
                                                                columnNumber: 23
                                                            }, this))
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/components/AddCarModal.tsx",
                                                    lineNumber: 408,
                                                    columnNumber: 19
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/components/AddCarModal.tsx",
                                            lineNumber: 404,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                    className: "block text-sm font-medium text-gray-700 mb-2",
                                                    children: "Serial Number *"
                                                }, void 0, false, {
                                                    fileName: "[project]/components/AddCarModal.tsx",
                                                    lineNumber: 425,
                                                    columnNumber: 19
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                    type: "text",
                                                    required: true,
                                                    value: formData.serial_number,
                                                    onChange: (e)=>setFormData({
                                                            ...formData,
                                                            serial_number: e.target.value
                                                        }),
                                                    className: "w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-gray-500 focus:border-transparent",
                                                    placeholder: "110 TUN 3000"
                                                }, void 0, false, {
                                                    fileName: "[project]/components/AddCarModal.tsx",
                                                    lineNumber: 426,
                                                    columnNumber: 19
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/components/AddCarModal.tsx",
                                            lineNumber: 424,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                    className: "block text-sm font-medium text-gray-700 mb-2",
                                                    children: "Number of Seats *"
                                                }, void 0, false, {
                                                    fileName: "[project]/components/AddCarModal.tsx",
                                                    lineNumber: 438,
                                                    columnNumber: 19
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                                                    required: true,
                                                    value: formData.nb_place,
                                                    onChange: (e)=>setFormData({
                                                            ...formData,
                                                            nb_place: parseInt(e.target.value)
                                                        }),
                                                    className: "w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-gray-500 focus:border-transparent",
                                                    children: [
                                                        1,
                                                        2,
                                                        3
                                                    ].map((num)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                            value: num,
                                                            children: [
                                                                num,
                                                                " seat",
                                                                num > 1 ? "s" : ""
                                                            ]
                                                        }, num, true, {
                                                            fileName: "[project]/components/AddCarModal.tsx",
                                                            lineNumber: 446,
                                                            columnNumber: 23
                                                        }, this))
                                                }, void 0, false, {
                                                    fileName: "[project]/components/AddCarModal.tsx",
                                                    lineNumber: 439,
                                                    columnNumber: 19
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/components/AddCarModal.tsx",
                                            lineNumber: 437,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                    className: "block text-sm font-medium text-gray-700 mb-2",
                                                    children: [
                                                        "Engine Type * ",
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                            className: "text-xs text-gray-500"
                                                        }, void 0, false, {
                                                            fileName: "[project]/components/AddCarModal.tsx",
                                                            lineNumber: 454,
                                                            columnNumber: 35
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/components/AddCarModal.tsx",
                                                    lineNumber: 453,
                                                    columnNumber: 19
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                                                    required: true,
                                                    value: formData.engine_type,
                                                    onChange: (e)=>setFormData({
                                                            ...formData,
                                                            engine_type: e.target.value
                                                        }),
                                                    className: "w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-gray-500 focus:border-transparent",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                            value: "",
                                                            children: "-- Select engine type --"
                                                        }, void 0, false, {
                                                            fileName: "[project]/components/AddCarModal.tsx",
                                                            lineNumber: 462,
                                                            columnNumber: 21
                                                        }, this),
                                                        engineTypes.map((type)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                                value: type.id,
                                                                children: type.name
                                                            }, type.id, false, {
                                                                fileName: "[project]/components/AddCarModal.tsx",
                                                                lineNumber: 464,
                                                                columnNumber: 23
                                                            }, this))
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/components/AddCarModal.tsx",
                                                    lineNumber: 456,
                                                    columnNumber: 19
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/components/AddCarModal.tsx",
                                            lineNumber: 452,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                    className: "block text-sm font-medium text-gray-700 mb-2",
                                                    children: "Grey Card *"
                                                }, void 0, false, {
                                                    fileName: "[project]/components/AddCarModal.tsx",
                                                    lineNumber: 473,
                                                    columnNumber: 19
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                    type: "text",
                                                    required: true,
                                                    value: formData.grey_card,
                                                    onChange: (e)=>setFormData({
                                                            ...formData,
                                                            grey_card: e.target.value
                                                        }),
                                                    className: "w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-gray-500 focus:border-transparent",
                                                    placeholder: "e.g., GC-1234-5678"
                                                }, void 0, false, {
                                                    fileName: "[project]/components/AddCarModal.tsx",
                                                    lineNumber: 474,
                                                    columnNumber: 19
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/components/AddCarModal.tsx",
                                            lineNumber: 472,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                    className: "block text-sm font-medium text-gray-700 mb-2",
                                                    children: "Year *"
                                                }, void 0, false, {
                                                    fileName: "[project]/components/AddCarModal.tsx",
                                                    lineNumber: 486,
                                                    columnNumber: 19
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                    type: "number",
                                                    required: true,
                                                    min: "1990",
                                                    max: new Date().getFullYear() + 1,
                                                    value: formData.year,
                                                    onChange: (e)=>setFormData({
                                                            ...formData,
                                                            year: parseInt(e.target.value)
                                                        }),
                                                    className: "w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-gray-500 focus:border-transparent"
                                                }, void 0, false, {
                                                    fileName: "[project]/components/AddCarModal.tsx",
                                                    lineNumber: 487,
                                                    columnNumber: 19
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/components/AddCarModal.tsx",
                                            lineNumber: 485,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "md:col-span-2",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                    className: "block text-sm font-medium text-gray-700 mb-2",
                                                    children: "Car Image (Optional, max 5MB)"
                                                }, void 0, false, {
                                                    fileName: "[project]/components/AddCarModal.tsx",
                                                    lineNumber: 500,
                                                    columnNumber: 19
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                    type: "file",
                                                    accept: "image/*",
                                                    onChange: handleImageChange,
                                                    className: "w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-gray-500 focus:border-transparent file:mr-4 file:py-2 file:px-4 file:rounded file:border-0 file:text-sm file:font-semibold file:bg-gray-100 file:text-gray-700 hover:file:bg-gray-200"
                                                }, void 0, false, {
                                                    fileName: "[project]/components/AddCarModal.tsx",
                                                    lineNumber: 501,
                                                    columnNumber: 19
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/components/AddCarModal.tsx",
                                            lineNumber: 499,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/components/AddCarModal.tsx",
                                    lineNumber: 359,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "flex gap-4 pt-4 border-t border-gray-200",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                            type: "button",
                                            onClick: handleClose,
                                            disabled: loading,
                                            className: "flex-1 px-6 py-3 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition font-medium disabled:opacity-50",
                                            children: "Cancel"
                                        }, void 0, false, {
                                            fileName: "[project]/components/AddCarModal.tsx",
                                            lineNumber: 511,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                            type: "submit",
                                            disabled: loading,
                                            className: "flex-1 px-6 py-3 bg-black text-white rounded-lg hover:bg-gray-800 transition font-medium disabled:opacity-50",
                                            children: loading ? "Adding..." : "Add Car"
                                        }, void 0, false, {
                                            fileName: "[project]/components/AddCarModal.tsx",
                                            lineNumber: 519,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/components/AddCarModal.tsx",
                                    lineNumber: 510,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/components/AddCarModal.tsx",
                            lineNumber: 345,
                            columnNumber: 13
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/components/AddCarModal.tsx",
                    lineNumber: 312,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/components/AddCarModal.tsx",
            lineNumber: 298,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/components/AddCarModal.tsx",
        lineNumber: 297,
        columnNumber: 5
    }, this);
}
}),
"[project]/app/profile/page.tsx [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

// "use client";
// import { useState, useEffect } from "react";
// import { useSelector } from "react-redux";
// import api from "../../api/api";
// import type { UserState } from "../../store/userSlice";
// import ProfileCard from "../../components/profile/ProfileCard";
// import TripsSection from "../../components/profile/TripsSection";
// import CarsSection from "../../components/profile/CarsSection";
// import { Car } from "../../components/profile/CarCard";
// import AddCarModal, { CarFormData } from "../../components/AddCarModal";
// interface RootState {
//   user: UserState;
// }
// // Même shape que dans AddCarModal
// // interface CarFormData {
// //   model: string;
// //   vehicle_type: string;
// //   color: string;
// //   serialNumber: string;
// //   seats: number;
// //   engine_type: string;
// //   greyCard: string;
// //   year: number;
// //   image: File | null;
// // }
// export default function ProfilePage() {
//   const user = useSelector((state: RootState) => state.user.user);
//   const [ownedCars, setOwnedCars] = useState<Car[]>([]);
//   const [isModalOpen, setIsModalOpen] = useState(false);
// interface OfferedRide {
//   id: number;
//   from: string;
//   to: string;
//   date: string;
//   price: string;
//   seats: number;
//   seatsAvailable: number;
//   status: string;
// }
// const [offeredRides, setOfferedRides] = useState<OfferedRide[]>([]);
//   // const [reservations, setReservations] = useState<any[]>([]);
// interface Reservation {
//   id: number;
//   from: string;
//   to: string;
//   date: string;
//   driver: string;
//   price: string;
//   status: string;
//   seats: number;
// }
// const [reservations, setReservations] = useState<Reservation[]>([]);
//   // Réservations
//   useEffect(() => {
//     async function fetchReservations() {
//       try {
//         const res = await api.get("/api/reservations/");
//         const data = Array.isArray(res.data) ? res.data : [];
//         // const mapped = data.map((item: any) => {
//         //   const post = item.post;
//         //   return {
//         //     id: item.id,
//         //     from: post?.departure_place || "-",
//         //     to: post?.arrival_place || "-",
//         //     date: post?.departure_date || "-",
//         //     driver:
//         //       post?.user?.first_name && post?.user?.last_name
//         //         ? `${post.user.first_name} ${post.user.last_name}`
//         //         : post?.user?.username || "-",
//         //     price: post?.price ? post.price.toString() : "-",
//         //     status: item.status,
//         //     seats: item.nb_place,
//         //   };
//         // });
//         const mapped = data.map((item: Record<string, unknown>) => {
//   const post = item.post as Record<string, unknown> | undefined;
//   const postUser = post?.user as Record<string, unknown> | undefined;
//   return {
//     id: item.id as number,
//     from: (post?.departure_place as string) || "-",
//     to: (post?.arrival_place as string) || "-",
//     date: (post?.departure_date as string) || "-",
//     driver:
//       postUser?.first_name && postUser?.last_name
//         ? `${postUser.first_name} ${postUser.last_name}`
//         : (postUser?.username as string) || "-",
//     price: post?.price ? (post.price as number).toString() : "-",
//     status: item.status as string,
//     seats: item.nb_place as number,
//   };
// });
//         setReservations(mapped);
//         console.log("Fetched reservations:", mapped);
//       } catch (err) {
//         console.error("Failed to fetch reservations", err);
//       }
//     }
//     fetchReservations();
//   }, []);
//   // Trajets offerts
//   useEffect(() => {
//     async function fetchOfferedRides() {
//       try {
//         const res = await api.get("/api/myPosts/");
//         const data = res.data;
//         // const rides = (Array.isArray(data) ? data : []).map((item: any) => ({
//         //   id: item.id,
//         //   from: item.departure_place,
//         //   to: item.arrival_place,
//         //   date: item.departure_date,
//         //   price: item.price,
//         //   seats: item.car?.nb_place ?? 0,
//         //   seatsAvailable: item.nb_places_disponible ?? 0,
//         //   status: item.status,
//         // }));
//         const rides = (Array.isArray(data) ? data : []).map((item: Record<string, unknown>) => {
//   const car = item.car as Record<string, unknown> | undefined;
//   return {
//     id: item.id as number,
//     from: item.departure_place as string,
//     to: item.arrival_place as string,
//     date: item.departure_date as string,
//     price: item.price as string,
//     seats: (car?.nb_place as number) ?? 0,
//     seatsAvailable: (item.nb_places_disponible as number) ?? 0,
//     status: item.status as string,
//   };
// });
//         setOfferedRides(rides);
//       } catch (err) {
//         console.error("Failed to fetch offered rides", err);
//       }
//     }
//     fetchOfferedRides();
//   }, []);
//   // Voitures possédées
//   // useEffect(() => {
//   //   async function fetchCars() {
//   //     try {
//   //       const res = await api.get("/api/cars/");
//   //       const data = Array.isArray(res.data) ? res.data : [];
//   //       const cars: Car[] = data.map((item: any) => ({
//   //         id: item.id,
//   //         brand: "", // à compléter si ton API renvoie la marque
//   //         model: item.model?.toString() || "",
//   //         year: item.year ?? "",
//   //         color: item.color || "",
//   //         seats: item.nb_place,
//   //         fuelType: item.engine_type,
//   //         licensePlate: item.serial_number,
//   //         image: item.image,
//   //       }));
//   //       setOwnedCars(cars);
//   //     } catch (err) {
//   //       console.error(err);
//   //     }
//   //   }
//   //   fetchCars();
//   // }, []);
//   useEffect(() => {
//   async function fetchCars() {
//     try {
//       const res = await api.get("/api/cars/");
//       const data = Array.isArray(res.data) ? res.data : [];
//       // ✅ Remplacer `any` par un type explicite
//       const cars: Car[] = data.map((item: Record<string, unknown>) => {
//         const modelDetails = item.model_details as Record<string, unknown> | undefined;
//         const brandDetails = modelDetails?.brand as Record<string, unknown> | undefined;
//         const colorDetails = item.color_details as Record<string, unknown> | undefined;
//         const engineTypeDetails = item.engine_type_details as Record<string, unknown> | undefined;
//         return {
//           id: item.id as number,
//           brand: (brandDetails?.name as string) || "",
//           model: (modelDetails?.name as string) || "",
//           year: item.year ? String(item.year) : "",
//           color: (colorDetails?.name as string) || "",
//           seats: (item.nb_place as number) || 0,
//           fuelType: (engineTypeDetails?.name as string) || "",
//           licensePlate: (item.serial_number as string) || "",
//           image: (item.image as string) || "",
//         };
//       });
//       setOwnedCars(cars);
//       console.log("✅ Voitures chargées:", cars);
//     } catch (err) {
//       console.error("❌ Erreur fetch cars:", err);
//     }
//   }
//   fetchCars();
// }, []);
// //   useEffect(() => {
// //   async function fetchCars() {
// //     try {
// //       const res = await api.get("/api/cars/");
// //       const data = Array.isArray(res.data) ? res.data : [];
// //       const cars: Car[] = data.map((item: any) => ({
// //         id: item.id,
// //         // ✅ UTILISER LES DETAILS NESTED
// //         brand: item.model_details?.brand?.name || "",
// //         model: item.model_details?.name || "",
// //         year: item.year?.toString() || "",
// //         color: item.color_details?.name || "",
// //         seats: item.nb_place || 0,
// //         fuelType: item.engine_type_details?.name || "",
// //         licensePlate: item.serial_number || "",
// //         image: item.image || "",
// //       }));
// //       setOwnedCars(cars);
// //       console.log("✅ Voitures chargées:", cars);
// //     } catch (err) {
// //       console.error("❌ Erreur fetch cars:", err);
// //     }
// //   }
// //   fetchCars();
// // }, []);
//   // ✅ Création de voiture côté backend + MAJ state
// //   const handleAddCar = async (formData: CarFormData) => {
// //     if (!user?.id) {
// //       alert("Utilisateur non connecté.");
// //       return;
// //     }
// //     try {
// //       const data = new FormData();
// //       data.append("model", formData.model);                 // ID du Model (ex: "1")
// //     data.append("type", formData.type);                  // ex: "SUV"
// //     data.append("color", formData.color);                // ex: "Silver"
// //     data.append("serial_number", formData.serialNumber.toUpperCase());
// //     data.append("nb_place", String(formData.seats));     // champ nb_place en DB
// //     data.append("engine_type", formData.engineType);     // ex: "Electric"
// //     data.append("grey_card", formData.greyCard || "");
// //     data.append("year", String(formData.year));          // ex: "2025"
// //     if (formData.image) data.append("image", formData.image);
// //     console.log("🚗 FormData envoyée:");
// //     for (const [k, v] of data.entries()) console.log(k, v);
// //     const res = await api.post("/api/cars/", data);
// //     const newCar: Car = {
// //       id: res.data.id,
// //       brand: "", // à remplir si l’API renvoie la marque
// //       model: formData.model,
// //       year: formData.year,
// //       color: formData.color,
// //       seats: formData.seats,
// //       fuelType: formData.engineType,
// //       licensePlate: formData.serialNumber.toUpperCase(),
// //       image: res.data.image || "",
// //     };
// //     setOwnedCars(prev => [...prev, newCar]);
// //     setIsModalOpen(false);
// //     alert("✅ Voiture ajoutée !");
// //   } catch (err: any) {
// //     console.error("❌ ERROR /api/cars/:", err.response?.data || err);
// //     if (err.response?.data) {
// //       const errors = err.response.data as Record<string, any>;
// //       let msg = "Erreurs:\n";
// //       for (const [field, error] of Object.entries(errors)) {
// //         msg += `${field}: ${Array.isArray(error) ? error[0] : error}\n`;
// //       }
// //       alert(msg);
// //     } else {
// //       alert("Erreur serveur 500 lors de la création de la voiture.");
// //     }
// //   }
// // };
// const handleAddCar = async (formData: CarFormData) => {
//   if (!user?.id) {
//     alert("Utilisateur non connecté.");
//     return;
//   }
//   console.log("🔍 formData reçu:", formData);
//   try {
//     const data = new FormData();
//     // utiliser les bons champs
//     const modelId = formData.model ?? "";
//     const vehicleTypeId = formData.vehicle_type ?? "";
//     const colorId = formData.color ?? "";
//     const engineTypeId = formData.engine_type ?? "";
//     console.log("🔍 IDs calculés:", {
//       modelId,
//       vehicleTypeId,
//       colorId,
//       engineTypeId,
//     });
//     if (!modelId || !vehicleTypeId || !colorId || !engineTypeId) {
//       alert("Veuillez sélectionner modèle, type, couleur et type de moteur.");
//       return;
//     }
//     // data.append("model", String(modelId));
//     // data.append("vehicle_type", String(vehicleTypeId));
//     // data.append("color", String(colorId));
//     // const rawSerial = formData.serialNumber ?? "";
//     // const serial = String(rawSerial).toUpperCase().trim();
//     // data.append("serial_number", serial);
//     // data.append("nb_place", String(formData.seats ?? ""));
//     // data.append("engine_type", String(engineTypeId));
//     // data.append("grey_card", formData.greyCard || "");
//     // data.append("year", formData.year ? String(formData.year) : "");
//     data.append("model", String(modelId));
//   data.append("vehicle_type", String(vehicleTypeId));
//   data.append("color", String(colorId));
//   const serial = (formData.serial_number ?? "").toUpperCase().trim();
//   data.append("serial_number", serial);
//   data.append("nb_place", String(formData.nb_place ?? ""));
//   data.append("engine_type", String(engineTypeId));
//   data.append("grey_card", formData.grey_card || "");
//   data.append("year", formData.year ? String(formData.year) : "");
//     if (formData.image) data.append("image", formData.image);
//     console.log("🚗 FormData envoyée:");
//     for (const [k, v] of data.entries()) console.log(k, v);
//       const res = await api.post("/api/cars/", data, {
//       headers: { "Content-Type": "multipart/form-data" },
//     });
//     // construction de newCar…
//   } catch (err) {  // ✅ CORRECTION LIGNE 342: Supprimer : any
//     console.error("❌ ERROR /api/cars/:", err);
//     // ✅ Typage correct pour gérer l'erreur
//     const error = err as { response?: { data?: Record<string, unknown> } };
//     // if (error.response?.data) {
//     //   const errors = error.response.data;
//     //   let msg = "Erreurs:\n";
//     //   for (const [field, errorMsg] of Object.entries(errors)) {
//     //     msg += `${field}: ${Array.isArray(errorMsg) ? errorMsg[0] : errorMsg}\n`;
//     //   }
//     //   alert(msg);
//     // } else {
//     //   alert("Erreur serveur lors de la création de la voiture.");
//     // }
//   }
// };
// //   const handleAddCar = async (formData: CarFormData) => {
// //   if (!user?.id) {
// //     alert("Utilisateur non connecté.");
// //     return;
// //   }
// //   try {
// //     const data = new FormData();
// //     data.append("model", formData.model.toString());
// //     data.append("vehicle_type", formData.type.toString());
// //     data.append("color", formData.color.toString());
// //     // ✅ sécuriser serialNumber
// //     const serial = (formData.serialNumber || "").toString().toUpperCase().trim();
// //     if (!serial) {
// //       alert("La plaque d'immatriculation est obligatoire.");
// //       return;
// //     }
// //     data.append("serial_number", serial);
// //     data.append("nb_place", String(formData.seats));
// //     data.append("engine_type", formData.engineType.toString());
// //     data.append("grey_card", formData.greyCard || "");
// //     data.append("year", formData.year ? String(formData.year) : "");
// //     if (formData.image) data.append("image", formData.image);
// //     const res = await api.post("/api/cars/", data, {
// //       headers: { "Content-Type": "multipart/form-data" },
// //     });
// //     const newCar: Car = {
// //       id: res.data.id,
// //       brand: res.data.model_details?.brand?.name || "",
// //       model: res.data.model_details?.name || "",
// //       year: res.data.year ?? "",
// //       color: res.data.color_details?.name || "",
// //       seats: res.data.nb_place,
// //       fuelType: res.data.engine_type_details?.name || "",
// //       licensePlate: res.data.serial_number || "",
// //       image: res.data.image || "",
// //     };
// //     setOwnedCars(prev => [...prev, newCar]);
// //     setIsModalOpen(false);
// //     alert("✅ Voiture ajoutée !");
// //   } catch (err: any) {
// //     console.error("❌ ERROR /api/cars/:", err.response?.data || err);
// //     if (err.response?.data) {
// //       const errors = err.response.data as Record<string, any>;
// //       let msg = "Erreurs:\n";
// //       for (const [field, error] of Object.entries(errors)) {
// //         msg += `${field}: ${Array.isArray(error) ? error[0] : error}\n`;
// //       }
// //       alert(msg);
// //     } else {
// //       alert("Erreur serveur lors de la création de la voiture.");
// //     }
// //   }
// // };
//   const handleEditCar = (car: Car) => {
//     console.log("Edit car:", car);
//   };
//   const handleRemoveCar = (carId: number) => {
//     setOwnedCars((prev) => prev.filter((car) => car.id !== carId));
//   };
//   const handleCancelReservation = async (tripId: number) => {
//     try {
//       await api.put(`/api/reservations/${tripId}/`, { status: "canceled" });
// setReservations((prev) =>
//         prev.map((r) => (r.id === tripId ? { ...r, status: "canceled" } : r))
//       );
//     } catch (err) {
//       console.error("Failed to cancel reservation", err);
//     }
//   };
//   const handleCancelOfferedRide = async (tripId: number) => {
//     try {
//       await api.put(`/api/posts/${tripId}/`, { status: "canceled" });
// setOfferedRides((prev) =>
//         prev.map((r) => (r.id === tripId ? { ...r, status: "canceled" } : r))
//       );
//     } catch (err) {
//       console.error("Failed to cancel offered ride", err);
//     }
//   };
//   const handleEditOfferedRide = (tripId: number) => {
//     console.log("Edit offered ride:", tripId);
//   };
//   return (
//     <main className="min-h-screen bg-gray-50 py-8">
//       <div className="max-w-6xl mx-auto px-4">
//         {user && <ProfileCard user={user} />}
//         <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
//           <TripsSection
// title="Mes réservations"
//             trips={reservations.filter(
//               (r) => r.status?.toLowerCase() !== "canceled"
//             )}
//             type="reservation"
//             onCancel={handleCancelReservation}
//           />
//           <TripsSection
// title="Mes trajets proposés"
//             trips={offeredRides}
//             type="offered"
//             onCancel={handleCancelOfferedRide}
//             onEdit={handleEditOfferedRide}
//           />
//         </div>
//         <CarsSection
//           cars={ownedCars}
//           onAddCar={() => setIsModalOpen(true)}
//           onEditCar={handleEditCar}
//           onRemoveCar={handleRemoveCar}
//         />
//       </div>
//       <AddCarModal
//         isOpen={isModalOpen}
//         onClose={() => setIsModalOpen(false)}
//         onSubmit={handleAddCar}
//       />
//     </main>
//   );
// }
// src/app/profile/page.tsx
__turbopack_context__.s({
    "default": ()=>ProfilePage
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$redux$2f$dist$2f$react$2d$redux$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-redux/dist/react-redux.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$api$2f$api$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/api/api.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$profile$2f$ProfileCard$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/profile/ProfileCard.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$profile$2f$TripsSection$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/profile/TripsSection.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$profile$2f$CarsSection$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/profile/CarsSection.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$AddCarModal$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/AddCarModal.tsx [app-ssr] (ecmascript)");
"use client";
;
;
;
;
;
;
;
;
function ProfilePage() {
    const user = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$redux$2f$dist$2f$react$2d$redux$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useSelector"])((state)=>state.user.user);
    const [ownedCars, setOwnedCars] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])([]);
    const [isModalOpen, setIsModalOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    const [offeredRides, setOfferedRides] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])([]);
    const [reservations, setReservations] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])([]);
    // ============================================================================
    // CHARGER LES RÉSERVATIONS
    // ============================================================================
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        async function fetchReservations() {
            try {
                const res = await __TURBOPACK__imported__module__$5b$project$5d2f$api$2f$api$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].get("/api/reservations/");
                const data = Array.isArray(res.data) ? res.data : [];
                const mapped = data.map((item)=>{
                    const post = item.post;
                    const postUser = post?.user;
                    return {
                        id: item.id,
                        from: post?.departure_place || "-",
                        to: post?.arrival_place || "-",
                        date: post?.departure_date || "-",
                        driver: postUser?.first_name && postUser?.last_name ? `${postUser.first_name} ${postUser.last_name}` : postUser?.username || "-",
                        price: post?.price ? post.price.toString() : "-",
                        status: item.status,
                        seats: item.nb_place
                    };
                });
                setReservations(mapped);
                console.log("✅ Réservations chargées:", mapped);
            } catch (err) {
                console.error("❌ Erreur fetch reservations:", err);
            }
        }
        fetchReservations();
    }, []);
    // ============================================================================
    // CHARGER LES TRAJETS OFFERTS
    // ============================================================================
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        async function fetchOfferedRides() {
            try {
                const res = await __TURBOPACK__imported__module__$5b$project$5d2f$api$2f$api$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].get("/api/myPosts/");
                const data = res.data;
                const rides = (Array.isArray(data) ? data : []).map((item)=>{
                    const car = item.car;
                    return {
                        id: item.id,
                        from: item.departure_place,
                        to: item.arrival_place,
                        date: item.departure_date,
                        price: item.price,
                        seats: car?.nb_place ?? 0,
                        seatsAvailable: item.nb_places_disponible ?? 0,
                        status: item.status
                    };
                });
                setOfferedRides(rides);
            } catch (err) {
                console.error("❌ Erreur fetch offered rides:", err);
            }
        }
        fetchOfferedRides();
    }, []);
    // ============================================================================
    // CHARGER LES VOITURES - MISE À JOUR POUR STOCKER LES IDs
    // ============================================================================
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        async function fetchCars() {
            try {
                const res = await __TURBOPACK__imported__module__$5b$project$5d2f$api$2f$api$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].get("/api/cars/");
                const data = Array.isArray(res.data) ? res.data : [];
                const cars = data.map((item)=>{
                    const modelDetails = item.model_details;
                    const brandDetails = modelDetails?.brand;
                    const colorDetails = item.color_details;
                    const engineTypeDetails = item.engine_type_details;
                    return {
                        id: item.id,
                        brand: brandDetails?.name || "",
                        model: modelDetails?.name || "",
                        year: item.year ? String(item.year) : "",
                        color: colorDetails?.name || "",
                        seats: item.nb_place || 0,
                        fuelType: engineTypeDetails?.name || "",
                        licensePlate: item.serial_number || "",
                        image: item.image || "",
                        // ✅ AJOUTER LES IDs POUR LE MODAL
                        vehicle_type: item.vehicle_type,
                        color_id: item.color,
                        engine_type: item.engine_type,
                        model_id: item.model,
                        nb_place: item.nb_place,
                        serial_number: item.serial_number,
                        grey_card: item.grey_card
                    };
                });
                setOwnedCars(cars);
                console.log("✅ Voitures chargées:", cars);
            } catch (err) {
                console.error("❌ Erreur fetch cars:", err);
            }
        }
        fetchCars();
    }, []);
    // ============================================================================
    // AJOUTER UNE VOITURE
    // ============================================================================
    const handleAddCar = async (formData)=>{
        if (!user?.id) {
            alert("Utilisateur non connecté.");
            return;
        }
        console.log("📝 formData reçu:", formData);
        try {
            const data = new FormData();
            const modelId = formData.model ?? "";
            const vehicleTypeId = formData.vehicle_type ?? "";
            const colorId = formData.color ?? "";
            const engineTypeId = formData.engine_type ?? "";
            console.log("📝 IDs calculés:", {
                modelId,
                vehicleTypeId,
                colorId,
                engineTypeId
            });
            if (!modelId || !vehicleTypeId || !colorId || !engineTypeId) {
                alert("Veuillez sélectionner modèle, type, couleur et type de moteur.");
                return;
            }
            data.append("model", String(modelId));
            data.append("vehicle_type", String(vehicleTypeId));
            data.append("color", String(colorId));
            const serial = (formData.serial_number ?? "").toUpperCase().trim();
            data.append("serial_number", serial);
            data.append("nb_place", String(formData.nb_place ?? ""));
            data.append("engine_type", String(engineTypeId));
            data.append("grey_card", formData.grey_card || "");
            data.append("year", formData.year ? String(formData.year) : "");
            if (formData.image) data.append("image", formData.image);
            console.log("🚗 FormData envoyée:");
            for (const [k, v] of data.entries())console.log(k, v);
            const res = await __TURBOPACK__imported__module__$5b$project$5d2f$api$2f$api$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].post("/api/cars/", data, {
                headers: {
                    "Content-Type": "multipart/form-data"
                }
            });
            console.log("✅ Voiture créée:", res.data);
            setIsModalOpen(false);
            alert("✅ Voiture ajoutée !");
            // Recharger les voitures
            window.location.reload();
        } catch (err) {
            console.error("❌ ERROR /api/cars/:", err);
            const error = err;
            if (error.response?.data) {
                const errors = error.response.data;
                let msg = "Erreurs:\n";
                for (const [field, errorMsg] of Object.entries(errors)){
                    msg += `${field}: ${Array.isArray(errorMsg) ? errorMsg[0] : errorMsg}\n`;
                }
                alert(msg);
            } else {
                alert("Erreur serveur lors de la création de la voiture.");
            }
        }
    };
    // ============================================================================
    // MODIFIER UNE VOITURE - Le modal gère ça maintenant
    // ============================================================================
    const handleEditCar = (car)=>{
        console.log("✅ Edit car appelé (géré par le modal):", car);
    // Le modal s'ouvre automatiquement depuis CarCard
    };
    // ============================================================================
    // SUPPRIMER UNE VOITURE
    // ============================================================================
    const handleRemoveCar = (carId)=>{
        setOwnedCars((prev)=>prev.filter((car)=>car.id !== carId));
    };
    // ============================================================================
    // ANNULER UNE RÉSERVATION
    // ============================================================================
    const handleCancelReservation = async (tripId)=>{
        try {
            await __TURBOPACK__imported__module__$5b$project$5d2f$api$2f$api$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].put(`/api/reservations/${tripId}/`, {
                status: "canceled"
            });
            setReservations((prev)=>prev.map((r)=>r.id === tripId ? {
                        ...r,
                        status: "canceled"
                    } : r));
        } catch (err) {
            console.error("Failed to cancel reservation", err);
        }
    };
    // ============================================================================
    // ANNULER UN TRAJET OFFERT
    // ============================================================================
    const handleCancelOfferedRide = async (tripId)=>{
        try {
            await __TURBOPACK__imported__module__$5b$project$5d2f$api$2f$api$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].put(`/api/posts/${tripId}/`, {
                status: "canceled"
            });
            setOfferedRides((prev)=>prev.map((r)=>r.id === tripId ? {
                        ...r,
                        status: "canceled"
                    } : r));
        } catch (err) {
            console.error("Failed to cancel offered ride", err);
        }
    };
    // ============================================================================
    // MODIFIER UN TRAJET OFFERT
    // ============================================================================
    const handleEditOfferedRide = (tripId)=>{
        console.log("Edit offered ride:", tripId);
    };
    // ============================================================================
    // RENDER
    // ============================================================================
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("main", {
        className: "min-h-screen bg-gray-50 py-8",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "max-w-6xl mx-auto px-4",
                children: [
                    user && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$profile$2f$ProfileCard$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                        user: user
                    }, void 0, false, {
                        fileName: "[project]/app/profile/page.tsx",
                        lineNumber: 804,
                        columnNumber: 18
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "grid grid-cols-1 lg:grid-cols-2 gap-8",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$profile$2f$TripsSection$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                title: "Mes réservations",
                                trips: reservations.filter((r)=>r.status?.toLowerCase() !== "canceled"),
                                type: "reservation",
                                onCancel: handleCancelReservation
                            }, void 0, false, {
                                fileName: "[project]/app/profile/page.tsx",
                                lineNumber: 807,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$profile$2f$TripsSection$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                title: "Mes trajets proposés",
                                trips: offeredRides,
                                type: "offered",
                                onCancel: handleCancelOfferedRide,
                                onEdit: handleEditOfferedRide
                            }, void 0, false, {
                                fileName: "[project]/app/profile/page.tsx",
                                lineNumber: 816,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/profile/page.tsx",
                        lineNumber: 806,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$profile$2f$CarsSection$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                        cars: ownedCars,
                        onAddCar: ()=>setIsModalOpen(true),
                        onEditCar: handleEditCar,
                        onRemoveCar: handleRemoveCar
                    }, void 0, false, {
                        fileName: "[project]/app/profile/page.tsx",
                        lineNumber: 825,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/profile/page.tsx",
                lineNumber: 803,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$AddCarModal$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                isOpen: isModalOpen,
                onClose: ()=>setIsModalOpen(false),
                onSubmit: handleAddCar
            }, void 0, false, {
                fileName: "[project]/app/profile/page.tsx",
                lineNumber: 833,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/profile/page.tsx",
        lineNumber: 802,
        columnNumber: 5
    }, this);
}
}),

};

//# sourceMappingURL=_60081d1c._.js.map