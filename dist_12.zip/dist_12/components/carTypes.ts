// List of car types (expand as needed)
export const CAR_TYPES = [
  "Sedan",
  "SUV",
  "Hatchback",
  "Convertible",
  "Coupe",
  "Wagon",
  "Van",
  "Pickup",
  "Minivan",
  "Crossover",
  "Sports Car",
];
